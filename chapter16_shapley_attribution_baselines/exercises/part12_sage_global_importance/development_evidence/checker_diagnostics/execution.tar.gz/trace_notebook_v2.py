import nbformat,json,os
from pathlib import Path
from nbclient import NotebookClient
root=Path('/home/bitwise/Documents/ARENA_3.0_Extended')
p=Path('/home/bitwise/.cache/arena_extended/sage/own-full-v2')
out=p.parent/'trace-v2';out.mkdir(exist_ok=False)
n=nbformat.read(p/'completed_learner.ipynb',as_version=4)
for i,c in enumerate(n.cells):
 if c.cell_type=='code':
  c.outputs=[];c.execution_count=None
  c.source+='\n\nif "prepared" in globals():\n    _stored = t.load(native_dir / "study/prepared.pt", weights_only=True)\n    _deltas = {k: float((prepared["explanations"][0][k] - _stored["explanations"][0][k]).abs().max()) for k in ["game", "sage", "predictions"]}\n    print("TRACE cell '+str(i)+':", _deltas)\n    if any(_deltas.values()):\n        t.save(prepared, output_dir / "mutated.pt")\n        raise ValueError("Native game mutated at cell '+str(i)+'")\n'
try:
 NotebookClient(n,timeout=600,kernel_name='python3',resources={'metadata':{'path':str(root)}}).execute(env={**os.environ,'CUDA_VISIBLE_DEVICES':'','OMP_NUM_THREADS':'4','MKL_NUM_THREADS':'4','ARENA_SAGE_OUTPUT_DIRECTORY':str(out/'figures')})
finally:nbformat.write(n,out/'trace.ipynb')

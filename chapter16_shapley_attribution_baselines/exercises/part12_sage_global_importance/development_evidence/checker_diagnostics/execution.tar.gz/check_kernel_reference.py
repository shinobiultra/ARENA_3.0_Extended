from pathlib import Path
import nbformat,os
from nbclient import NotebookClient
p=Path('/home/bitwise/.cache/arena_extended/sage');n=nbformat.v4.new_notebook()
n.cells=[nbformat.v4.new_code_cell('''import sys, torch as t, numpy as np, inspect
from pathlib import Path
sys.path.insert(0, '/home/bitwise/Documents/ARENA_3.0_Extended')
from chapter16_shapley_attribution_baselines.exercises.part12_sage_global_importance import sage_reference,sage_methods,sage_study
print(sys.executable, np.__version__, sage_reference.__file__)
t.set_num_threads(4)
a=t.load(next(Path('/home/bitwise/.cache/arena_extended/sage/own-full-v2/figures').glob('native-*/study/prepared.pt')),weights_only=True)
print(sage_reference.checks(a,sage_methods,sage_study.make_predictor(a['models'][0])))
''')]
try:NotebookClient(n,timeout=60,kernel_name='python3').execute(env={**os.environ,'CUDA_VISIBLE_DEVICES':'','OMP_NUM_THREADS':'4','MKL_NUM_THREADS':'4'})
finally:nbformat.write(n,p/'kernel_reference.ipynb')

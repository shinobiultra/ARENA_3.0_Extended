"""Audit the learner-facing course surface for extension chapters."""

from __future__ import annotations

import ast
import json
import re
import sys
from pathlib import Path
from typing import Any

import yaml


ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

CONFIG_PATH = ROOT / "infrastructure/core/config.yaml"
EXTENSION_ORIGINAL_SECTIONS = {"0.6", "1.6"}
REQUIRED_STREAMLIT_THEME_KEYS = {
    "primaryColor",
    "backgroundColor",
    "secondaryBackgroundColor",
    "textColor",
}
REQUIRED_INSTRUCTION_REQUIREMENTS = {
    "torch",
    "streamlit==1.45.0",
    "pyyaml",
}
REQUIRED_NOTEBOOK_VERIFICATION_STRINGS = (
    "def run_gpu_test(max_vram_gb: float = 24.0)",
    "def run_full_experiment(max_vram_gb: float = 24.0)",
)
REQUIRED_NOTEBOOK_EVIDENCE_SURFACES = (
    "verification_report.json",
    "run_gelu1l_signature_result",
    "prepare_gelu1l_state",
    "run_transformerlens_acdc_preflight",
)


def load_config(path: Path = CONFIG_PATH) -> dict[str, Any]:
    return yaml.safe_load(path.read_text())


def is_extension_section(number: str) -> bool:
    if number in EXTENSION_ORIGINAL_SECTIONS:
        return True
    try:
        return int(number.split(".", maxsplit=1)[0]) >= 5
    except ValueError:
        return False


def extension_chapter_names(config: dict[str, Any]) -> list[str]:
    chapter_names = config["chapter_names"]
    return [chapter_names[index] for index in sorted(chapter_names) if int(index) >= 5]


def _chapter_number_from_name(config: dict[str, Any], chapter_name: str) -> int:
    for number, name in config["chapter_names"].items():
        if name == chapter_name:
            return int(number)
    raise KeyError(chapter_name)


def _requirement_lines(path: Path) -> set[str]:
    return {
        line.strip()
        for line in path.read_text().splitlines()
        if line.strip() and not line.strip().startswith("#")
    }


def _page_has_arena_shape(text: str, number: str, title: str) -> bool:
    has_title = f"# [{number}] {title}" in text
    has_intro = re.search(r"^#{1,2}\s+(?:Introduction|Core Question)\s*$", text, re.M | re.I) is not None
    has_learning_objectives = re.search(r"^#{2,5}\s+(?:Content & )?Learning Objectives\s*$", text, re.M | re.I) is not None
    has_exercise = "Exercise" in text
    has_visible_test = "tests." in text or "run_smoke_test" in text
    has_runtime_contract = ("run_gpu_test" in text or "CUDA" in text or "GPU Contract" in text
                            or re.search(r"\bruns? on CPU\b", text) is not None
                            or re.search(r"REQUIRES_GPU\s*=\s*(?:True|False)\b", text) is not None)
    return all(
        [
            has_title,
            has_intro,
            has_learning_objectives,
            has_exercise,
            has_visible_test,
            has_runtime_contract,
        ]
    )


def _exercise_notebook_source(path: Path) -> str:
    notebook = json.loads(path.read_text())
    return "\n".join("".join(cell.get("source", [])) for cell in notebook.get("cells", []))


def _exercise_notebook_declares_verification_contract(path: Path) -> bool:
    source = _exercise_notebook_source(path)
    has_contract = all(required in source for required in REQUIRED_NOTEBOOK_VERIFICATION_STRINGS)
    has_evidence_surface = any(surface in source for surface in REQUIRED_NOTEBOOK_EVIDENCE_SURFACES)
    # Legacy interface detection is only a surface check, never scientific
    # acceptance. Modern lessons execute their methods and keep reports outside
    # the learning arc; their full executor supplies the verification interface.
    return (has_contract and has_evidence_surface) or _has_direct_experiment_contract(path)


def _has_direct_experiment_contract(path: Path) -> bool:
    """Recognize an own-answer lesson without requiring report-reading cells.

    Require actual exercise definitions/answers, calls to learner methods in
    experiment cells, generated figures, and a separate complete execution path.
    Source/output hashes and fresh CUDA evidence are checked by the report and
    section evidence audits, not inferred from this structural check.
    """
    here = path.parent
    required = [here / name for name in ("lesson.md", "execute_learner.py", "solutions.py")]
    if not all(file.is_file() for file in required):
        return False
    notebook = json.loads(path.read_text())
    cells = notebook.get("cells", [])
    markdown = "\n".join("".join(cell.get("source", [])) for cell in cells if cell.get("cell_type") == "markdown")
    try:
        trees = [ast.parse("".join(cell.get("source", []))) for cell in cells if cell.get("cell_type") == "code"]
        source_tree = ast.parse(required[2].read_text())
        executor_tree = ast.parse(required[1].read_text())
        answers = [ast.parse(code) for block in re.findall(r"<summary>Solution</summary>(.*?)</details>", markdown, re.S)
                   for code in re.findall(r"```python\s*\n(.*?)```", block, re.S)]
    except SyntaxError:
        return False
    definitions = (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)
    stubs = {node.name for tree in trees for node in tree.body if isinstance(node, definitions)
             and any(isinstance(child, ast.Raise) and "NotImplementedError" in ast.unparse(child)
                     for child in ast.walk(node))}
    answered = {node.name for tree in answers for node in tree.body if isinstance(node, definitions)}
    if len(stubs) < 3 or not stubs <= answered:
        return False
    # Exclude method definitions and test calls: a method must be used by a
    # visible experiment, rather than appear only in a stub or its own test.
    experiment_nodes = [node for tree in trees for node in tree.body if not isinstance(node, definitions)]
    calls = [node for outer in experiment_nodes for node in ast.walk(outer) if isinstance(node, ast.Call)]
    used = {node.func.id for node in calls if isinstance(node.func, ast.Name)} & stubs
    figures = any(isinstance(node.func, ast.Attribute) and node.func.attr == "savefig" for node in calls)
    # A visible figure helper is ordinary notebook plumbing. Follow its call
    # only when it saves the figure object passed by an experiment cell.
    called = {node.func.id for node in calls if isinstance(node.func, ast.Name)}
    for tree in trees:
        for node in tree.body:
            if isinstance(node, ast.FunctionDef) and node.name in called and node.args.args:
                figure_arg = node.args.args[0].arg
                figures |= any(
                    isinstance(item, ast.Call) and isinstance(item.func, ast.Attribute)
                    and item.func.attr == "savefig" and isinstance(item.func.value, ast.Name)
                    and item.func.value.id == figure_arg for item in ast.walk(node)
                )
                # A called pyplot helper can also save the active figure.
                # Follow its actual save operation, not its name or a comment.
                figures |= any(
                    isinstance(item, ast.Call) and isinstance(item.func, ast.Attribute)
                    and item.func.attr == "savefig"
                    and isinstance(item.func.value, ast.Call)
                    and isinstance(item.func.value.func, ast.Attribute)
                    and item.func.value.func.attr == "gcf"
                    and isinstance(item.func.value.func.value, ast.Name)
                    and item.func.value.func.value.id in {"plt", "pyplot"}
                    for item in ast.walk(node)
                )
    functions = {node.name: node for node in source_tree.body if isinstance(node, ast.FunctionDef)}
    if not {"run_gpu_test", "run_full_experiment"} <= functions.keys():
        return False
    full = ast.unparse(functions["run_full_experiment"])
    executor = ast.unparse(executor_tree)
    own_executor = ("complete_learner(" in executor and ".execute(" in executor
                    and "completed_from_own_answers" in executor)
    integrated_publication = "--publish" in executor and "execute_learner.py" in full
    # A separate publisher can validate and copy the exact completed learner.
    # Follow the GPU entry point's local imported orchestration module to check
    # that it runs the full executor and separate CUDA path; filenames alone
    # do not count as an execution/publication interface.
    separate_publisher = False
    for file in here.glob("publish_*.py"):
        try:
            publisher = ast.unparse(ast.parse(file.read_text()))
        except SyntaxError:
            continue
        if ("complete_learner(" in publisher and "validate_" in publisher
                and ".write_text(" in publisher and "completed_learner.ipynb" in publisher):
            separate_publisher = True
    delegated_execution = False
    for node in ast.walk(functions["run_gpu_test"]):
        if not isinstance(node, ast.ImportFrom) or not node.module:
            continue
        delegate_path = here / (node.module.rsplit(".", 1)[-1] + ".py")
        if not delegate_path.is_file():
            continue
        try:
            delegate = ast.unparse(ast.parse(delegate_path.read_text()))
        except SyntaxError:
            continue
        if ("execute_learner.py" in delegate and "subprocess.run(" in delegate
                and "--scope" in delegate and "full" in delegate and "cuda.py" in delegate):
            delegated_execution = True
        # A completed learner can be validated once and independently reproduced
        # without rerunning the entire learner inside every report command.
        imported_names = {alias.asname or alias.name: alias.name for alias in node.names}
        called_names = {call.func.id for call in ast.walk(functions["run_gpu_test"])
                        if isinstance(call, ast.Call) and isinstance(call.func, ast.Name)}
        delegate_functions = {item.name: item for item in ast.parse(delegate_path.read_text()).body
                              if isinstance(item, ast.FunctionDef)}
        for local_name, remote_name in imported_names.items():
            if local_name not in called_names or remote_name not in delegate_functions:
                continue
            fresh_calls = [call for call in ast.walk(delegate_functions[remote_name]) if isinstance(call, ast.Call)]
            fresh_names = {call.func.id for call in fresh_calls if isinstance(call.func, ast.Name)}
            loads_model = any(isinstance(call.func, ast.Attribute) and call.func.attr == "from_pretrained"
                              and isinstance(call.func.value, ast.Name) and call.func.value.id == "AutoModelForCausalLM"
                              for call in fresh_calls)
            native_measurements = ("measure_calendar_replacements" in fresh_names
                                   or {"capture_rows", "replace_rows", "fit_candidates"} <= fresh_names)
            # A frozen-alignment study validates saved bases and reruns its
            # own visible intervention and continuation, checking independent
            # full-forward hooks rather than refitting CCA maps.
            invoked_methods = {
                call.func.slice.value for call in fresh_calls
                if isinstance(call.func, ast.Subscript)
                and isinstance(call.func.value, ast.Name)
                and call.func.value.id == "methods"
                and isinstance(call.func.slice, ast.Constant)
                and isinstance(call.func.slice.value, str)
            }
            native_measurements |= (
                {"capture_native", "full_forward_intervention"} <= fresh_names
                and {"subspace_interchange", "continue_native"} <= invoked_methods
            )
            # Concept erasure refits maps and probes before a separate native
            # inference helper. Follow those called helpers; filenames and a
            # loaded checkpoint alone are not an experiment contract.
            fit_node = delegate_functions.get("construct_conditions")
            infer_node = delegate_functions.get("infer")
            edit_node = delegate_functions.get("edit")
            if fit_node is not None and infer_node is not None and edit_node is not None:
                fit_attributes = {
                    call.func.attr for call in ast.walk(fit_node)
                    if isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute)
                    and isinstance(call.func.value, ast.Name) and call.func.value.id == "m"
                }
                infer_names = {
                    call.func.id for call in ast.walk(infer_node)
                    if isinstance(call, ast.Call) and isinstance(call.func, ast.Name)
                }
                edit_attributes = {
                    call.func.attr for call in ast.walk(edit_node)
                    if isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute)
                    and isinstance(call.func.value, ast.Name) and call.func.value.id == "m"
                }
                native_measurements |= (
                    {"capture_native", "full_forward_intervention", "construct_conditions",
                     "compare_fitted_conditions", "infer"} <= fresh_names
                    and {"fit_leace", "fit_binary_probe", "fit_orthogonal_eraser"} <= fit_attributes
                    and {"edit", "continue_native"} <= infer_names
                    and {"apply_eraser", "matched_random_edit"} <= edit_attributes
                )
            if loads_model and "validate_learner" in fresh_names and native_measurements:
                delegated_execution = True
            # CCS reloads through token-capture plumbing and refits through
            # provided control orchestration. Inspect those actual called
            # functions as well as the fresh entry point.
            if _has_ccs_native_refit_contract(here, delegate_functions[remote_name], fresh_names):
                delegated_execution = True
            if _has_data_attribution_refit_contract(here, fresh_names):
                delegated_execution = True
            if _has_datamodel_refit_contract(here, fresh_names):
                delegated_execution = True
            if _has_cartography_refit_contract(here, fresh_names):
                delegated_execution = True
            if _has_sage_refit_contract(here, fresh_names):
                delegated_execution = True
    return (len(used) >= 3 and figures and own_executor and "run_gpu_test(" in full
            and (integrated_publication or (separate_publisher and delegated_execution)))


def _has_sage_refit_contract(here: Path, fresh_names: set[str]) -> bool:
    """Require actual native model training, performance games and independent checks."""
    if not {"run", "compare"} <= fresh_names:
        return False
    requirements = {
        "run_native.py": {"run": {"validate_freeze", "sage_data.load_split",
            "sage_study.prepare_study", "sage_study.evaluate_study", "sage_study.diagnostics",
            "sage_study.native_play", "sage_reference.checks"}},
        "sage_data.py": {"load_split": {"source_data"}},
        "sage_methods.py": {
            "marginal_predict": {"t.where", "model"},
            "loss_game": {"(predictions - y[:, None]).square"},
            "exact_shapley": {"math.comb"},
            "gaussian_game": {"t.linalg.pinv", "t.einsum"},
            "permutation_sage": {"marginal_predict", "path_contributions", "t.cat"},
            "summarize_paths": {"math.sqrt"},
        },
        "sage_study.py": {
            "fit_models": {"t.nn.Linear", "t.optim.Adam", "loss.backward", "optimizer.step", "t.linalg.solve"},
            "prepare_study": {"fit_models", "methods.coalition_predictions", "explain_predictions", "t.argsort", "t.save"},
            "explain_predictions": {"methods.loss_game", "methods.exact_shapley"},
            "evaluate_study": {"methods.coalition_predictions", "methods.prefix_values"},
            "diagnostics": {"methods.permutation_sage", "methods.table_path_contributions", "methods.summarize_paths"},
            "native_play": {"methods.coalition_predictions", "explain_predictions"},
        },
        "sage_reference.py": {
            "checks": {"permutation_reference", "np.linalg.lstsq", "np.testing.assert_allclose", "author_imputer"},
            "permutation_reference": {"itertools.permutations", "np.bitwise_or", "np.testing.assert_allclose"},
        },
    }
    for filename, functions in requirements.items():
        try:
            nodes = {node.name: node for node in ast.parse((here / filename).read_text()).body
                     if isinstance(node, ast.FunctionDef)}
        except (OSError, SyntaxError):
            return False
        for name, required in functions.items():
            if name not in nodes:
                return False
            calls = {ast.unparse(node.func) for node in ast.walk(nodes[name]) if isinstance(node, ast.Call)}
            if not required <= calls:
                return False
    return True


def _has_cartography_refit_contract(here: Path, fresh_names: set[str]) -> bool:
    """Follow actual SGD traces, data selection, held-out evaluation and reproduction."""
    if not {"run", "compare"} <= fresh_names:
        return False
    requirements = {
        "run_native.py": {
            "run": {"validate_freeze", "load_training", "map_training_data", "retrain_selections",
                    "load_evaluation", "evaluate_study", "retraining_play", "reference_checks"},
            "reference_checks": {"implementation.train_ensemble", "np.exp",
                                 "np.testing.assert_allclose", "torch.testing.assert_close"},
        },
        "cartography_data.py": {
            "load_training": {"source_arrays", "training_rows", "make_split"},
            "load_evaluation": {"source_arrays", "make_split"},
        },
        "cartography_methods.py": {
            "training_statistics": {"gold_probabilities", "probabilities.mean", "probabilities.std"},
            "train_ensemble": {"initialize_parameters", "batched_logits", "F.cross_entropy",
                               "torch.autograd.grad", "align_epoch", "value.add_"},
            "evaluate_models": {"batched_logits", "F.cross_entropy"},
        },
        "cartography_study.py": {
            "map_training_data": {"methods.train_ensemble", "methods.training_statistics", "methods.retrieval_curve"},
            "make_selections": {"methods.select_indices", "methods.matched_random_indices", "torch.randperm"},
            "retrain_selections": {"make_selections", "methods.train_ensemble", "torch.save"},
            "evaluate_study": {"methods.evaluate_models"},
            "retraining_play": {"methods.select_indices", "methods.matched_random_indices",
                                "methods.train_ensemble", "methods.evaluate_models"},
        },
        "cartography_reference.py": {
            "standard_training": {"torch.optim.SGD", "model", "optimizer.step", "F.cross_entropy"},
        },
    }
    for filename, functions in requirements.items():
        try:
            nodes = {node.name: node for node in ast.parse((here / filename).read_text()).body
                     if isinstance(node, ast.FunctionDef)}
        except (OSError, SyntaxError):
            return False
        for name, required in functions.items():
            if name not in nodes:
                return False
            calls = {ast.unparse(node.func) for node in ast.walk(nodes[name]) if isinstance(node, ast.Call)}
            if not required <= calls:
                return False
    return True


def _has_datamodel_refit_contract(here: Path, fresh_names: set[str]) -> bool:
    """Follow subset training, validation, frozen interventions and full comparison."""
    if not {"run", "compare"} <= fresh_names:
        return False
    requirements = {
        "run_native.py": {
            "run": {"load_data", "data_manifest", "study.make_designs", "study.prepare_study",
                    "study.evaluate_study", "study.deletion_play", "reference_checks"},
            "reference_checks": {"study.refit_masks", "scipy_logistic_optimum", "Lasso", "independent.predict"},
        },
        "datamodel_data.py": {"load_data": {"source_arrays"}},
        "datamodel_methods.py": {
            "fit_datamodel_path": {"fit_lasso"},
            "fit_lasso": {"soft_threshold", "lasso_kkt"},
        },
        "datamodel_study.py": {
            "make_designs": {"methods.sample_subsets"},
            "refit_masks": {"fit_weighted_logistic"},
            "model_margins": {"methods.correct_class_margins"},
            "fit_response_models": {"methods.fit_datamodel_path", "least_squares_datamodel"},
            "build_deletion_masks": {"methods.select_supportive", "methods.matched_random_removals"},
            "prepare_study": {"refit_masks", "model_margins", "fit_response_models", "build_deletion_masks"},
            "evaluate_study": {"refit_masks", "model_margins", "response_predictions"},
            "deletion_play": {"methods.select_supportive", "methods.matched_random_removals",
                              "refit_masks", "model_margins"},
        },
    }
    for filename, functions in requirements.items():
        try:
            nodes = {node.name: node for node in ast.parse((here / filename).read_text()).body
                     if isinstance(node, ast.FunctionDef)}
        except (OSError, SyntaxError):
            return False
        for name, required in functions.items():
            if name not in nodes:
                return False
            calls = {ast.unparse(node.func) for node in ast.walk(nodes[name]) if isinstance(node, ast.Call)}
            if not required <= calls:
                return False
            if filename == "run_native.py" and name == "reference_checks":
                fitted_lasso = any(
                    isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                    and node.func.attr == "fit" and isinstance(node.func.value, ast.Call)
                    and isinstance(node.func.value.func, ast.Name)
                    and node.func.value.func.id == "Lasso"
                    for node in ast.walk(nodes[name])
                )
                if not fitted_lasso:
                    return False
    return True


def _has_data_attribution_refit_contract(here: Path, fresh_names: set[str]) -> bool:
    """Follow actual scratch-model fitting, counterfactuals and comparisons.

    A pretrained-model loader is not part of a from-scratch digit experiment.
    Require its complete data/refit/evaluation path instead. This recognizes
    structure; source hashes and numerical reproduction remain separate gates.
    """
    if not {"load_study_data", "data_manifest", "prepare_study", "evaluate_final",
            "query_deletion_play", "compare", "scipy_logistic_optimum"} <= fresh_names:
        return False
    requirements = {
        "attribution_study.py": {
            "prepare_study": {"fit_condition"},
            "fit_condition": {"m.fit_weighted_logistic", "m.sgd_trace", "score_queries",
                              "m.class_matched_removals", "m.conjugate_gradient", "m.logistic_hvp"},
            "score_queries": {"query_outputs", "m.upweight_influence",
                              "m.trace_loss_reductions", "checkpoint_analysis"},
            "checkpoint_analysis": {"m.tracin_checkpoint_scores", "m.ghost_linear_products",
                                    "torch.testing.assert_close"},
            "evaluate_final": {"score_queries", "query_outputs"},
        },
        "attribution_data.py": {
            "load_study_data": {"source_arrays"},
            "source_arrays": {"sha256", "zipfile.ZipFile", "np.loadtxt"},
        },
        "attribution_play.py": {
            "query_deletion_play": {"m.upweight_influence", "m.class_matched_removals",
                                    "m.fit_weighted_logistic"},
        },
    }
    for filename, functions in requirements.items():
        try:
            nodes = {node.name: node for node in ast.parse((here / filename).read_text()).body
                     if isinstance(node, ast.FunctionDef)}
        except (OSError, SyntaxError):
            return False
        for name, required in functions.items():
            if name not in nodes:
                return False
            calls = {ast.unparse(call.func) for call in ast.walk(nodes[name]) if isinstance(call, ast.Call)}
            if not required <= calls:
                return False
    return True


def _has_ccs_native_refit_contract(here: Path, fresh_node: ast.FunctionDef, names: set[str]) -> bool:
    """Structural coverage only; execution and artifact hashes have separate gates."""
    if not {"validate_learner", "compare_nested", "validate_complete_result"} <= names:
        return False

    def calls(node):
        return {ast.unparse(item.func) for item in ast.walk(node) if isinstance(item, ast.Call)}

    if not {"native.load_model", "native.check_capture", "native.capture_pairs", "native.weight_digest",
            "study.fit_reporters", "study.calibrate_reporters", "study.reporter_scores",
            "study.evaluate_reporters", "study.summarize_native_outputs"} <= calls(fresh_node):
        return False
    try:
        native_tree = ast.parse((here / "ccs_native.py").read_text())
        study_tree = ast.parse((here / "ccs_study.py").read_text())
    except (OSError, SyntaxError):
        return False
    native = {node.name: node for node in native_tree.body if isinstance(node, ast.FunctionDef)}
    study = {node.name: node for node in study_tree.body if isinstance(node, ast.FunctionDef)}
    requirements = [
        (native, "load_model", {"AutoModelForCausalLM.from_pretrained"}),
        (native, "capture_pairs", {"capture_texts"}),
        (native, "capture_texts", {"model.transformer", "model.lm_head", "gather"}),
        (native, "check_capture", {"model", "capture_texts", "torch.testing.assert_close"}),
        (study, "fit_reporters", {"m.fit_pair_centering", "m.apply_pair_centering", "m.fit_ccs_restarts",
                                  "m.select_restart", "m.fit_difference_pca", "fit_binary_probe", "torch.randn"}),
        (study, "calibrate_reporters", {"reporter_scores", "m.calibrate_orientation"}),
        (study, "reporter_scores", {"m.apply_pair_centering", "m.paired_probabilities"}),
        (study, "evaluate_reporters", {"m.binary_metrics", "nm.paired_opinion_change"}),
        (study, "summarize_native_outputs", {"nm.model_answer_metrics"}),
    ]
    return all(name in functions and required <= calls(functions[name])
               for functions, name, required in requirements)


def chapter_surface_blockers(config: dict[str, Any], chapter_name: str) -> list[str]:
    chapter_dir = ROOT / chapter_name
    instructions_dir = chapter_dir / "instructions"
    blockers: list[str] = []

    home_path = instructions_dir / "Home.py"
    if not home_path.exists():
        blockers.append(f"{chapter_name}: missing instructions/Home.py")
    elif "render_extension_home(__file__)" not in home_path.read_text():
        blockers.append(f"{chapter_name}: Home.py does not use shared extension renderer")

    config_path = instructions_dir / ".streamlit/config.toml"
    if not config_path.exists():
        blockers.append(f"{chapter_name}: missing instructions/.streamlit/config.toml")
    else:
        config_text = config_path.read_text()
        if "[theme]" not in config_text:
            blockers.append(f"{chapter_name}: streamlit config missing [theme]")
        for key in REQUIRED_STREAMLIT_THEME_KEYS:
            if key not in config_text:
                blockers.append(f"{chapter_name}: streamlit config missing {key}")

    requirements_path = instructions_dir / "requirements.txt"
    if not requirements_path.exists():
        blockers.append(f"{chapter_name}: missing instructions/requirements.txt")
    else:
        missing = REQUIRED_INSTRUCTION_REQUIREMENTS - _requirement_lines(requirements_path)
        if missing:
            blockers.append(f"{chapter_name}: instruction requirements missing {sorted(missing)}")

    return blockers


def section_surface_blockers(
    config: dict[str, Any],
    chapter_name: str,
    section: dict[str, Any],
) -> list[str]:
    chapter_dir = ROOT / chapter_name
    number = str(section.get("number", ""))
    title = str(section.get("title", ""))
    blockers: list[str] = []

    conversion = config["conversion_map"].get(number)
    if conversion is None:
        blockers.append(f"{number}: missing conversion_map entry")
        return blockers
    if conversion.get("exercise_dir") != section.get("exercise_dir"):
        blockers.append(f"{number}: conversion_map exercise_dir mismatch")
    expected_page = f"{conversion.get('streamlit_page')}.md"
    if expected_page != section.get("page_file"):
        blockers.append(f"{number}: conversion_map streamlit_page does not match page_file")

    page_path = chapter_dir / "instructions/pages" / str(section.get("page_file", ""))
    if not page_path.exists():
        blockers.append(f"{number}: missing instruction page {page_path.relative_to(ROOT)}")
    elif not _page_has_arena_shape(page_path.read_text(), number, title):
        blockers.append(f"{number}: instruction page lacks ARENA-style learner surface")

    exercise_dir = chapter_dir / "exercises" / str(section.get("exercise_dir", ""))
    if not exercise_dir.exists():
        blockers.append(f"{number}: missing exercise dir {exercise_dir.relative_to(ROOT)}")
    for required in ("README.md", "solutions.py", "tests.py", "verification_report.json"):
        required_path = exercise_dir / required
        if not required_path.exists():
            blockers.append(f"{number}: missing {required_path.relative_to(ROOT)}")

    solutions_path = exercise_dir / "solutions.py"
    if solutions_path.exists() and "def run_gpu_test" in solutions_path.read_text():
        exercise_notebooks = sorted(exercise_dir.glob("*_exercises.ipynb"))
        if not exercise_notebooks:
            blockers.append(f"{number}: missing exercise notebook with verification contract")
        else:
            for notebook_path in exercise_notebooks:
                try:
                    has_contract = _exercise_notebook_declares_verification_contract(notebook_path)
                except json.JSONDecodeError as exc:
                    blockers.append(
                        f"{number}: invalid notebook JSON in {notebook_path.relative_to(ROOT)}: {exc}"
                    )
                    continue
                if not has_contract:
                    blockers.append(
                        f"{number}: exercise notebook lacks a complete learner execution or GPU/full verification surface"
                    )

    return blockers


def course_surface_blockers(config: dict[str, Any] | None = None) -> list[str]:
    config = config or load_config()
    blockers: list[str] = []

    for chapter_name in extension_chapter_names(config):
        blockers.extend(chapter_surface_blockers(config, chapter_name))

    for chapter_name, chapter in config["chapters"].items():
        for section in chapter.get("sections", []):
            number = str(section.get("number", ""))
            if is_extension_section(number):
                blockers.extend(section_surface_blockers(config, chapter_name, section))

    return blockers


def main() -> None:
    blockers = course_surface_blockers()
    print(f"extension_chapters_checked={len(extension_chapter_names(load_config()))}")
    print(f"course_surface_blockers={len(blockers)}")
    if blockers:
        print("COURSE_SURFACE=FAIL")
        for blocker in blockers:
            print(f"- {blocker}")
        raise SystemExit(1)
    print("COURSE_SURFACE=PASS")


if __name__ == "__main__":
    main()

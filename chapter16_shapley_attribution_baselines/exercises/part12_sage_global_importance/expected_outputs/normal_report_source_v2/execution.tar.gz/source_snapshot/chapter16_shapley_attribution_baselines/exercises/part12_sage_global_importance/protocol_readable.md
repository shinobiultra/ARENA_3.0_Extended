# SAGE concrete-regression experiment — frozen before native fitting

Question: which inputs reduce a fixed model's squared prediction error, and how does the answer differ from
explaining its output? Conditional SAGE is derived and checked on analytic Gaussian distributions. The
real-data experiment uses the paper's practical marginal convention with a finite empirical training
background. Its all-coalition values are exact for that finite game, not for the unknown conditional data
distribution or population.

Data: official UCI 165 CSV, SHA256 8d4b15b6fc68cd932d745cbd663d5ceae66dd54422e99c1e4865f2936ab7e2af. Keep all
1030 rows, including replicates. Group identical seven-ingredient recipes, ignoring age, by the frozen
manifest rule: 427 groups; train 298 groups/758 rows, explanation 64/153, untouched audit 65/119. Source
experiment/laboratory IDs are unavailable; grouping does not establish independence of laboratories or
individual measurements. Record duplicates; never collapse conflicting repeated outcomes.

Preprocessing: input mean and population standard deviation from 758 training rows only; no logarithms,
learned features or clipping. Target mean/population SD from training only. All native regressors use eight
standardized inputs and standardized target during optimization; displayed predictions and losses use MPa and
MPa². Row-weighted primary importance. A recipe-equal-weight explanation is a predeclared sensitivity
analysis, not a replacement primary result.

Models: six newly initialized CPU float64 networks, three clean and three shuffled-target controls.
Architecture 8→32 ReLU→32 ReLU→1. torch.nn.Linear default initialization with manual seeds
161210,161211,161212; reset the same seed for each clean/shuffled pair. For each shuffled model, independently
permute training targets using NumPy default_rng(161220+seed_index); retain chance coincidences. Full-batch
Adam, 800 updates, learning rate .003, weight_decay .0001 on all parameters, standard default betas/epsilon;
MSE loss; no early stopping, validation selection or restarts. CPU four threads. Save initial/final parameters
and all training losses. Also fit one visible ridge baseline to standardized data with intercept and ridge .01
on feature coefficients (not intercept), using mean squared-error normal equations. No native model fits have
occurred at freezing.

Background: source training rows sorted by SHA256(arena16.12/background/{seed}/{row_id}), with fixed seeds
161260,161261,161262. Primary background first64 rows of seed161260. Primary-size sensitivity uses
nested16/64/128. Independent-background sensitivity uses first64 rows of the other two orders. All removed
coordinates come from one intact background row per hybrid; retain dependence within the removed block.
Predict each hybrid, average predictions, then square error. Mean imputation is a separate control. Never
average losses across imputed samples and call it SAGE.

Primary study: every one of 256 coalitions for all 153 explanation and 119 audit rows for each of seven fitted
models. Compute exact Shapley by subset weights, local prediction Shapley, local loss Shapley, mean/mean
absolute prediction attributions, leave-one-feature-out and singleton predictive power. For clean seed0
compute explanation tables under additional nested16/128, two independent64 backgrounds and mean-imputation
control. Also explanation outcome permutation seed161270 (same trained model, changes evaluation game). Show
all six neural runs and ridge, not a best seed.

Selection/evaluation boundary: compute feature rankings using explanation split only, then persist rankings
and final models before loading audit split in the runner. For every model, compare its own explanation-SAGE
descending/ascending and leave-one-out descending ranking with 100 random orders from NumPy
default_rng(161280). Evaluate remaining-feature prefix curves using audit coalition tables, no retraining,
with all eight features as common endpoint and empty background-mean prediction as common origin. These are
fixed restricted-model curves, not optimal retrained subset performance. Report all sizes and seed variation.
Audit SAGE is descriptive stability evidence, not a ranking selection input.

Sampling: implement direct Algorithm-1-style outer row/permutation sampling, marginal predictions from the
fixed64-row background. First implementation uses a supplied row schedule and permutation matrix, then
compares against cached coalition-table paths and the official author imputer. Main direct run 4096 paths,
random row schedule/default_rng161290 and independent row-wise feature permutations from the same generator;
batch256. No adaptive stop. Repeated cheap table-based runs: 32 independent schedules, seeds161300..161331,
prefix budgets32/128/512/2048/8192, each chooses explanation rows uniformly with replacement and uniform
feature permutations. Compare empirical RMSE/SE with exact global values; uncertainty is outer sampling
conditional on fixed model, explanation dataset and background. Separately show between-background and
between-model changes. Do not label those changes covered by outer SE.

Additional derivations/controls: exact Gaussian conditional and marginal games with zero-mean features,
coefficients truth=[1,0], model=[1,0], rho in 0..1; then truth=[1,0], model=[1,bad_weight] at rho=0 to reveal
negative importance. Bayes-optimal nonnegativity and universal predictive power apply only to the analytic
optimum. Exact XOR loss game shows interaction allocation and failure of singleton/leave-one-out baselines.
Nonlinear inner-averaging example shows squared-error variance/m bias with a fixed target; increased outer
iterations cannot remove this error. Append ignored ninth feature in a model wrapper and verify dummy
importance zero. Native coalition assumptions checked with input correlation and train-distance comparisons of
original versus hybrid recipes; distance is a diagnostic, not proof of conditional plausibility.

Plays: analytic correlation/wrong-weight sliders via editable parameters; actual native held-out
row/feature/background selection recomputes hybrid predictions and local prediction/loss explanations. Default
first audit row by source id, primary background64, clean seed0. No model retraining or test-based parameter
selection in plays. Exploratory reuse is labeled.

Independent checks: all40320 feature permutations on an actual native global game, constrained
weighted-regression Shapley solution, NumPy forward pass on actual trained network, author MarginalImputer at
commit0e34e6c7e2a6b1666e39043e83b9929e68ee68f3 on fixed actual native inputs/masks, small analytic Gaussian
and averaging controls. Fresh complete CPU retraining compared with actual own-answer notebook payloads,
rtol=1e-7/atol=1e-8 for floats; exact shape, dtype, identities, masks and integers. Native comparisons retain
all outputs, not only plots or aggregate metrics.

Outcome policy: no label/seed/background/model/recipe exclusion or training change based on native results. If
implementation errors occur, preserve the attempt and state the correction. Plot disagreements and
negative/weak controls honestly. This is a method study on a small tabular neural regressor, not the paper's
complete benchmark, a material-design recommendation, a causal effect estimate, or an intrinsic universal
feature ranking.

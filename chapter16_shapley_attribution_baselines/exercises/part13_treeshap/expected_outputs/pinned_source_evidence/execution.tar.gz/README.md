# Pinned primary evidence

The three unmodified SHAP source files are copied from the installed 0.49.1
wheel and bound by author_reference.json. SHAP_LICENSE retains their MIT notice.
The public UCI concrete CSV is byte-pinned under CC BY4.0 (Yeh, DOI10.24432/C5PK67).
The original article PDF remains in the persistent research cache, with its exact
SHA256 in author_reference.json; it is not repackaged into this course archive.

Primary paper: https://arxiv.org/abs/1802.03888 .
Official API: https://shap.readthedocs.io/en/latest/generated/shap.TreeExplainer.html .
The separate numerical reference correction is documented in the learner and
reference_boundary_addendum.md; these primary sources are unmodified.

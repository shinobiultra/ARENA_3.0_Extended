# Independent TreeSHAP methods and study review — 2026-09-06

Status: **PASS after the float32-routing repair, with reporting limitations below.** This reviewer made no canonical repository edits.

## Scope and primary references

Reviewed `treeshap_methods.py`, `treeshap_methods_tests.py`, `treeshap_study.py`, `protocol.md`, `protocol_freeze.json`, `data_manifest.json`, and `docs/arena_salvage/2026-09-06_treeshap_next_plan.md`. Checked Lundberg, Erion & Lee Section 3 and Algorithms 1–2 in the pinned paper and the pinned SHAP 0.49.1 Python/C++ sources. All paper/source hashes match `author_reference.json`; all three frozen protocol hashes match `protocol_freeze.json`.

## Correctness evidence

- The extend/unwind recurrence, repeated-feature removal, leaf contraction, cover-weighted absence, paired-donor absence, ensemble linearity, offsets, signed tree weights, and Saabas expectation differences agree with the paper algorithm and the explicit games implemented here.
- Immediate suite: `9 passed` with `.venv/bin/python -m pytest -q .../treeshap_methods_tests.py`.
- Mutation check: removing the float32-to-float64 promotion from `tree_shap` makes the new `10.099999904632568` / `10.1` boundary regression fail with `phi=[-10, 0]` instead of `[0, 0]`.
- Cached `forest_clean_0`, all 32 component trees, five rows including the original source-row 139/162 failures: dynamic program versus all 256 path coalitions max absolute error `2.842170943040401e-14`; paired-donor dynamic program versus explicit hybrids max absolute error `4.973799150320701e-14`.
- Independent randomized stress test: 200 balanced trees, depths 1–6, 1–5 supplied features, repeated features, extreme positive cover ratios, paired donors, and float32 boundary values. Maximum path-oracle error `1.3322676295501878e-15`; maximum donor-oracle error `8.881784197001252e-16`.
- The preserved first native run at `native-dev-v1/state.json` correctly remains FAIL: path additivity differed by `0.4902010869565` MPa on two forest rows because NumPy 1.26 rounded a float64 scalar threshold during float32 array/scalar comparison. With inputs first rounded to float32 and then promoted to float64, cached forest prediction parity is exact and path additivity error is at most `1.4210854715202004e-14`.
- The repaired fresh run at `native-dev-v2/state.json` is PASS after 18 fits. Its prepared rankings use exactly the 153 explanation IDs; its audit uses exactly the disjoint 119 audit IDs; the 64-row primary background is an exact frozen training-ID selection. Exact-game endpoints, deletion indexing/MSEs, all 100 distinct random orders, and nested 16/64/128 backgrounds were independently checked.
- The manifest was independently regenerated from the stated two-stage recipe digest and salted group ordering. It contains all 1,030 rows exactly once, with 298/64/65 mutually disjoint recipe groups and 758/153/119 rows.

## SHAP 0.49.1 interventional-reference correction

The compiled independent path stores each split threshold in `Node.thres` as C++ `float`, although sklearn stores the learned threshold as float64 and routes float32 inputs against that original float64 value. For any finite float32 query coordinate `q`,

`q <= t64` if and only if `q <= floor_F32(t64)`,

where `floor_F32` is the greatest representable float32 value no greater than `t64`. Applying this correction to a deep-copied reference model therefore preserves sklearn's partition for every finite input on the float32 lattice. Across all 5,480 internal nodes from the frozen 18 models, 941 thresholds round upward under ordinary float32 conversion. Ordinary float thresholds caused 217 routing disagreements over all 1,030 source rows; the all-threshold floor correction caused zero.

Preserve both raw and corrected SHAP comparisons. Describe the corrected result as parity after a documented SHAP 0.49.1 reference workaround. The proof does not cover NaN/default-branch or categorical routing; neither occurs in this study. Keep the actual fitted models unchanged, and apply the correction only to a deep copy used for reference comparison.

## Scientific and reporting limitations

- Clean DecisionTree and GradientBoosting fits at the three nominal seeds are numerical duplicates (maximum training-prediction differences about `3.6e-14` and `1.4e-14`). Do not interpret those repeated clean fits as independent stability replicates or use them for uncertainty bars. Forest seeds do produce distinct fits.
- `boost_shuffled_0` audit MSE is `244.29690126873754`, slightly below the training-mean baseline `244.67938059553117` by chance, while clean boost is `58.19406121254112`. State that shuffled controls collapse near baseline and fail relative to clean models; do not claim every shuffled fit is worse than the mean baseline.
- Path, interventional, and Saabas explanation-split global rankings are identical for `forest_clean_0` and `boost_clean_0`, so their audit deletion curves are identical. The real deletion result separates the ordered methods from random controls but cannot distinguish the three attribution methods. Use the correlated/order tiny controls or local attribution displays for that distinction, and report the real global agreement honestly.
- Audit deletion is a diagnostic of the fitted model and empirical donor game. It is not a causal ingredient intervention, and row-averaged errors give larger recipe groups more weight. The frozen protocol already disclaims causality and unavailable laboratory identities.

No new method, paper, or course topic was introduced. Original ARENA content was not modified.

## Reproducible evidence package

- `evidence/randomized200_tree_oracle_check.py` (`08a70deadbed08c684f46b634fd411d4bb79ef00a8fcf8d0f69b617b23f72826`) and its captured `evidence/randomized200_tree_oracle_check.result.json` (`7829951958b02e0d93d4dd3231f9b393c2b47ae01972807e54ba5d28c5b3b96e`).
- `evidence/all_threshold_floor_check.py` (`03fc3a9473459405fff6ff1b7487f8cfba21ff34ba11d2052e344fc54b60f8ff`) and its captured `evidence/all_threshold_floor_check.result.json` (`782500846520fed6b5a002a06d87891ca6e102a60ea79d297168d558c8f42a7e`).

Both scripts were rerun after capture with exit code 0. Parsed fresh output matched the saved JSON exactly after removing only the fresh `run_utc` field.

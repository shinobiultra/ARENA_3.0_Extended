#!/usr/bin/env python3
"""Reproduce the independent randomized TreeSHAP/exhaustive-oracle check."""

from __future__ import annotations

import hashlib
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

import numpy as np


ROOT = Path("/home/bitwise/Documents/ARENA_3.0_Extended")
METHODS_PATH = ROOT / "chapter16_shapley_attribution_baselines/exercises/part13_treeshap/treeshap_methods.py"
sys.path.insert(0, str(ROOT))

from chapter16_shapley_attribution_baselines.exercises.part13_treeshap.treeshap_methods import (  # noqa: E402
    coalition_masks,
    exact_shapley,
    tree_path_game,
    tree_predict,
    tree_shap,
)


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    seed = 930142
    cases = 200
    rng = np.random.default_rng(seed)
    max_path = 0.0
    max_donor = 0.0
    worst_path = None
    worst_donor = None
    failures = []

    for case in range(cases):
        depth = int(rng.integers(1, 7))
        d = int(rng.integers(1, min(6, depth + 2)))
        node_count = 2 ** (depth + 1) - 1
        leaves = np.arange(2**depth - 1, node_count)

        left = np.full(node_count, -1, dtype=int)
        right = np.full(node_count, -1, dtype=int)
        for node in range(2**depth - 1):
            left[node] = 2 * node + 1
            right[node] = 2 * node + 2

        feature = np.full(node_count, -1, dtype=int)
        feature[: 2**depth - 1] = rng.integers(0, d, 2**depth - 1)
        threshold = np.zeros(node_count, dtype=float)
        threshold[: 2**depth - 1] = rng.normal(size=2**depth - 1)
        if case % 5 == 0:
            threshold[int(rng.integers(0, 2**depth - 1))] = 10.099999904632568

        value = np.zeros(node_count, dtype=float)
        value[leaves] = rng.normal(size=len(leaves))
        cover = np.zeros(node_count, dtype=float)
        cover[leaves] = 10 ** rng.uniform(-2, 2, len(leaves))
        for node in range(2**depth - 2, -1, -1):
            cover[node] = cover[left[node]] + cover[right[node]]
            value[node] = (
                cover[left[node]] * value[left[node]]
                + cover[right[node]] * value[right[node]]
            ) / cover[node]

        tree = {
            "left": left,
            "right": right,
            "feature": feature,
            "threshold": threshold,
            "value": value,
            "cover": cover,
        }
        x = rng.normal(size=(4, d))
        donor = rng.normal(size=(4, d))
        if case % 5 == 0:
            x[0] = 10.1
            donor[1] = 10.1
        masks = coalition_masks(d)

        path_actual = tree_shap(tree, x)
        path_expected = exact_shapley(tree_path_game(tree, x, masks))
        path_error = float(np.max(np.abs(path_actual - path_expected)))

        paired_games = np.array(
            [
                tree_predict(tree, np.where(masks, row, background))
                for row, background in zip(x, donor, strict=True)
            ]
        )
        donor_actual = tree_shap(tree, x, donor)
        donor_expected = exact_shapley(paired_games)
        donor_error = float(np.max(np.abs(donor_actual - donor_expected)))

        case_record = {
            "case": case,
            "depth": depth,
            "features": d,
            "max_abs_error": path_error,
        }
        if path_error > max_path:
            max_path = path_error
            worst_path = case_record
        if donor_error > max_donor:
            max_donor = donor_error
            worst_donor = {**case_record, "max_abs_error": donor_error}
        if not np.allclose(path_actual, path_expected, atol=2e-10, rtol=2e-10):
            failures.append({**case_record, "game": "path"})
        if not np.allclose(donor_actual, donor_expected, atol=2e-10, rtol=2e-10):
            failures.append({"case": case, "depth": depth, "features": d, "max_abs_error": donor_error, "game": "paired_donor"})

    result = {
        "status": "PASS" if not failures else "FAIL",
        "run_utc": datetime.now(timezone.utc).isoformat(),
        "provenance": {
            "script": str(Path(__file__).resolve()),
            "methods": str(METHODS_PATH),
            "methods_sha256": sha256(METHODS_PATH),
            "python": platform.python_version(),
            "numpy": np.__version__,
        },
        "design": {
            "rng_seed": seed,
            "cases": cases,
            "queries_per_case": 4,
            "depth_inclusive": [1, 6],
            "maximum_supplied_features": 5,
            "cover_leaf_log10_range": [-2, 2],
            "float32_boundary_injected_every_n_cases": 5,
            "oracle": "all coalitions, path game and explicit paired-donor hybrids",
            "atol": 2e-10,
            "rtol": 2e-10,
        },
        "results": {
            "maximum_path_absolute_error": max_path,
            "maximum_paired_donor_absolute_error": max_donor,
            "worst_path_case": worst_path,
            "worst_paired_donor_case": worst_donor,
            "failure_count": len(failures),
            "failures": failures,
        },
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())

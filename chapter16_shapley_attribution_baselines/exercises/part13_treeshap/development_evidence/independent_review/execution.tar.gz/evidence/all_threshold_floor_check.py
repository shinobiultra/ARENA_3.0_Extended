#!/usr/bin/env python3
"""Check the SHAP 0.49.1 float-threshold correction on every frozen tree/source row."""

from __future__ import annotations

import hashlib
import json
import platform
import sys
from datetime import datetime, timezone
from pathlib import Path

import joblib
import numpy as np


ROOT = Path("/home/bitwise/Documents/ARENA_3.0_Extended")
PART = ROOT / "chapter16_shapley_attribution_baselines/exercises/part13_treeshap"
FITTED_PATH = Path.home() / ".cache/arena_extended/treeshap/native-dev-v2/fitted.joblib"
DATA_PATH = Path.home() / ".cache/arena_extended/treeshap/concrete.csv"
SHAP_CPP_PATH = Path.home() / ".cache/arena_extended/treeshap/cext/tree_shap.h"
sys.path.insert(0, str(ROOT))

from chapter16_shapley_attribution_baselines.exercises.part13_treeshap.treeshap_data import source_data  # noqa: E402


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def floor_float32(value: float) -> np.float32:
    rounded = np.float32(value)
    if float(rounded) > value:
        return np.nextafter(rounded, np.float32(-np.inf), dtype=np.float32)
    return rounded


def main() -> int:
    fitted = joblib.load(FITTED_PATH)
    x = source_data()[:, :8].astype(np.float32).astype(np.float64)
    internal_thresholds = 0
    thresholds_rounded_up = 0
    raw_node_row_disagreements = 0
    corrected_node_row_disagreements = 0
    floor_definition_failures = []
    examples = []
    component_trees = 0

    for model_key, item in fitted["models"].items():
        for tree_index, tree in enumerate(item["ensemble"]["trees"]):
            component_trees += 1
            for node_index in np.flatnonzero(tree["left"] != -1):
                internal_thresholds += 1
                feature = int(tree["feature"][node_index])
                threshold = float(tree["threshold"][node_index])
                rounded = np.float32(threshold)
                floored = floor_float32(threshold)
                floor64 = float(floored)
                if float(rounded) > threshold:
                    thresholds_rounded_up += 1

                next_up = float(np.nextafter(floored, np.float32(np.inf), dtype=np.float32))
                if floor64 > threshold or next_up <= threshold:
                    floor_definition_failures.append(
                        {
                            "model": model_key,
                            "tree": tree_index,
                            "node": int(node_index),
                            "threshold": threshold,
                            "floored": floor64,
                            "next_up": next_up,
                        }
                    )

                values = x[:, feature]
                truth = values <= threshold
                raw = values <= float(rounded)
                corrected = values <= floor64
                raw_disagreements = int(np.count_nonzero(raw != truth))
                corrected_disagreements = int(np.count_nonzero(corrected != truth))
                raw_node_row_disagreements += raw_disagreements
                corrected_node_row_disagreements += corrected_disagreements
                if raw_disagreements and len(examples) < 8:
                    examples.append(
                        {
                            "model": model_key,
                            "tree": tree_index,
                            "node": int(node_index),
                            "feature": feature,
                            "threshold_float64": threshold,
                            "ordinary_float32": float(rounded),
                            "floor_float32": floor64,
                            "source_row_disagreements": raw_disagreements,
                        }
                    )

    status = (
        "PASS"
        if corrected_node_row_disagreements == 0 and not floor_definition_failures
        else "FAIL"
    )
    result = {
        "status": status,
        "run_utc": datetime.now(timezone.utc).isoformat(),
        "provenance": {
            "script": str(Path(__file__).resolve()),
            "fitted_artifact": str(FITTED_PATH),
            "fitted_artifact_sha256": sha256(FITTED_PATH),
            "source_data": str(DATA_PATH),
            "source_data_sha256": sha256(DATA_PATH),
            "shap_cpp_source": str(SHAP_CPP_PATH),
            "shap_cpp_source_sha256": sha256(SHAP_CPP_PATH),
            "protocol_freeze_sha256": sha256(PART / "protocol_freeze.json"),
            "python": platform.python_version(),
            "numpy": np.__version__,
            "joblib": joblib.__version__,
        },
        "scope": {
            "models": len(fitted["models"]),
            "component_trees": component_trees,
            "source_rows": len(x),
            "internal_thresholds": internal_thresholds,
        },
        "results": {
            "thresholds_requiring_downward_floor": thresholds_rounded_up,
            "ordinary_float32_node_row_routing_disagreements": raw_node_row_disagreements,
            "floor_float32_node_row_routing_disagreements": corrected_node_row_disagreements,
            "floor_definition_failure_count": len(floor_definition_failures),
            "floor_definition_failures": floor_definition_failures,
            "first_raw_disagreement_examples": examples,
        },
        "metric_note": "Routing counts are node-row comparisons, summed over every internal node and all source rows.",
        "proof_scope": "Finite float32 numerical features; excludes NaN/default-branch and categorical routing.",
    }
    print(json.dumps(result, indent=2, sort_keys=True))
    return 0 if status == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())

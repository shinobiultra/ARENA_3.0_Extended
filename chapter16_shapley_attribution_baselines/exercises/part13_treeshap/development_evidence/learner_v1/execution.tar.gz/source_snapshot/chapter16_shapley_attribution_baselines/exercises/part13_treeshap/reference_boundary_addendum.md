# Reference threshold finding after the first native run

Recorded 2026-09-06, after the frozen experiment's first fits. The original
protocol, data manifest and data loader remain byte-unchanged. This addendum
does not change the trained models, data, backgrounds, selected rows, missing
feature games or exact-oracle tolerance.

The original expectation that unmodified SHAP 0.49.1 interventional output would
meet the stated tolerance was falsified. Its C++ `dense_independent` conversion
stores a double-precision tree threshold in the single-precision `Node.thres`.
Scikit-learn instead compares a float32-rounded input to the original float64
threshold. Rounding a threshold upward can therefore change the represented
model at an exactly representable input. The library's default additivity
check is too permissive to establish the stricter contract used here.

An observed example is the first clean forest's component tree31, node32,
feature4: threshold10.099999904632568 becomes10.100000381469727, equal to the
float32 representation of input10.1. The original split takes the right branch;
the rounded split takes the left. Explanation rows7/9 (source rows139/162) show
about0.4902 MPa error in base plus summed contributions. The unmodified
path-dependent implementation agrees with the original prediction.

Keep the unmodified reference arrays, exact errors and failed parity flag.
Do not increase the tolerance or describe this reference as passing. A second,
explicitly corrected compiled reference replaces every threshold in a separate
explainer with the greatest float32 value less than or equal to the original
threshold. This is a numerical compatibility correction, not an adjustment
of individual examples or attributions.

For any finite original threshold t and any float32-representable query q,
q <= t if and only if q <= floor_float32(t). Thus this transformation preserves
the sklearn partition on its actual input domain. The fitted sklearn model
and the student implementation keep their original thresholds. Record every
changed threshold and verify its lower/upper float32 neighbors. The corrected
compiled reference must meet the original strict tolerance and must also agree
with exhaustive subset values. Remaining float32 value arithmetic is still
covered by the originally stated compiled-reference tolerance.

The learner sees both results. Exactness refers to the declared game and
numerical prediction semantics; agreement with a popular library is supporting
evidence, and a failed library comparison is a scientific result to investigate.

"""Preserve only review material and receipts; numerical payloads remain in cache."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import tarfile

parser=argparse.ArgumentParser()
parser.add_argument('--version',required=True)
args=parser.parse_args()
ROOT=Path('/home/bitwise/Documents/ARENA_3.0_Extended')
CACHE=Path('/home/bitwise/.cache/arena_extended/shapiq_estimators')
HERE=ROOT/'chapter16_shapley_attribution_baselines/exercises/part17_shapiq_estimators'
learner=CACHE/f'new-environment-learner-{args.version}'
fresh=CACHE/f'new-environment-reproduction-{args.version}'
expected=HERE/'expected_outputs'
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

published=json.loads((expected/'learner_execution.json').read_text())
assert published['learner_directory']==str(learner)
assert published['publication_fresh_directory']==str(fresh)
historical=CACHE/'historical-publication-ff6d06e3'
historical.mkdir(exist_ok=True)
for name in ('execution_review.tar.gz','execution_review.tar.gz.json'):
    source=expected/name
    destination=historical/name
    if not destination.exists(): shutil.copy2(source,destination)

files={}
def include(path,relative):
    assert path.is_file(),path
    assert path.stat().st_size<32*1024**2,(path,'oversize repository review member')
    assert not path.name.endswith('.pt'),path
    assert relative not in files,relative
    files[relative]=path

for name in ('execution.json','completed_learner.ipynb'):
    include(learner/name,'learner/'+name)
for subdir in ('source_snapshot','html_review'):
    for path in sorted((learner/subdir).rglob('*')):
        if path.is_file():include(path,'learner/'+str(path.relative_to(learner)))
for path in sorted((learner/'figures').glob('*.png')):
    include(path,'learner/figures/'+path.name)
include(learner/'figures/native/summary.json','learner/figures/native/summary.json')
include(CACHE/'new-environment-learner-v1/html_review/figure_author_review.json',
        'checks/direct_current_environment_png_review.json')
include(fresh/'reproduction.json','checks/publication_fresh_reproduction.json')
for name in ('fresh_reproduction.json','reference_metrics.json','learner_execution.json'):
    include(expected/name,'checks/published_'+name)
for name in (f'new-environment-learner-{args.version}-budget.json',
             f'new-environment-play-review-{args.version}.py',
             f'new-environment-play-review-{args.version}.log',
             f'new-environment-normal-report-{args.version}.log',
             f'new-environment-section-tests-{args.version}.log'):
    include(CACHE/name,'checks/'+name)
include(CACHE/'new-environment-scientific-tests-v3.log','checks/new-environment-scientific-tests-v3.log')
include(CACHE/'new-environment-section-gates-v4.json','checks/new-environment-section-gates-v4.json')
include(CACHE/'new-environment-original-preservation.log','checks/new-environment-original-preservation.log')
include(HERE/'verification_report.json','checks/verification_report.json')
include(Path(__file__),'checks/archive_current_environment.py')

archive=expected/'execution_review.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
        with tarfile.open(fileobj=compressed,mode='w') as tar:
            for name,path in sorted(files.items()):
                blob=path.read_bytes()
                info=tarfile.TarInfo(name);info.size=len(blob);info.mode=0o644;info.mtime=0
                tar.addfile(info,io.BytesIO(blob))
inventory={name:{'sha256':digest(path),'bytes':path.stat().st_size} for name,path in sorted(files.items())}
with tarfile.open(archive,'r:gz') as tar:
    assert {member.name for member in tar.getmembers()}==set(inventory)
    for name,item in inventory.items():
        blob=tar.extractfile(name).read()
        assert len(blob)==item['bytes'] and hashlib.sha256(blob).hexdigest()==item['sha256'],name
receipt={'archive':archive.name,'sha256':digest(archive),'bytes':archive.stat().st_size,
         'scope':'Own-answer notebook, source snapshots, actual figures, author browser and play review, and complete check receipts. Numerical .pt arrays remain external and physically hashed in native_summary.json.',
         'files':inventory,'external_native_directory':str(learner/'figures/native')}
(expected/'execution_review.tar.gz.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(f'PASS: archive {len(inventory)} members, {archive.stat().st_size} bytes; all member hashes verified; no .pt payloads.')

"""Recheck the existing editable plays using actual completed-learner functions."""
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import os
import sys

ROOT = Path('/home/bitwise/Documents/ARENA_3.0_Extended')
LEARNER = Path('/home/bitwise/.cache/arena_extended/shapiq_estimators/new-environment-learner-v4')
sys.path.insert(0, str(ROOT))
os.environ['MPLBACKEND'] = 'Agg'
os.environ['ARENA_ESTIMATOR_OUTPUT_DIRECTORY'] = str(LEARNER / 'html_review/play_figures')
import torch as t
import matplotlib.pyplot as plt
from chapter16_shapley_attribution_baselines.exercises.part17_shapiq_estimators import estimator_plots as plots
from chapter16_shapley_attribution_baselines.exercises.part17_shapiq_estimators.reproduce_native import validate_current

validate_current(LEARNER)
nb = json.loads((LEARNER / 'completed_learner.ipynb').read_text())
namespace = {'__name__': '__play_review__'}
for cell in nb['cells']:
    meta = cell.get('metadata', {}).get('arena', {})
    if cell['cell_type'] == 'code' and (meta.get('exercise_functions') or meta.get('calling_cell') in ('setup', 'methods_namespace')):
        exec(''.join(cell['source']), namespace)
methods = namespace['methods']
payload = {name: t.load(LEARNER / 'figures/native' / (name + '.pt'), map_location='cpu', weights_only=False) for name in ('games', 'exact')}
output = LEARNER / 'html_review/play_figures'
output.mkdir(exist_ok=True)
native = [
    {}, {'draws':16}, {'draws':1024}, {'seed':161751}, {'proposal':'uniform'},
    {'model_key':'clean_1'}, {'model_key':'shuffled_0'}, {'model_key':'ridge'}, {'source_id':1},
    {'model_key':'ridge','source_id':1,'draws':2,'proposal':'uniform'},
    {'model_key':'clean_2','source_id':1,'draws':32,'seed':123,'proposal':'uniform'},
    {'draws':4096,'seed':161782,'proposal':'uniform'},
]
native_records=[]
for i, args in enumerate(native):
    play=plots.make_native_play(payload,methods,**args)
    for key in ('shapiq','se','exact'):
        assert t.isfinite(play[key]).all(), key
    assert t.isfinite(play['kernelshap_iq']['pairs']).all()
    assert len(play['sampled_masks']) == play['draws']
    assert play['receipt']['unique_queries'] <= 256
    assert play['receipt']['unique_queries'] == len(set(play['receipt']['queried_masks'].tolist()))
    assert bool(play['exploratory_audit_reuse']) == (play['source_id'] == 1)
    fig=plots.plot_native_play(play)
    path=output/f'native_{i:02d}.png'
    fig.savefig(path,dpi=130,bbox_inches='tight'); plt.close(fig)
    native_records.append({key: play[key] for key in ('model_key','source_id','draws','seed','proposal','exploratory_audit_reuse')} | {
        'unique_queries':play['receipt']['unique_queries'],
        'pair_rank':play['kernelshap_iq']['pair_stage']['free_rank'],
        'figure':str(path.relative_to(LEARNER)),
        'figure_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
    })

games=plots.analytic_games(methods.coalition_design)
analytic_records=[]
for i,(game,mask) in enumerate([('mixed',0),('mixed',15),('mixed',5),('constant',3),('additive',3),('pure_four',15)]):
    fig=plots.plot_shared_query(games,methods.sii_query_weights,query_mask=mask,game_name=game)
    path=output/f'analytic_{i:02d}.png'
    fig.savefig(path,dpi=130,bbox_inches='tight'); plt.close(fig)
    analytic_records.append({'game':game,'mask':mask,'figure':str(path.relative_to(LEARNER)),
                             'figure_sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
invalid=[{'draws':1},{'model_key':'missing'},{'source_id':-1},{'proposal':'missing'}]
for args in invalid:
    try: plots.make_native_play(payload,methods,**args)
    except ValueError: pass
    else: raise AssertionError(f'Invalid play accepted: {args}')
record={'status':'PASS','learner_execution_sha256':hashlib.sha256((LEARNER/'execution.json').read_bytes()).hexdigest(),
        'review_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'method_source':'Actual completed own-answer learner exercise cells, with immediate tests reexecuted.',
        'native_variations':native_records,'analytic_variations':analytic_records,'invalid_inputs_rejected':invalid,
        'scope':'Actual editable play functions and rendered figures; fixed study evidence unchanged.'}
(LEARNER/'html_review/play_variations.json').write_text(json.dumps(record,indent=2)+'\n')
print('PASS: 12 native variations, six analytic variations, four invalid inputs rejected; all nine immediate method tests passed.')

# Independent DeepSHAP pre-fit protocol review

Reviewed 2026-09-06 before `protocol_freeze.json` existed and before any native
DeepSHAP Concrete fit. The review used the canonical learner plan, draft
protocol, data manifest and loader, the cache API contract and preparation note,
and the visible methods/study sources. It did not fit a model or alter any
implementation or experiment output.

## Verdict

READY TO FREEZE at protocol SHA256
`ceca1c3d0fa9bd5635915b4f7c8ec9d2353c3e55b6816788ce69b58d8e67869e`.
Do not edit the protocol after the freeze except through a dated addendum.

## Scientific corrections made before freeze

1. The earlier replacement-curve paragraph described per-row rankings by
   `sign(vfull-vempty)*phi`. That contradicted the canonical plan, API and study
   source, which freeze descending explanation-split mean absolute rankings and
   apply the same order to every audit row. The protocol now states that actual
   design. Per-row sign-oriented ranking remains available only in the generic
   exercise method and editable local play. Per-row sign still orients displayed
   insertion gain and deletion drop.
2. The earlier count of 15,232 attribution coordinates was presented beside
   per-reference contributions. The protocol now distinguishes 15,232 averaged
   model-row-feature coordinates per method from 974,848 stored DeepSHAP
   query-donor-feature contributions. The primary workload remains 1,904
   model-rows, 487,424 coalition values and 31,195,136 hybrid predictions.
3. The two salted 64-row background controls are independently ordered, not
   constrained to be disjoint. The protocol now labels them deterministic
   sensitivity probes rather than uncertainty replicates. In the frozen design,
   `primary64` overlaps `independent64_a` in 5 rows and `independent64_b` in 6;
   the two independently ordered sets overlap in 9 rows.
4. The real-data local-accuracy tolerance now has an explicit failure policy:
   retain and diagnose an out-of-tolerance residual instead of changing the
   finite epsilon or tolerance. The known near-zero crossing remains the
   predeclared exception to exact completeness.

The remaining changes to `protocol.md` only restored ordinary spacing and
readable mathematical notation. Identifiers, hashes, salts, seeds, model grid,
backgrounds, tolerances and experiment scope were preserved.

## Independent no-fit evidence

The exact split recipe was regenerated from the cached source bytes. It matches
all manifest row IDs exactly: 427 recipe groups split into 298 / 64 / 65 groups
and 758 / 153 / 119 rows. The three row blocks are disjoint, their union is
source IDs 0 through 1029, and recipe groups do not cross blocks. The cached CSV
has 41,472 bytes, SHA256
`8d4b15b6fc68cd932d745cbd663d5ceae66dd54422e99c1e4865f2936ab7e2af`,
shape `(1030, 9)`, all finite values, 992 unique eight-input rows and 1,005
unique complete rows.

The background audit confirms sizes 16 / 64 / 128 / 64 / 64, unique IDs within
each set and the exact nested chain `nested16 <= primary64 <= nested128`. Every
background ID belongs to train because all orders are computed over the 758
training IDs.

The arithmetic audit independently confirms:

- `7 * 272 = 1,904` model-rows;
- `1,904 * 256 = 487,424` coalition values;
- `487,424 * 64 = 31,195,136` primary hybrid predictions;
- `1,904 * 8 = 15,232` averaged coordinates per method;
- `1,904 * 64 * 8 = 974,848` stored DeepSHAP pair coordinates;
- `7 * 2 * 64 = 896` bounded author model/query/donor pairs and 7,168
  coordinates.

The threshold game independently gives coalition values `(0,0,0,1)`, exact
Shapley `(0.5,0.5)`, Rescale `(2/3,1/3)`, gradient-delta `(2,1)` and two
single-feature necessity effects of 1. Both min representations agree on all
four binary inputs while producing the predeclared Rescale allocations `(0,1)`
and `(1,0)`; exact and RevealCancel are `(0.5,0.5)`. The near-zero crossing has
preactivation difference `8e-7`, output difference `4e-7`, guarded contribution
zero and `epsilon=0` contribution `4e-7`. A random fixed-network normalization
fold agrees between standardized and raw forms to `7.11e-15` maximum absolute
error.

## Evidence files

- `pre_fit_protocol_audit.py`, SHA256
  `ecba0bcc15ceab12dfc8d06871cb9a912b4364022b0eee6c75638e3ffacf4622`
- `pre_fit_protocol_audit.result.json`, SHA256
  `ab6a5866920a58ff940835f0aa6db0dc29d76e479888659aac460c67e35a2314`

The JSON retains every selected background source ID as well as all numeric
checks. No native fitted artifact was read or produced.

## Remaining limits

This is a pre-fit design review. Actual model performance, real-data
approximation error, local-accuracy residuals, author parity, figures and exact
fresh reproduction remain unknown until the frozen experiment runs. Those
results must be retained even when they contradict the motivating expectation.

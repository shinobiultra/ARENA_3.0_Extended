# Independent review: DeepSHAP methods and study

Date: 2026-09-06 (Asia/Tokyo)

## Verdict

PASS for mathematical correctness and frozen-protocol conformance. I found no
source defect requiring a canonical change in `deepshap_methods.py` or
`deepshap_study.py`.

The one provenance limitation is explicit: `native-dev-v1` executed
`deepshap_methods.py` SHA256 `36d983eb...`; the current source SHA256 is
`8d5e9d04...`. The complete diff is only the private-helper rename
`_float_tensor` to `_method_tensor` and its call sites. The executed behavior is
unchanged, and the current source passes the separate fit-free probe. The
planned final learner execution must provide exact-current-source execution
evidence.

## Reviewed source

- Frozen `protocol.md`: `ceca1c3d0fa9bd5635915b4f7c8ec9d2353c3e55b6816788ce69b58d8e67869e`
- Current `deepshap_methods.py`: `8d5e9d04624e3941768a710ba9c72dfd281c25c39b495845beda296a1628c4c6`
- Current `deepshap_study.py`: `df5d7f892a6846309d27441a10258595988015c59be1db49d49d314764f3120d`

No canonical file was edited by this reviewer. No fit function was called.

## Mathematical and design conclusions

1. `paired_forward`, `rescale_slope`, `rescale_multipliers`,
   `single_reference`, and `background_deepshap` implement the supported
   scalar affine/ReLU Rescale chain correctly. Reverse Linear propagation uses
   the layer weight, and every ReLU uses the endpoint secant outside the frozen
   guard. The strict guard is exactly `abs(zx-zb) < 1e-6` or exact zero, with
   reference derivative `1[zb>0]`.
2. The disclosed near-zero exception is real and preserved. For query `+4e-7`
   and reference `-4e-7`, the primary rule returns attribution `0` for output
   delta `4e-7`; `epsilon=0` returns `4e-7`. The implementation therefore does
   not support an unconditional completeness claim, and the frozen protocol
   does not make one.
3. `coalition_values` evaluates each missing-feature hybrid from one intact
   donor and averages donor predictions. It does not replace missing features
   with their coordinate-wise mean. Feature zero is the least-significant bit.
   `exact_shapley` uses the correct factorial-equivalent weight
   `1 / (D * choose(D-1, |S|))` for each absent-feature coalition.
4. `gradient_delta` is exactly the stated point-gradient control
   `grad f(x) * (x - mean background)`, with no GradientSHAP claim.
5. The MLP and ridge raw-unit folds are algebraically correct. Saved native raw
   states equal an independent application of the formulas exactly. Rebuilt
   training predictions agree with stored predictions within `2.81e-13`.
6. Preparation receives only train and explanation blocks, computes descending
   explanation-split mean-absolute rankings, and breaks ties stably by feature
   index. Audit replacement curves expand those frozen global orders for every
   row. The generic method and `native_play` separately use the sign-oriented
   local order and label audit reuse `exploratory`.
7. The native orchestration seals fitted and prepared payload hashes before the
   literal audit load. `evaluate_study` rechecks train/explanation values,
   identities, background orders, disjoint audit identities, and the frozen
   ranking payload. The source contains no causal/intervention wording; the
   frozen protocol correctly calls the game empirical marginal/background and
   noncausal.
8. All seven models, all primary games, complete donor contributions, five
   background designs, all audit curves, and the 100-permutation control stream
   are retained with the intended dimensions.

## Independent fit-free probe

Command:

```text
.venv/bin/python /home/bitwise/.cache/arena_extended/deepshap/reviews/methods_study_independent_probe.py
```

The probe uses four fixed untrained networks and independent NumPy forward,
hybrid-game, reverse-Rescale, and permutation-Shapley implementations. It also
checks the finite-epsilon exception, affine analytic equality, raw folding,
study payload shapes, and the global/local ordering separation.

Selected maximum absolute errors:

- intact-donor game: `8.88e-16`
- permutation Shapley: `2.22e-16`
- exact efficiency: `2.22e-16`
- NumPy reverse multiplier: `4.44e-16`
- random-network pair completeness: `1.33e-15`
- affine DeepSHAP/exact/gradient analytic parity: `8.88e-16`
- raw fold: `0`

Evidence:

- `methods_study_independent_probe.py`: `f6c0c32d7f6160d40bb399945a740bf21c2134fdc2baa124a78eeba5903b78cc`
- `methods_study_independent_probe.result.json`: `e6a756bae6a264c7d8dd5fbefda60ac97f98a85b114c24541b7df4eb171f0a64`
- `methods_study_independent_probe.stdout.log`: same bytes/hash as the result JSON

## Read-only saved-array audit

Command:

```text
.venv/bin/python /home/bitwise/.cache/arena_extended/deepshap/reviews/native_saved_array_integrity.py
```

The audit reads `/home/bitwise/.cache/arena_extended/deepshap/native-dev-v1`;
it does not train. It independently contracts every primary and alternate game
with a coefficient matrix derived from the factorial Shapley formula, rebuilds
all replacement masks and values, recomputes all explanation-only rankings and
audit MSEs, checks donor/split identities, reapplies every normalization fold,
and verifies the sealed fitted/prepared hashes.

Verified counts:

- 7 models and 1,904 model-rows
- 487,424 primary coalition values
- 31,195,136 primary hybrid predictions by dimension
- 15,232 averaged coordinates per method
- 974,848 retained query-donor-feature coordinates
- 896 bounded author pair checks / 7,168 coordinates

Maximum independent saved-array errors:

- empty-game/base: `0`
- full-game/prediction: `1.92e-13`
- retained pair mean/DeepSHAP: `0`
- DeepSHAP local residual: `1.74e-13`
- independent exact contraction: `6.66e-14`
- exact efficiency: `1.92e-13`
- alternate-background exact efficiency: `6.75e-14`
- alternate-background DeepSHAP local residual: `5.68e-14`

The audit MSEs in MPa squared are clean MLPs `31.04`, `35.61`, `36.58`;
shuffled controls `452.79`, `643.67`, `576.97`; ridge `99.65`; and the
training-mean baseline `244.68`. Clean audit DeepSHAP-versus-exact coordinate
MAEs are `1.47`, `1.59`, and `2.09` MPa. These are descriptive discrepancies,
not failed acceptance gates. Ridge DeepSHAP/exact audit MAE is `1.14e-15` MPa.

The saved reference payload reports full averaged-vector author parity maximum
error `1.71e-13` and bounded-pair maximum attribution error `6.31e-13`. I
inspected those saved reference results but did not rerun SHAP author calls in
this review.

Evidence:

- `native_saved_array_integrity.py`: `473da19aa7dbccb75f46a2b97736f8e579f3f8c72a4e47d1cd251fcbb920120b`
- `native_saved_array_integrity.result.json`: `2f561d7eedc1748b131a05044d671d86c12f493db26bc09125af801da8f30543`

## Tests

```text
.venv/bin/python -m pytest -q \
  chapter16_shapley_attribution_baselines/exercises/part14_deepshap/deepshap_methods_tests.py \
  chapter16_shapley_attribution_baselines/exercises/part14_deepshap/deepshap_study_tests.py
```

Result: `20 passed in 3.12s`. The one `fit_models` test rejects malformed input
before fitting; no native model was trained.

## Limitations

- Author-library parity is taken from the completed, hash-bound reference
  payload and was not independently rerun here.
- `native-dev-v1` predates the behavior-preserving private-helper rename, so it
  is evidence for the same computation but cannot be the final exact-source
  learner run.
- The independent randomized probe covers the deliberately narrow exact
  `Sequential` Linear/ReLU contract; it does not claim support for other graph
  operators, as required by the frozen scope.

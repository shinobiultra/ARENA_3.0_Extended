"""Fit-free independent probes for the frozen part 16.14 methods and study.

This script deliberately constructs only fixed, untrained affine/ReLU networks.
It does not call any native fitting entry point or load any audit outcome.
"""

from __future__ import annotations

import hashlib
import itertools
import json
from pathlib import Path

import numpy as np
import torch as t
from torch import nn

ROOT = Path("/home/bitwise/Documents/ARENA_3.0_Extended")
PART = ROOT / "chapter16_shapley_attribution_baselines/exercises/part14_deepshap"
REVIEW = Path("/home/bitwise/.cache/arena_extended/deepshap/reviews")

import sys

sys.path.insert(0, str(ROOT))
from chapter16_shapley_attribution_baselines.exercises.part14_deepshap import (  # noqa: E402
    deepshap_methods as methods,
)
from chapter16_shapley_attribution_baselines.exercises.part14_deepshap import (  # noqa: E402
    deepshap_study as study,
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def linear(weight: np.ndarray, bias: np.ndarray) -> nn.Linear:
    layer = nn.Linear(weight.shape[1], weight.shape[0], dtype=t.float64)
    with t.no_grad():
        layer.weight.copy_(t.from_numpy(weight))
        layer.bias.copy_(t.from_numpy(bias))
    return layer


def numpy_forward(model: nn.Sequential, x: np.ndarray) -> np.ndarray:
    value = np.asarray(x, dtype=np.float64)
    for layer in model:
        if type(layer) is nn.Linear:
            value = value @ layer.weight.detach().numpy().T + layer.bias.detach().numpy()
        elif type(layer) is nn.ReLU:
            value = np.maximum(value, 0.0)
        else:  # pragma: no cover - the fixed probes never use another operator
            raise TypeError(type(layer))
    return value[:, 0]


def numpy_states(model: nn.Sequential, x: np.ndarray) -> list[np.ndarray]:
    states = [np.asarray(x, dtype=np.float64)]
    value = states[0]
    for layer in model:
        if type(layer) is nn.Linear:
            value = value @ layer.weight.detach().numpy().T + layer.bias.detach().numpy()
        else:
            value = np.maximum(value, 0.0)
        states.append(value)
    return states


def numpy_rescale_multipliers(
    model: nn.Sequential, x: np.ndarray, background: np.ndarray, epsilon: float
) -> np.ndarray:
    """Independent NumPy reverse rule, one query/reference pair at a time."""
    x_states = numpy_states(model, x)
    b_states = numpy_states(model, background)
    out = np.empty((len(x), len(background), x.shape[1]), dtype=np.float64)
    layers = list(model)
    for row in range(len(x)):
        for donor in range(len(background)):
            multiplier = np.ones(1, dtype=np.float64)
            for index in range(len(layers) - 1, -1, -1):
                layer = layers[index]
                if type(layer) is nn.Linear:
                    multiplier = multiplier @ layer.weight.detach().numpy()
                else:
                    zx = x_states[index][row]
                    zb = b_states[index][donor]
                    delta = zx - zb
                    guarded = (delta == 0.0) | (np.abs(delta) < epsilon)
                    safe = np.where(guarded, 1.0, delta)
                    slope = (np.maximum(zx, 0.0) - np.maximum(zb, 0.0)) / safe
                    slope = np.where(guarded, (zb > 0.0).astype(np.float64), slope)
                    multiplier = multiplier * slope
            out[row, donor] = multiplier
    return out


def manual_game(model: nn.Sequential, x: np.ndarray, background: np.ndarray) -> np.ndarray:
    n, d = x.shape
    values = np.empty((n, 2**d), dtype=np.float64)
    for row in range(n):
        for mask in range(2**d):
            predictions = []
            for donor in background:
                hybrid = donor.copy()
                for feature in range(d):
                    if mask & (1 << feature):
                        hybrid[feature] = x[row, feature]
                predictions.append(numpy_forward(model, hybrid[None, :])[0])
            values[row, mask] = np.mean(predictions)
    return values


def permutation_shapley(values: np.ndarray) -> np.ndarray:
    n, size = values.shape
    d = int(np.log2(size))
    result = np.zeros((n, d), dtype=np.float64)
    permutations = list(itertools.permutations(range(d)))
    for order in permutations:
        mask = 0
        for feature in order:
            result[:, feature] += values[:, mask | (1 << feature)] - values[:, mask]
            mask |= 1 << feature
    return result / len(permutations)


def maxerr(actual: t.Tensor | np.ndarray, expected: t.Tensor | np.ndarray) -> float:
    a = actual.detach().numpy() if isinstance(actual, t.Tensor) else np.asarray(actual)
    b = expected.detach().numpy() if isinstance(expected, t.Tensor) else np.asarray(expected)
    return float(np.max(np.abs(a - b)))


def main() -> None:
    t.set_default_dtype(t.float64)
    rng = np.random.default_rng(161496)
    model = nn.Sequential(
        linear(rng.normal(size=(5, 4)), rng.normal(size=5)),
        nn.ReLU(),
        linear(rng.normal(size=(3, 5)), rng.normal(size=3)),
        nn.ReLU(),
        linear(rng.normal(size=(1, 3)), rng.normal(size=1)),
    ).eval()
    x_np = rng.normal(size=(3, 4))
    b_np = rng.normal(size=(6, 4))
    x = t.from_numpy(x_np)
    background = t.from_numpy(b_np)
    masks = methods.coalition_masks(4)

    expected_game = manual_game(model, x_np, b_np)
    actual_game = methods.coalition_values(
        model, x, background, masks, row_batch=2, forward_batch=7
    )
    game_error = maxerr(actual_game, expected_game)
    if game_error > 2e-14:
        raise AssertionError(f"intact-donor game mismatch: {game_error}")

    expected_phi = permutation_shapley(expected_game)
    actual_phi = methods.exact_shapley(actual_game)
    shapley_error = maxerr(actual_phi, expected_phi)
    efficiency_error = maxerr(actual_phi.sum(1), actual_game[:, -1] - actual_game[:, 0])
    if shapley_error > 2e-14 or efficiency_error > 2e-14:
        raise AssertionError((shapley_error, efficiency_error))

    expected_multipliers = numpy_rescale_multipliers(model, x_np, b_np, 1e-6)
    actual_multipliers = methods.rescale_multipliers(model, x, background)
    multiplier_error = maxerr(actual_multipliers, expected_multipliers)
    pair_values = actual_multipliers * (x[:, None, :] - background[None, :, :])
    pair_delta = t.from_numpy(
        numpy_forward(model, x_np)[:, None] - numpy_forward(model, b_np)[None, :]
    )
    completeness_error = maxerr(pair_values.sum(2), pair_delta)
    if multiplier_error > 2e-14 or completeness_error > 2e-13:
        raise AssertionError((multiplier_error, completeness_error))

    # The frozen finite-epsilon exception: the reference derivative at -4e-7 is zero.
    relu = nn.Sequential(
        linear(np.array([[1.0]]), np.array([0.0])),
        nn.ReLU(),
        linear(np.array([[1.0]]), np.array([0.0])),
    ).eval()
    near_x = t.tensor([[4e-7]])
    near_b = t.tensor([[-4e-7]])
    _, guarded_phi = methods.background_deepshap(relu, near_x, near_b)
    _, exact_secant_phi = methods.background_deepshap(relu, near_x, near_b, epsilon=0)
    if guarded_phi.item() != 0.0 or exact_secant_phi.item() != 4e-7:
        raise AssertionError((guarded_phi, exact_secant_phi))

    # An affine game has one analytic answer for DeepSHAP, exact Shapley and gradient-delta.
    affine_weight = np.array([[1.5, -2.0, 0.25, 3.0]])
    affine = nn.Sequential(linear(affine_weight, np.array([0.7]))).eval()
    affine_base, affine_deep = methods.background_deepshap(affine, x, background)
    affine_game = methods.coalition_values(affine, x, background, masks)
    affine_exact = methods.exact_shapley(affine_game)
    affine_gradient = methods.gradient_delta(affine, x, background)
    analytic = t.from_numpy(affine_weight[0]) * (x - background.mean(0))
    affine_error = max(
        maxerr(affine_deep, analytic),
        maxerr(affine_exact, analytic),
        maxerr(affine_gradient, analytic),
        abs(affine_base.item() - numpy_forward(affine, b_np).mean()),
    )
    if affine_error > 2e-14:
        raise AssertionError(affine_error)

    # Raw-unit folding on fixed untrained states, independently evaluated before and after.
    t.manual_seed(161497)
    standard_mlp = nn.Sequential(
        nn.Linear(8, 32, dtype=t.float64),
        nn.ReLU(),
        nn.Linear(32, 32, dtype=t.float64),
        nn.ReLU(),
        nn.Linear(32, 1, dtype=t.float64),
    ).eval()
    normalization = {
        "x_mean": t.from_numpy(rng.normal(size=8)),
        "x_std": t.from_numpy(rng.uniform(0.25, 2.0, size=8)),
        "y_mean": t.tensor(31.25),
        "y_std": t.tensor(8.5),
    }
    raw_x = t.from_numpy(rng.normal(size=(9, 8)))
    standard_state = {
        name: value.detach().clone() for name, value in standard_mlp.state_dict().items()
    }
    folded = study._fold_mlp_state(standard_state, normalization)
    raw_mlp = study.make_model({"kind": "mlp", "state": folded})
    expected_raw = (
        standard_mlp((raw_x - normalization["x_mean"]) / normalization["x_std"])[
            :, 0
        ]
        * normalization["y_std"]
        + normalization["y_mean"]
    )
    fold_error = maxerr(raw_mlp(raw_x)[:, 0], expected_raw)
    if fold_error > 2e-14:
        raise AssertionError(fold_error)

    # One fixed untrained protocol-width model exercises the complete study payload.
    item = {"kind": "mlp", "state": folded}
    explanation = study._explain_model(item, raw_x[:2], raw_x[2:6], methods)
    expected_shapes = {
        "prediction": (2,),
        "base": (),
        "phi_deep": (2, 8),
        "phi_exact": (2, 8),
        "phi_gradient": (2, 8),
        "game": (2, 256),
        "pair_deep": (2, 4, 8),
    }
    if {name: tuple(value.shape) for name, value in explanation.items()} != expected_shapes:
        raise AssertionError("study payload dimensions changed")
    study_exact_efficiency = maxerr(
        explanation["phi_exact"].sum(1),
        explanation["prediction"] - explanation["base"],
    )
    study_deep_residual = maxerr(
        explanation["phi_deep"].sum(1),
        explanation["prediction"] - explanation["base"],
    )
    if study_exact_efficiency > 2e-13 or study_deep_residual > 2e-13:
        raise AssertionError((study_exact_efficiency, study_deep_residual))

    # Study curves must honor the supplied frozen global order; generic curves remain local.
    additive = t.arange(8, 0, -1, dtype=t.float64)
    game = t.zeros((2, 256), dtype=t.float64)
    for mask in range(256):
        included = t.tensor([(mask >> feature) & 1 for feature in range(8)], dtype=t.float64)
        game[:, mask] = included @ additive
    audit_phi = t.stack([t.arange(8, dtype=t.float64), t.arange(8, 0, -1, dtype=t.float64)])
    frozen_order = t.arange(8, dtype=t.int64)
    fixed_curve = study._ranked_curves(game, audit_phi, frozen_order, methods)
    local_curve = methods.ranked_replacement_curves(game, audit_phi)
    if not t.equal(fixed_curve["orders"], frozen_order[None].expand(2, 8)):
        raise AssertionError("study replaced a frozen global ranking")
    if not t.equal(local_curve["orders"][0], t.arange(7, -1, -1)):
        raise AssertionError("generic local sign-oriented ranking changed")
    if not t.equal(local_curve["orders"][1], t.arange(8)):
        raise AssertionError("generic local sign-oriented ranking changed")

    counts = {
        "model_rows": 7 * (153 + 119),
        "coalition_values": 7 * (153 + 119) * 256,
        "primary_hybrid_predictions": 7 * (153 + 119) * 256 * 64,
        "averaged_coordinates_per_method": 7 * (153 + 119) * 8,
        "pair_coordinates": 7 * (153 + 119) * 64 * 8,
        "bounded_author_pairs": 7 * 2 * 64,
    }
    expected_counts = {
        "model_rows": 1904,
        "coalition_values": 487424,
        "primary_hybrid_predictions": 31195136,
        "averaged_coordinates_per_method": 15232,
        "pair_coordinates": 974848,
        "bounded_author_pairs": 896,
    }
    if counts != expected_counts:
        raise AssertionError(counts)

    result = {
        "status": "PASS",
        "provenance": {
            "methods_sha256": digest(PART / "deepshap_methods.py"),
            "study_sha256": digest(PART / "deepshap_study.py"),
            "protocol_sha256": digest(PART / "protocol.md"),
            "probe_sha256": digest(Path(__file__)),
            "native_fit_calls": 0,
            "audit_outcome_loads": 0,
            "fixed_untrained_networks": 4,
        },
        "errors": {
            "intact_donor_game_max_abs": game_error,
            "permutation_shapley_max_abs": shapley_error,
            "exact_efficiency_max_abs": efficiency_error,
            "numpy_rescale_multiplier_max_abs": multiplier_error,
            "random_network_pair_completeness_max_abs": completeness_error,
            "affine_three_method_max_abs": affine_error,
            "raw_fold_max_abs": fold_error,
            "study_exact_efficiency_max_abs": study_exact_efficiency,
            "study_deep_local_residual_max_abs": study_deep_residual,
        },
        "epsilon_exception": {
            "primary_epsilon_phi": guarded_phi.item(),
            "epsilon_zero_phi": exact_secant_phi.item(),
            "output_delta": 4e-7,
        },
        "ordering": {
            "frozen_global_first_row": fixed_curve["orders"][0].tolist(),
            "local_first_row": local_curve["orders"][0].tolist(),
            "local_second_row": local_curve["orders"][1].tolist(),
        },
        "counts": counts,
        "study_shapes": {name: list(value.shape) for name, value in explanation.items()},
    }
    result_path = REVIEW / "methods_study_independent_probe.result.json"
    result_path.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

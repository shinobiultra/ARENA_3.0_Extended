"""Read-only integrity audit of the completed saved DeepSHAP native arrays.

This script loads existing artifacts. It never calls fit_models, fit_one_mlp_control,
fit_ridge_control, or _train_mlp.
"""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np
import torch as t

ROOT = Path("/home/bitwise/Documents/ARENA_3.0_Extended")
PART = ROOT / "chapter16_shapley_attribution_baselines/exercises/part14_deepshap"
NATIVE = Path("/home/bitwise/.cache/arena_extended/deepshap/native-dev-v1")
REVIEW = Path("/home/bitwise/.cache/arena_extended/deepshap/reviews")
sys.path.insert(0, str(ROOT))

from chapter16_shapley_attribution_baselines.exercises.part14_deepshap import (  # noqa: E402
    deepshap_data as data,
)
from chapter16_shapley_attribution_baselines.exercises.part14_deepshap import (  # noqa: E402
    deepshap_study as study,
)


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name: str):
    return t.load(NATIVE / name, weights_only=False, map_location="cpu")


def maxerr(a: t.Tensor, b: t.Tensor) -> float:
    return float((a - b).abs().max())


def independent_shapley_weights(d: int) -> t.Tensor:
    """Matrix mapping integer-ordered games to Shapley values."""
    result = t.zeros((d, 2**d), dtype=t.float64)
    for feature in range(d):
        for mask in range(2**d):
            if mask & (1 << feature):
                continue
            size = int(mask).bit_count()
            weight = math.factorial(size) * math.factorial(d - size - 1) / math.factorial(d)
            result[feature, mask] -= weight
            result[feature, mask | (1 << feature)] += weight
    return result


def expected_masks(orders: t.Tensor) -> tuple[t.Tensor, t.Tensor]:
    n, d = orders.shape
    insertion = t.zeros((n, d + 1), dtype=t.int64)
    deletion = t.full((n, d + 1), 2**d - 1, dtype=t.int64)
    for step in range(d):
        bit = 2 ** orders[:, step]
        insertion[:, step + 1] = insertion[:, step] + bit
        deletion[:, step + 1] = deletion[:, step] - bit
    return insertion, deletion


def check_explanation(
    item: dict, rows: int, donors: int, weights: t.Tensor
) -> dict[str, float]:
    expected_shapes = {
        "prediction": (rows,),
        "base": (),
        "phi_deep": (rows, 8),
        "phi_exact": (rows, 8),
        "phi_gradient": (rows, 8),
        "game": (rows, 256),
        "pair_deep": (rows, donors, 8),
    }
    actual_shapes = {name: tuple(item[name].shape) for name in expected_shapes}
    if actual_shapes != expected_shapes:
        raise AssertionError((actual_shapes, expected_shapes))
    independently_contracted = item["game"] @ weights.T
    errors = {
        "empty_base": maxerr(item["game"][:, 0], item["base"].expand(rows)),
        "full_prediction": maxerr(item["game"][:, -1], item["prediction"]),
        "pair_mean": maxerr(item["pair_deep"].mean(1), item["phi_deep"]),
        "deep_local": maxerr(
            item["phi_deep"].sum(1), item["prediction"] - item["base"]
        ),
        "exact_independent": maxerr(item["phi_exact"], independently_contracted),
        "exact_efficiency": maxerr(
            item["phi_exact"].sum(1), item["prediction"] - item["base"]
        ),
    }
    if max(errors.values()) > 1e-10:
        raise AssertionError(errors)
    return errors


def main() -> None:
    fitted = load("fitted.pt")
    prepared = load("prepared.pt")
    evaluated = load("evaluated.pt")
    reference = load("reference.pt")
    play = load("play.pt")
    boundary = json.loads((NATIVE / "before_audit.json").read_text())
    run = json.loads((NATIVE / "state.json").read_text())

    if boundary["prepared_sha256"] != digest(NATIVE / "prepared.pt"):
        raise AssertionError("prepared payload no longer matches pre-audit seal")
    if boundary["fitted_sha256"] != digest(NATIVE / "fitted.pt"):
        raise AssertionError("fitted payload no longer matches pre-audit seal")
    if boundary["audit_loaded"] is not False or run["changed_sources"] != []:
        raise AssertionError("native provenance boundary failed")

    train = data.load_split("train")
    explain = data.load_split("explain")
    audit = data.load_split("audit")
    train_x, train_y, train_ids = study._rows(train, "train")
    explain_x, explain_y, explain_ids = study._rows(explain, "explain")
    audit_x, audit_y, audit_ids = study._rows(audit, "audit")
    if (len(train_ids), len(explain_ids), len(audit_ids)) != (758, 153, 119):
        raise AssertionError("split dimensions changed")
    study._require_disjoint_ids(train=train_ids, explanation=explain_ids, audit=audit_ids)
    identity_checks = {
        "fitted_train_ids": t.equal(fitted["train_ids"], train_ids),
        "fitted_train_x": t.equal(fitted["train_x_raw"], train_x),
        "fitted_train_y": t.equal(fitted["train_y_raw"], train_y),
        "prepared_explain_ids": t.equal(prepared["explain_ids"], explain_ids),
        "prepared_explain_x": t.equal(prepared["explain_x_raw"], explain_x),
        "prepared_explain_y": t.equal(prepared["explain_targets"], explain_y),
        "evaluated_audit_ids": t.equal(evaluated["audit_ids"], audit_ids),
        "evaluated_audit_y": t.equal(evaluated["audit_targets"], audit_y),
    }
    if not all(identity_checks.values()):
        raise AssertionError(identity_checks)

    expected_backgrounds = study._background_indices(train_ids)
    for name, indices in expected_backgrounds.items():
        if not t.equal(prepared["background_indices"][name], indices):
            raise AssertionError(f"background positions changed: {name}")
    primary = expected_backgrounds["primary64"]
    if not t.equal(prepared["background"], train_x[primary]):
        raise AssertionError("primary donor values changed")
    if not t.equal(prepared["background_ids"], train_ids[primary]):
        raise AssertionError("primary donor identities changed")

    weights = independent_shapley_weights(8)
    all_errors: dict[str, dict[str, dict[str, float]]] = {"explanation": {}, "audit": {}}
    deep_exact: dict[str, dict[str, dict[str, float]]] = {"explanation": {}, "audit": {}}
    for split, models, rows in (
        ("explanation", prepared["models"], 153),
        ("audit", evaluated["models"], 119),
    ):
        for key in study.MODEL_KEYS:
            item = models[key]
            all_errors[split][key] = check_explanation(item, rows, 64, weights)
            delta = item["phi_deep"] - item["phi_exact"]
            deep_exact[split][key] = {
                "mean_abs": float(delta.abs().mean()),
                "max_abs": float(delta.abs().max()),
                "rmse": float(delta.square().mean().sqrt()),
            }

    # Recompute frozen explanation mean-absolute orders and every stored audit curve.
    for key in study.MODEL_KEYS:
        for name in ("exact", "deep", "gradient"):
            expected_order = t.argsort(
                prepared["models"][key][f"phi_{name}"].abs().mean(0),
                descending=True,
                stable=True,
            )
            if not t.equal(prepared["rankings"][key][name], expected_order):
                raise AssertionError(f"ranking mismatch: {key}/{name}")
            curve = evaluated["replacement_curves"][key][name]
            expected_orders = expected_order[None].expand(119, 8)
            insertion, deletion = expected_masks(expected_orders)
            if not t.equal(curve["orders"], expected_orders):
                raise AssertionError(f"audit-local ranking leaked into {key}/{name}")
            if not t.equal(curve["insertion_masks"], insertion) or not t.equal(
                curve["deletion_masks"], deletion
            ):
                raise AssertionError(f"replacement masks mismatch: {key}/{name}")
            game = evaluated["models"][key]["game"]
            if not t.equal(curve["insertion"], game.gather(1, insertion)) or not t.equal(
                curve["deletion"], game.gather(1, deletion)
            ):
                raise AssertionError(f"replacement values mismatch: {key}/{name}")

    # The stream must advance; reconstruct it with one persistent generator.
    random_rng = np.random.default_rng(study.RANDOM_ORDER_SEED)
    expected_random = t.from_numpy(np.stack([random_rng.permutation(8) for _ in range(100)]))
    if not t.equal(evaluated["random_orders"], expected_random):
        raise AssertionError("random order stream changed")
    for key in study.MODEL_KEYS:
        random_curve = evaluated["replacement_curves"][key]["random"]
        game = evaluated["models"][key]["game"]
        for index, order in enumerate(expected_random):
            orders = order[None].expand(119, 8)
            insertion, deletion = expected_masks(orders)
            if not t.equal(random_curve["insertion_masks"][index], insertion):
                raise AssertionError(f"random insertion masks mismatch: {key}/{index}")
            if not t.equal(random_curve["deletion_masks"][index], deletion):
                raise AssertionError(f"random deletion masks mismatch: {key}/{index}")
            if not t.equal(random_curve["insertion"][index], game.gather(1, insertion)):
                raise AssertionError(f"random insertion values mismatch: {key}/{index}")
            if not t.equal(random_curve["deletion"][index], game.gather(1, deletion)):
                raise AssertionError(f"random deletion values mismatch: {key}/{index}")

    # Recheck raw normalization folds and saved training predictions for all seven states.
    fold_errors: dict[str, float] = {}
    training_prediction_errors: dict[str, float] = {}
    x_mean, x_std, y_mean, y_std = study._normalization_tensors(fitted["normalization"])
    for key in study.MODEL_KEYS:
        item = fitted["models"][key]
        if item["kind"] == "mlp":
            expected_state = study._fold_mlp_state(item["standardized_state"], fitted["normalization"])
        else:
            expected_state = study._fold_ridge_state(item["standardized_state"], fitted["normalization"])
        fold_errors[key] = max(
            maxerr(item["state"][name], expected_state[name]) for name in expected_state
        )
        raw_model = study.make_model(item)
        with t.no_grad():
            raw_prediction = raw_model(train_x).squeeze(-1)
        training_prediction_errors[key] = maxerr(raw_prediction, item["training_prediction"])
        if fold_errors[key] != 0.0 or training_prediction_errors[key] > 1e-10:
            raise AssertionError((key, fold_errors[key], training_prediction_errors[key]))
        if key.startswith("clean_") and not t.equal(
            item["target_permutation"], t.arange(758, dtype=t.int64)
        ):
            raise AssertionError(f"clean target order changed: {key}")
        if key.startswith("shuffled_"):
            index = int(key[-1])
            expected = t.from_numpy(
                np.random.default_rng(study.SHUFFLE_SEEDS[index]).permutation(758)
            )
            if not t.equal(item["target_permutation"], expected):
                raise AssertionError(f"shuffle changed: {key}")

    performance = {
        key: float((evaluated["models"][key]["prediction"] - audit_y).square().mean())
        for key in study.MODEL_KEYS
    }
    performance["training_mean"] = float((audit_y - train_y.mean()).square().mean())
    for key, mse in performance.items():
        if mse != float(evaluated["performance"][key]["mse"]):
            raise AssertionError(f"MSE mismatch: {key}")

    variants = evaluated["background_variants"]
    if tuple(variants) != tuple(evaluated["background_variant_order"]):
        raise AssertionError("background variant ordering changed")
    combined_ids = t.cat([explain_ids, audit_ids])
    combined_split = t.cat(
        [t.zeros(153, dtype=t.int64), t.ones(119, dtype=t.int64)]
    )
    variant_errors: dict[str, dict[str, float]] = {}
    for name, item in variants.items():
        donor_count = {"primary64": 64, "nested16": 16, "nested128": 128,
                       "independent64_a": 64, "independent64_b": 64}[name]
        if not t.equal(item["row_ids"], combined_ids) or not t.equal(
            item["row_split"], combined_split
        ):
            raise AssertionError(f"variant row identity mismatch: {name}")
        indices = expected_backgrounds[name]
        if not t.equal(item["background_ids"], train_ids[indices]) or not t.equal(
            item["background"], train_x[indices]
        ):
            raise AssertionError(f"variant donor identity mismatch: {name}")
        variant_errors[name] = check_explanation(item, 272, donor_count, weights)
    primary_expected = {
        "prediction": t.cat(
            [prepared["models"]["clean_0"]["prediction"], evaluated["models"]["clean_0"]["prediction"]]
        ),
        "phi_deep": t.cat(
            [prepared["models"]["clean_0"]["phi_deep"], evaluated["models"]["clean_0"]["phi_deep"]]
        ),
        "phi_exact": t.cat(
            [prepared["models"]["clean_0"]["phi_exact"], evaluated["models"]["clean_0"]["phi_exact"]]
        ),
        "phi_gradient": t.cat(
            [prepared["models"]["clean_0"]["phi_gradient"], evaluated["models"]["clean_0"]["phi_gradient"]]
        ),
        "game": t.cat(
            [prepared["models"]["clean_0"]["game"], evaluated["models"]["clean_0"]["game"]]
        ),
        "pair_deep": t.cat(
            [prepared["models"]["clean_0"]["pair_deep"], evaluated["models"]["clean_0"]["pair_deep"]]
        ),
    }
    if any(not t.equal(variants["primary64"][name], value) for name, value in primary_expected.items()):
        raise AssertionError("primary anchor was recomputed or changed")

    counts = {
        "models": len(study.MODEL_KEYS),
        "model_rows": len(study.MODEL_KEYS) * (len(explain_ids) + len(audit_ids)),
        "coalition_values": sum(
            item["game"].numel()
            for models in (prepared["models"], evaluated["models"])
            for item in models.values()
        ),
        "averaged_coordinates_per_method": sum(
            item["phi_deep"].numel()
            for models in (prepared["models"], evaluated["models"])
            for item in models.values()
        ),
        "pair_coordinates": sum(
            item["pair_deep"].numel()
            for models in (prepared["models"], evaluated["models"])
            for item in models.values()
        ),
        "primary_hybrid_predictions": 7 * 272 * 256 * 64,
        "bounded_author_pairs": int(reference["counts"]["bounded_author_pair_checks"]),
        "bounded_author_coordinates": int(reference["counts"]["bounded_author_pair_coordinates"]),
    }
    expected_counts = {
        "models": 7,
        "model_rows": 1904,
        "coalition_values": 487424,
        "averaged_coordinates_per_method": 15232,
        "pair_coordinates": 974848,
        "primary_hybrid_predictions": 31195136,
        "bounded_author_pairs": 896,
        "bounded_author_coordinates": 7168,
    }
    if counts != expected_counts:
        raise AssertionError(counts)

    local_default_orders = play["curves"]["exact"]["orders"]
    if local_default_orders.shape != (1, 8) or play["audit_reuse"] != "exploratory":
        raise AssertionError("editable local play lost its separate exploratory status")
    for key in study.MODEL_KEYS:
        for name in ("exact", "deep", "gradient"):
            if not t.equal(
                evaluated["replacement_curves"][key][name]["orders"],
                prepared["rankings"][key][name][None].expand(119, 8),
            ):
                raise AssertionError("primary audit curve used a local order")

    current_source_hashes = {
        "deepshap_methods.py": digest(PART / "deepshap_methods.py"),
        "deepshap_study.py": digest(PART / "deepshap_study.py"),
        "protocol.md": digest(PART / "protocol.md"),
    }
    native_source_hashes = {
        Path(name).name: checksum
        for name, checksum in run["source_inputs"].items()
        if Path(name).name in current_source_hashes
    }
    source_hash_matches = {
        name: current_source_hashes[name] == native_source_hashes[name]
        for name in current_source_hashes
    }

    causal_lines = []
    for filename in ("deepshap_methods.py", "deepshap_study.py"):
        for line_number, line in enumerate((PART / filename).read_text().splitlines(), 1):
            if "causal" in line.lower() or "intervention" in line.lower():
                causal_lines.append(f"{filename}:{line_number}:{line.strip()}")

    maxima = {
        name: max(
            values[name]
            for split in all_errors.values()
            for values in split.values()
        )
        for name in next(iter(next(iter(all_errors.values())).values()))
    }
    maxima["alternate_background_exact_efficiency"] = max(
        values["exact_efficiency"] for values in variant_errors.values()
    )
    maxima["alternate_background_deep_local"] = max(
        values["deep_local"] for values in variant_errors.values()
    )
    result = {
        "status": "PASS",
        "provenance": {
            "native_directory": str(NATIVE),
            "fitted_sha256": digest(NATIVE / "fitted.pt"),
            "prepared_sha256": digest(NATIVE / "prepared.pt"),
            "evaluated_sha256": digest(NATIVE / "evaluated.pt"),
            "reference_sha256": digest(NATIVE / "reference.pt"),
            "play_sha256": digest(NATIVE / "play.pt"),
            "source_sha256": current_source_hashes,
            "native_execution_source_sha256": native_source_hashes,
            "current_source_hash_matches_native": source_hash_matches,
            "methods_difference_from_native": (
                "private helper rename _float_tensor to _method_tensor only; "
                "current source separately covered by the fit-free probe"
            ),
            "audit_script_sha256": digest(Path(__file__)),
            "native_fit_calls_by_this_audit": 0,
        },
        "identity_checks": identity_checks,
        "counts": counts,
        "max_errors": maxima,
        "audit_mse_mpa_squared": performance,
        "deep_vs_exact": deep_exact,
        "fold_max_errors": fold_errors,
        "training_prediction_max_errors": training_prediction_errors,
        "author_reference_saved_max_errors": {
            name: float(value) for name, value in reference["max_errors"].items()
        },
        "author_reference_status": reference["status"],
        "causal_or_intervention_source_lines": causal_lines,
        "global_audit_orders_recomputed_from_explanation_only": True,
        "local_play_separate_and_exploratory": True,
    }
    output = REVIEW / "native_saved_array_integrity.result.json"
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()

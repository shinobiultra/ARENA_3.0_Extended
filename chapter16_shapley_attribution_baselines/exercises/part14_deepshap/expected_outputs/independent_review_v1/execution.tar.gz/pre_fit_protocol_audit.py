"""Independent no-fit arithmetic and data audit for the DeepSHAP protocol."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np


REPO = Path("/home/bitwise/Documents/ARENA_3.0_Extended")
PART = REPO / "chapter16_shapley_attribution_baselines/exercises/part14_deepshap"
CSV = Path("/home/bitwise/.cache/arena_extended/deepshap/concrete.csv")


def exact_two(values: np.ndarray) -> np.ndarray:
    """Two-player Shapley contraction for values [empty, x0, x1, full]."""
    return np.array(
        [
            0.5 * ((values[1] - values[0]) + (values[3] - values[2])),
            0.5 * ((values[2] - values[0]) + (values[3] - values[1])),
        ]
    )


def relu(value: np.ndarray) -> np.ndarray:
    return np.maximum(value, 0.0)


def split_audit(data: np.ndarray, manifest: dict) -> dict:
    groups: dict[str, list[int]] = {}
    for source_id, row in enumerate(data):
        raw = np.asarray(row[:7], dtype="<f8").tobytes()
        group_hex = hashlib.sha256(raw).hexdigest()
        groups.setdefault(group_hex, []).append(source_id)
    ordered = sorted(
        groups,
        key=lambda group_hex: hashlib.sha256(
            ("arena16.12/split/" + group_hex).encode()
        ).digest(),
    )
    first = int(np.floor(0.70 * len(ordered)))
    second = int(np.floor(0.85 * len(ordered)))
    group_splits = {
        "train": ordered[:first],
        "explain": ordered[first:second],
        "audit": ordered[second:],
    }
    regenerated = {
        name: sorted(source_id for group in selected for source_id in groups[group])
        for name, selected in group_splits.items()
    }
    row_sets = {name: set(rows) for name, rows in regenerated.items()}
    return {
        "recipe_groups": len(groups),
        "group_counts": {name: len(groups_) for name, groups_ in group_splits.items()},
        "row_counts": {name: len(rows) for name, rows in regenerated.items()},
        "manifest_exact": {
            name: rows == manifest["splits"][name] for name, rows in regenerated.items()
        },
        "row_union_is_0_to_1029": sorted(set().union(*row_sets.values())) == list(range(1030)),
        "row_splits_disjoint": all(
            not row_sets[left] & row_sets[right]
            for index, left in enumerate(row_sets)
            for right in list(row_sets)[index + 1 :]
        ),
        "recipe_splits_disjoint": all(
            not set(group_splits[left]) & set(group_splits[right])
            for index, left in enumerate(group_splits)
            for right in list(group_splits)[index + 1 :]
        ),
        "regenerated": regenerated,
    }


def background_audit(train_ids: list[int]) -> dict:
    train = np.asarray(train_ids, dtype=np.int64)

    def ordered(seed: int) -> np.ndarray:
        return np.asarray(
            sorted(
                range(len(train)),
                key=lambda index: hashlib.sha256(
                    f"arena16.14/background/{seed}/{int(train[index])}".encode()
                ).digest(),
            )
        )

    primary_order = ordered(161460)
    backgrounds = {
        "primary64": train[primary_order[:64]],
        "nested16": train[primary_order[:16]],
        "nested128": train[primary_order[:128]],
        "independent64_a": train[ordered(161461)[:64]],
        "independent64_b": train[ordered(161462)[:64]],
    }
    sets = {name: set(values.tolist()) for name, values in backgrounds.items()}
    return {
        "sizes": {name: len(values) for name, values in backgrounds.items()},
        "all_unique_within_set": all(len(sets[name]) == len(values) for name, values in backgrounds.items()),
        "nested_chain": sets["nested16"] <= sets["primary64"] <= sets["nested128"],
        "overlap_primary_independent_a": len(sets["primary64"] & sets["independent64_a"]),
        "overlap_primary_independent_b": len(sets["primary64"] & sets["independent64_b"]),
        "overlap_independent_a_b": len(sets["independent64_a"] & sets["independent64_b"]),
        "source_ids": {name: values.tolist() for name, values in backgrounds.items()},
    }


def toy_math_audit() -> dict:
    gate_weight = np.array([2.0, 1.0])
    gate_bias = -2.0
    query = np.array([1.0, 1.0])
    reference = np.array([0.0, 0.0])

    def gate(value: np.ndarray) -> float:
        return float(max(gate_weight @ value + gate_bias, 0.0))

    gate_values = np.array(
        [
            gate(reference),
            gate(np.array([query[0], reference[1]])),
            gate(np.array([reference[0], query[1]])),
            gate(query),
        ]
    )
    gate_exact = exact_two(gate_values)
    gate_zx = gate_weight @ query + gate_bias
    gate_zb = gate_weight @ reference + gate_bias
    gate_slope = (max(gate_zx, 0.0) - max(gate_zb, 0.0)) / (gate_zx - gate_zb)
    gate_deep = gate_weight * gate_slope * (query - reference)
    gate_gradient = gate_weight * (query - reference)
    gate_effects = np.array(
        [gate(query) - gate(np.array([reference[0], query[1]])),
         gate(query) - gate(np.array([query[0], reference[1]]))]
    )

    binary = np.array([[0.0, 0.0], [1.0, 0.0], [0.0, 1.0], [1.0, 1.0]])
    min_left = binary[:, 1] - relu(binary[:, 1] - binary[:, 0])
    min_right = binary[:, 0] - relu(binary[:, 0] - binary[:, 1])
    min_values = np.array([0.0, 0.0, 0.0, 1.0])
    min_left_weight = np.array([[0.0, 1.0], [-1.0, 1.0]])
    min_right_weight = np.array([[1.0, 0.0], [1.0, -1.0]])
    output_weight = np.array([1.0, -1.0])

    def one_hidden_rescale(weight: np.ndarray) -> np.ndarray:
        zx_hidden = weight @ query
        zb_hidden = weight @ reference
        delta = zx_hidden - zb_hidden
        slope = np.where(
            delta == 0,
            (zb_hidden > 0).astype(float),
            (relu(zx_hidden) - relu(zb_hidden)) / np.where(delta == 0, 1.0, delta),
        )
        multiplier = (output_weight * slope) @ weight
        return multiplier * (query - reference)

    min_deep_left = one_hidden_rescale(min_left_weight)
    min_deep_right = one_hidden_rescale(min_right_weight)

    epsilon = 1e-6
    zx, zb = 4e-7, -4e-7
    delta = zx - zb
    guarded_slope = float(zb > 0) if abs(delta) < epsilon or delta == 0 else (max(zx, 0) - max(zb, 0)) / delta
    exact_slope = (max(zx, 0) - max(zb, 0)) / delta

    return {
        "threshold": {
            "game": gate_values.tolist(),
            "exact": gate_exact.tolist(),
            "deep": gate_deep.tolist(),
            "gradient_delta": gate_gradient.tolist(),
            "single_feature_necessity_effects": gate_effects.tolist(),
            "all_expected": bool(
                np.allclose(gate_exact, [0.5, 0.5], atol=0, rtol=0)
                and np.allclose(gate_deep, [2 / 3, 1 / 3], atol=0, rtol=0)
            ),
        },
        "min_representation": {
            "binary_inputs": binary.tolist(),
            "left_representation": min_left.tolist(),
            "mirrored_representation": min_right.tolist(),
            "representations_equal_on_binary_domain": bool(np.array_equal(min_left, min_right)),
            "exact": exact_two(min_values).tolist(),
            "deep_left": min_deep_left.tolist(),
            "deep_mirrored": min_deep_right.tolist(),
            "reveal_cancel": [0.5, 0.5],
        },
        "near_zero": {
            "preactivation_delta": delta,
            "output_delta": max(zx, 0) - max(zb, 0),
            "guarded_slope": guarded_slope,
            "guarded_contribution": guarded_slope * delta,
            "epsilon_zero_slope": exact_slope,
            "epsilon_zero_contribution": exact_slope * delta,
        },
    }


def folding_audit() -> dict:
    rng = np.random.default_rng(161499)
    x_mean = rng.normal(size=8)
    x_std = rng.uniform(0.2, 3.0, size=8)
    y_mean = float(rng.normal())
    y_std = float(rng.uniform(0.2, 3.0))
    w1, b1 = rng.normal(size=(5, 8)), rng.normal(size=5)
    w2, b2 = rng.normal(size=(4, 5)), rng.normal(size=4)
    w3, b3 = rng.normal(size=(1, 4)), rng.normal(size=1)
    x_raw = rng.normal(size=(31, 8))

    standardized = relu(relu((x_raw - x_mean) / x_std @ w1.T + b1) @ w2.T + b2) @ w3.T + b3
    expected = y_std * standardized + y_mean
    w1raw = w1 / x_std
    b1raw = b1 - w1 @ (x_mean / x_std)
    w3raw = y_std * w3
    b3raw = y_std * b3 + y_mean
    actual = relu(relu(x_raw @ w1raw.T + b1raw) @ w2.T + b2) @ w3raw.T + b3raw
    return {"random_fixture_max_abs_error": float(np.max(np.abs(expected - actual)))}


def main() -> None:
    payload = CSV.read_bytes()
    data = np.loadtxt(CSV, delimiter=",", skiprows=1)
    manifest = json.loads((PART / "data_manifest.json").read_text())
    split = split_audit(data, manifest)
    counts = {
        "model_rows": 7 * 272,
        "coalition_values": 7 * 272 * 256,
        "primary_hybrid_predictions": 7 * 272 * 256 * 64,
        "averaged_coordinates_per_method": 7 * 272 * 8,
        "stored_deepshap_pair_coordinates": 7 * 272 * 64 * 8,
        "bounded_author_pairs": 7 * 2 * 64,
        "bounded_author_coordinates": 7 * 2 * 64 * 8,
    }
    result = {
        "audit_kind": "independent pre-fit protocol audit; no model fitting",
        "source": {
            "bytes": len(payload),
            "sha256": hashlib.sha256(payload).hexdigest(),
            "shape": list(data.shape),
            "finite": bool(np.isfinite(data).all()),
            "unique_first_8_columns": int(len(np.unique(data[:, :8], axis=0))),
            "unique_all_9_columns": int(len(np.unique(data, axis=0))),
        },
        "split": {key: value for key, value in split.items() if key != "regenerated"},
        "background": background_audit(split["regenerated"]["train"]),
        "counts": counts,
        "toy_math": toy_math_audit(),
        "normalization_fold": folding_audit(),
        "protocol_sha256": hashlib.sha256((PART / "protocol.md").read_bytes()).hexdigest(),
    }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()

<!-- ARENA:cell markdown -->

# [16.9] Influence Functions and TracIn

Which training images helped a prediction, and what changes if we remove them?

This lesson follows one question through three different experiments: slightly
change an example's weight, follow the loss along training, and actually retrain
without that example. You will derive and implement each calculation before
comparing them on real handwritten digits.

By the end, you should be able to:

- compute influence with a Hessian-vector product and a checked linear solve;
- explain what regularization changes in a leave-one-out approximation;
- distinguish exact single-example path accounting, its Taylor approximation and TracInCP;
- identify helpful and harmful images for a particular query, then test a deletion policy;
- recognize when an approximation's sign or ranking fails.

You should be comfortable with gradients, matrix multiplication and the training
loop from original ARENA [0.3 Optimization](../../../chapter0_fundamentals/exercises/part3_optimization/0.3_Optimization_exercises.ipynb).
Section [16.7](../part7_data_shapley_in_one_training_run/README.md) supplies the nearby data-value
question. An influence score is not a Shapley value: keep the perturbation and
training procedure in view.

This is the mathematical foundation of a section still under construction.
The real-data comparisons and complete publication checks are not finished.

<!-- ARENA:cell code -->

```python
from pathlib import Path
from collections.abc import Callable
import math
import os
import sys

import numpy as np
import torch
from torch import Tensor
import torch.nn.functional as F
import matplotlib.pyplot as plt
from IPython import get_ipython

if get_ipython() is not None:
    get_ipython().run_line_magic("matplotlib", "inline")

ROOT = next(p for p in [Path.cwd(), *Path.cwd().parents] if (p / "chapter16_shapley_attribution_baselines").exists())
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from chapter16_shapley_attribution_baselines.exercises.part9_influence_and_tracin import attribution_methods_tests as tests
from chapter16_shapley_attribution_baselines.exercises.part9_influence_and_tracin.attribution_data import load_study_data

DTYPE = torch.float64
torch.set_num_threads(4)
OUTPUT = Path(os.environ.get("ARENA_ATTRIBUTION_OUTPUT_DIRECTORY", "/tmp/arena16_9_foundation"))
OUTPUT.mkdir(parents=True, exist_ok=True)
plt.rcParams.update({"figure.figsize": (10, 4), "axes.spines.top": False, "axes.spines.right": False, "font.size": 11})

def show_figure(figure, name):
    figure.tight_layout()
    figure.savefig(OUTPUT / f"{name}.png", dpi=150, bbox_inches="tight")
    plt.show()
```

<!-- ARENA:cell markdown -->

## A familiar image can carry the wrong training label

These are actual UCI handwritten images. We deliberately flip twelve training
labels in one experimental condition and retain a clean-label condition as a
control. The true source labels remain available. An attribution method only
receives the labels used for training; it does not receive the corruption mask.

Before running the cell, predict whether a mislabeled image must hurt every
query. Consider a query from each class. “Helpful” will always be relative to a
particular loss, label and model, rather than an intrinsic property of an image.

<!-- ARENA:cell code -->

```python
data = load_study_data()
train = data["train"]
fig, axes = plt.subplots(1, 4, figsize=(10, 3))
for ax, (digit, flipped) in zip(axes, [(1, False), (1, True), (7, False), (7, True)]):
    index = torch.nonzero((train["digit"] == digit) & (train["flipped"] == flipped)).flatten()[0].item()
    ax.imshow(train["images"][index], cmap="gray_r", vmin=0, vmax=1, interpolation="nearest")
    observed = 7 if train["corrupted_y"][index] else 1
    ax.set_title(f"Source: {digit}  |  training label: {observed}")
    ax.set_xlabel(train["ids"][index], fontsize=9)
    ax.set_xticks([])
    ax.set_yticks([])
show_figure(fig, "attribution_training_images")
```

<!-- ARENA:cell markdown -->

## 1️⃣ Start with a loss you can differentiate

Let $x_i\in\mathbb{R}^p$ include a final constant coordinate for the bias, and
let $y_i\in\{0,1\}$. Our logistic model predicts $p_i=\sigma(x_i^T\theta)$.
The per-example negative log-likelihood is

$$\ell_i(\theta)=\operatorname{softplus}(x_i^T\theta)-y_i x_i^T\theta.$$

We use $R(\theta)=\lambda\|\theta\|^2/2$, including the bias. Write
$q_i=\ell_i+R$. This convention will matter when an example is removed.
Queries use $\ell$, without the regularizer: we want their prediction loss.

Take the derivative on paper. Each example contributes one vector, not one
scalar and not an already averaged batch gradient.

<!-- ARENA:cell markdown -->

### Exercise 1 — Keep the per-example gradients

```text
Difficulty: 🔴🔴🔴⚪⚪
Importance: 🔵🔵🔵🔵⚪

You should spend 15–20 minutes on this exercise.
```

Implement losses shaped `[examples]` and gradients shaped `[examples, parameters]`. With `l2=0`, return data losses/gradients. With positive `l2`, include $R$ in every example. Do not take a mean inside either function.

<details><summary>Help</summary>

The derivative of softplus is sigmoid. Each row has gradient $(\sigma(x_i^T\theta)-y_i)x_i+\lambda\theta$. A common bug is adding the regularizer after averaging incorrectly; the mean of your gradient rows must equal the gradient of the mean of your loss rows.

</details>

<details><summary>Expected output</summary>

Both checks print a success message. The loss check includes logits of magnitude 1000; confident correct predictions must stay finite and near zero.

</details>

<details><summary>Solution</summary>

```python
def logistic_losses(theta: Tensor, x: Tensor, y: Tensor, l2: float = 0.0) -> Tensor:
    """Unreduced per-example losses, optionally including R(theta) in each row."""
    if theta.ndim != 1 or x.ndim != 2 or x.shape[1] != theta.numel() or y.shape != (len(x),):
        raise ValueError("Expected theta [parameters], x [examples, parameters], y [examples].")
    if not ((y == 0) | (y == 1)).all() or not math.isfinite(l2) or l2 < 0:
        raise ValueError("Use binary labels and a finite nonnegative regularizer.")
    logits = x @ theta
    return F.softplus(logits) - y * logits + 0.5 * l2 * theta.square().sum()

def logistic_gradients(theta: Tensor, x: Tensor, y: Tensor, l2: float = 0.0) -> Tensor:
    """Per-example parameter gradients; their mean is the objective gradient."""
    logistic_losses(theta, x, y, l2)  # Validate the common public contract.
    residual = torch.sigmoid(x @ theta) - y
    return residual[:, None] * x + l2 * theta[None, :]
```

</details>

<!-- ARENA:cell code -->

```python
def logistic_losses(theta: Tensor, x: Tensor, y: Tensor, l2: float = 0.0) -> Tensor:
    'Unreduced per-example losses, optionally including R(theta) in each row.'
    raise NotImplementedError()

def logistic_gradients(theta: Tensor, x: Tensor, y: Tensor, l2: float = 0.0) -> Tensor:
    'Per-example parameter gradients; their mean is the objective gradient.'
    raise NotImplementedError()

tests.test_logistic_losses(logistic_losses)
tests.test_logistic_gradients(logistic_gradients)
```

<!-- ARENA:cell markdown -->

## 2️⃣ Make the counterfactual objective explicit

For nonnegative weights $a_i$ with positive total mass, define

$$F_a(\theta)=\frac{\sum_i a_i\ell_i(\theta)}{\sum_i a_i}+R(\theta).$$

Setting one weight to zero removes that image while preserving the specified
regularization strength. Multiplying all weights by nine leaves the objective
unchanged. By contrast, dividing by the original $n$ after removal and retaining
the same $R$ changes the relative penalty.

We will refit many counterfactuals. Give every fit its own row of weights and
parameters. Sharing matrix operations is useful; sharing its objective denominator
with another fit would change the experiment.

<!-- ARENA:cell markdown -->

### Exercise 2 — Compute the weighted objective and its curvature

```text
Difficulty: 🔴🔴🔴⚪⚪
Importance: 🔵🔵🔵🔵⚪

You should spend 20–25 minutes on this exercise.
```

Use `theta [fits, parameters]`, `weights [fits, examples]` and one shared input matrix. Return one objective per fit, then gradients `[fits, parameters]` and Hessians `[fits, parameters, parameters]`. Reject negative weights and zero-mass fits.

<details><summary>Help</summary>

Normalize each row of weights separately. The scalar curvature of logistic loss is $p_i(1-p_i)$, so each input contributes a scaled outer product $x_ix_i^T$. Add $\lambda I$ to every Hessian. Common mistake: forgetting that the bias is regularized in this lesson.

</details>

<details><summary>Expected output</summary>

The checks compare every fit against independent autograd derivatives. Rescaling all weights changes neither the objective nor its relative regularization.

</details>

<details><summary>Solution</summary>

```python
def weighted_objective(theta: Tensor, x: Tensor, y: Tensor, weights: Tensor, l2: float) -> Tensor:
    """One independent normalized objective per row of theta [fits, parameters]."""
    if theta.ndim != 2 or x.ndim != 2 or theta.shape[1] != x.shape[1]:
        raise ValueError("Expected theta [fits, parameters] and x [examples, parameters].")
    if weights.shape != (len(theta), len(x)) or y.shape != (len(x),):
        raise ValueError("Expected weights [fits, examples] and y [examples].")
    if not torch.isfinite(weights).all() or (weights < 0).any() or (weights.sum(1) <= 0).any():
        raise ValueError("Every fit needs finite nonnegative weights with positive total mass.")
    if not ((y == 0) | (y == 1)).all() or not math.isfinite(l2) or l2 < 0:
        raise ValueError("Use binary targets and a finite nonnegative regularizer.")
    probabilities = weights / weights.sum(1, keepdim=True)
    logits = theta @ x.T
    return ((F.softplus(logits) - y[None, :] * logits) * probabilities).sum(1) + 0.5 * l2 * theta.square().sum(1)

def objective_derivatives(theta: Tensor, x: Tensor, y: Tensor, weights: Tensor, l2: float) -> tuple[Tensor, Tensor]:
    """Gradient and dense Hessian of each independently weighted objective."""
    weighted_objective(theta, x, y, weights, l2)
    mass = weights / weights.sum(1, keepdim=True)
    probabilities = torch.sigmoid(theta @ x.T)
    gradient = ((probabilities - y[None, :]) * mass) @ x + l2 * theta
    curvature = probabilities * (1 - probabilities) * mass
    hessian = torch.einsum("np,bn,nq->bpq", x, curvature, x)
    hessian = hessian + l2 * torch.eye(x.shape[1], dtype=x.dtype, device=x.device)
    return gradient, hessian
```

</details>

<!-- ARENA:cell code -->

```python
def weighted_objective(theta: Tensor, x: Tensor, y: Tensor, weights: Tensor, l2: float) -> Tensor:
    'One independent normalized objective per row of theta [fits, parameters].'
    raise NotImplementedError()

def objective_derivatives(theta: Tensor, x: Tensor, y: Tensor, weights: Tensor, l2: float) -> tuple[Tensor, Tensor]:
    'Gradient and dense Hessian of each independently weighted objective.'
    raise NotImplementedError()

tests.test_weighted_objective(weighted_objective)
tests.test_objective_derivatives(objective_derivatives)
```

<!-- ARENA:cell markdown -->

## 3️⃣ Curvature changes which directions are expensive

A positive-definite Hessian describes the local resistance to moving the model.
The same gradient can produce a large parameter response along a weak-curvature
direction and a small response along a strong one. A plain gradient dot product
ignores this distinction.

For large models, storing every entry of $H$ is impractical. To compute $Hv$,
first project $v$ onto each input, weight by curvature, then map back to parameter
space. The following operation never needs a `[parameters, parameters]` array.

<!-- ARENA:cell markdown -->

### Exercise 3 — Multiply by the Hessian without forming it

```text
Difficulty: 🔴🔴🔴⚪⚪
Importance: 🔵🔵🔵🔵⚪

You should spend 10–15 minutes on this exercise.
```

Implement one Hessian-vector product for a single fitted parameter vector. Keep the same normalized weights and regularizer as Exercise 2.

<details><summary>Help</summary>

Compute $X^T[c\odot(Xv)]+\lambda v$, where $c_i=(a_i/\sum_j a_j)p_i(1-p_i)$. A common mistake is using the labels as curvature weights; labels affect the gradient but the logistic Hessian at fixed parameters depends on $p_i$.

</details>

<details><summary>Expected output</summary>

The result matches an independent derivative of a directional gradient. It has shape `[parameters]`.

</details>

<details><summary>Solution</summary>

```python
def logistic_hvp(theta: Tensor, x: Tensor, y: Tensor, weights: Tensor, vector: Tensor, l2: float) -> Tensor:
    """An objective Hessian-vector product without materializing a Hessian."""
    if theta.ndim != 1 or vector.shape != theta.shape or weights.shape != (len(x),):
        raise ValueError("Use one parameter vector, one matching direction and one example-weight vector.")
    weighted_objective(theta[None], x, y, weights[None], l2)
    probabilities = torch.sigmoid(x @ theta)
    curvature = weights / weights.sum() * probabilities * (1 - probabilities)
    return x.T @ (curvature * (x @ vector)) + l2 * vector
```

</details>

<!-- ARENA:cell code -->

```python
def logistic_hvp(theta: Tensor, x: Tensor, y: Tensor, weights: Tensor, vector: Tensor, l2: float) -> Tensor:
    'An objective Hessian-vector product without materializing a Hessian.'
    raise NotImplementedError()

tests.test_logistic_hvp(logistic_hvp)
```

<!-- ARENA:cell markdown -->

### Exercise 4 — Solve a curvature system and check the residual

```text
Difficulty: 🔴🔴🔴⚪⚪
Importance: 🔵🔵🔵🔵⚪

You should spend 20–25 minutes on this exercise.
```

Implement conjugate gradients using only a `matvec` function. Return the solution and a residual-norm history. Stop only when the actual residual meets `atol + rtol * norm(rhs)`. Reject nonpositive curvature and raise when the iteration budget is exhausted.

<details><summary>Help</summary>

Initialize $x=0$, $r=b-Ax$, $p=r$. Each step uses $\alpha=(r^Tr)/(p^TAp)$, then updates $x,r$ and $p$. Check a zero right-hand side before dividing by its norm. Recurrence residuals can drift, so verify $\|b-Ax\|$ before declaring success.

</details>

<details><summary>Expected output</summary>

A small positive-definite system matches a dense solve. A negative-definite system and an insufficient iteration budget fail explicitly.

</details>

<details><summary>Solution</summary>

```python
def conjugate_gradient(
    matvec: Callable[[Tensor], Tensor], rhs: Tensor, rtol: float = 1e-10,
    atol: float = 1e-12, max_steps: int | None = None,
) -> tuple[Tensor, Tensor]:
    """Solve an SPD system, returning the actual residual norms at every step."""
    if rhs.ndim != 1 or not torch.isfinite(rhs).all():
        raise ValueError("The right-hand side must be one finite vector.")
    if not all(math.isfinite(t) and t >= 0 for t in (rtol, atol)):
        raise ValueError("Residual tolerances must be finite and nonnegative.")
    max_steps = 2 * rhs.numel() if max_steps is None else max_steps
    if max_steps < 1:
        raise ValueError("Allow at least one CG step.")
    answer = torch.zeros_like(rhs)
    residual = rhs - matvec(answer)
    direction = residual.clone()
    squared_norm = residual @ residual
    threshold = atol + rtol * torch.linalg.vector_norm(rhs)
    history = [torch.linalg.vector_norm(residual)]
    if history[-1] <= threshold:
        return answer, torch.stack(history)
    for _ in range(max_steps):
        product = matvec(direction)
        curvature = direction @ product
        if not torch.isfinite(curvature) or curvature <= 0:
            raise ValueError("CG encountered nonpositive curvature; its SPD assumption failed.")
        alpha = squared_norm / curvature
        answer = answer + alpha * direction
        residual = residual - alpha * product
        # A recurrence residual can drift: success is checked against A @ answer.
        actual_norm = torch.linalg.vector_norm(rhs - matvec(answer))
        history.append(actual_norm)
        if actual_norm <= threshold:
            return answer, torch.stack(history)
        next_squared_norm = residual @ residual
        direction = residual + (next_squared_norm / squared_norm) * direction
        squared_norm = next_squared_norm
    raise RuntimeError(f"CG did not converge: residual {float(history[-1]):.3g} exceeds {float(threshold):.3g}.")
```

</details>

<!-- ARENA:cell code -->

```python
def conjugate_gradient(
    matvec: Callable[[Tensor], Tensor], rhs: Tensor, rtol: float = 1e-10,
    atol: float = 1e-12, max_steps: int | None = None,
) -> tuple[Tensor, Tensor]:
    'Solve an SPD system, returning the actual residual norms at every step.'
    raise NotImplementedError()

tests.test_conjugate_gradient(conjugate_gradient)
```

<!-- ARENA:cell code -->

```python
rotation = torch.tensor([[.8, -.6], [.6, .8]], dtype=DTYPE)
H = rotation @ torch.diag(torch.tensor([.4, 4.], dtype=DTYPE)) @ rotation.T
g = torch.tensor([1., .5], dtype=DTYPE)
response, residuals = conjugate_gradient(lambda v: H @ v, g)
u, v = np.meshgrid(np.linspace(-3, 3, 150), np.linspace(-3, 3, 150))
points = torch.tensor(np.stack([u, v], -1), dtype=DTYPE)
energy = .5 * torch.einsum("...p,pq,...q->...", points, H, points)
fig, axes = plt.subplots(1, 2, figsize=(10, 4))
axes[0].contour(u, v, energy.numpy(), levels=[.25, .5, 1, 2, 4, 8], colors=".7")
for vector, label, color in [(g, "Identity-curvature control", "#d95f02"), (response, "Hessian-aware response", "#1f77b4")]:
    axes[0].arrow(0, 0, *vector.tolist(), width=.025, color=color, length_includes_head=True, label=label)
axes[0].set(xlabel="Parameter 1", ylabel="Parameter 2", aspect="equal", title="Same gradient, different geometry")
axes[0].legend(fontsize=8)
axes[1].semilogy(range(len(residuals)), residuals.clamp_min(1e-16), "o-", label="CG actual residual")
axes[1].axhline(float(torch.linalg.vector_norm(g)), color="#d95f02", ls="--", label="Zero-solution control")
axes[1].set(xlabel="CG step", ylabel="Residual norm")
axes[1].legend(fontsize=9)
show_figure(fig, "attribution_curvature_solve")
```

<!-- ARENA:cell markdown -->

<details><summary>Interpretation — does a small residual prove the scientific approximation?</summary>

It proves that we solved this linear system accurately. It does not prove that
the fitted model is stationary, that its local Hessian describes a large change,
or that a checkpoint score predicts removal. We will check those questions with
separate experiments. The identity-curvature arrow shows what is lost if the
inverse Hessian is discarded.

</details>

<!-- ARENA:cell markdown -->

### Exercise 5 — Actually refit the counterfactual models

```text
Difficulty: 🔴🔴🔴⚪⚪
Importance: 🔵🔵🔵🔵⚪

You should spend 25–35 minutes on this exercise.
```

Implement independent Newton refits from zero for every weight row. Use your weighted objective and derivatives, an individual Armijo line search for each fit, and a strict maximum-coordinate gradient tolerance. Preserve parameter states and residuals for plotting.

<details><summary>Help</summary>

Solve `H step = gradient`, then propose `theta - rate * step`. Halve only the rates of fits that fail sufficient decrease. Freeze already converged rows. Near an optimum, predicted loss decreases can be smaller than floating-point roundoff; permit eight machine epsilons times `max(1, abs(loss))` in the comparison, while still requiring the original gradient tolerance. A common bug is reporting convergence because the step became tiny.

</details>

<details><summary>Expected output</summary>

All counterfactual optima match independent SciPy root solves. Every final gradient is at most 1e-10, and a one-update budget fails. Batching must not turn several objectives into one pooled fit.

</details>

<details><summary>Solution</summary>

```python
def fit_weighted_logistic(
    x: Tensor, y: Tensor, weights: Tensor, l2: float = 0.02,
    tolerance: float = 1e-10, max_steps: int = 60,
) -> dict[str, Tensor]:
    """Independently refit every row of weights from zero using Newton/Armijo.

Batching shares matrix operations, not fitted parameters or loss reductions.
Each fit keeps its own line search and convergence decision. No failed fit is
silently accepted. Regularization stays fixed after normalization of weights.
"""
    if weights.ndim != 2 or l2 <= 0 or not math.isfinite(l2):
        raise ValueError("Use weights [fits, examples] and a strictly positive regularizer.")
    if tolerance <= 0 or not math.isfinite(tolerance) or max_steps < 1:
        raise ValueError("Use a positive residual tolerance and iteration budget.")
    theta = torch.zeros(weights.shape[0], x.shape[1], dtype=x.dtype, device=x.device)
    states, residuals = [], []
    for _ in range(max_steps + 1):
        loss = weighted_objective(theta, x, y, weights, l2)
        gradient, hessian = objective_derivatives(theta, x, y, weights, l2)
        norms = torch.linalg.vector_norm(gradient, ord=float("inf"), dim=1)
        states.append(theta.clone())
        residuals.append(norms)
        active = norms > tolerance
        if not active.any():
            return {"theta": theta, "states": torch.stack(states), "gradient_norms": torch.stack(residuals), "objective": loss}
        if len(states) > max_steps:
            break
        step = torch.linalg.solve(hessian, gradient.unsqueeze(-1)).squeeze(-1)
        step[~active] = 0
        decrement = (gradient * step).sum(1)
        rates = torch.ones(len(theta), dtype=x.dtype, device=x.device)
        accepted = ~active
        proposed = theta.clone()
        for _ in range(30):
            trial = theta - rates[:, None] * step
            trial_loss = weighted_objective(trial, x, y, weights, l2)
            # Near the optimum, the predicted decrease can be below one ulp.
            # Allow objective roundoff while still requiring the final gradient
            # tolerance; otherwise a vanishing step can stall a correct refit.
            roundoff = 8 * torch.finfo(x.dtype).eps * loss.abs().clamp_min(1)
            sufficient = trial_loss <= loss - 1e-4 * rates * decrement + roundoff
            newly_accepted = sufficient & ~accepted
            proposed[newly_accepted] = trial[newly_accepted]
            accepted |= sufficient
            if accepted.all():
                break
            rates[~accepted] *= 0.5
        if not accepted.all():
            raise RuntimeError("Newton line search failed; retain the failure instead of accepting an unfinished refit.")
        theta = proposed
    raise RuntimeError(f"Newton did not converge for every fit; largest gradient is {float(norms.max()):.3g}.")
```

</details>

<!-- ARENA:cell code -->

```python
def fit_weighted_logistic(
    x: Tensor, y: Tensor, weights: Tensor, l2: float = 0.02,
    tolerance: float = 1e-10, max_steps: int = 60,
) -> dict[str, Tensor]:
    'Independently refit every row of weights from zero using Newton/Armijo.\n\nBatching shares matrix operations, not fitted parameters or loss reductions.\nEach fit keeps its own line search and convergence decision. No failed fit is\nsilently accepted. Regularization stays fixed after normalization of weights.'
    raise NotImplementedError()

tests.test_fit_weighted_logistic(fit_weighted_logistic)
```

<!-- ARENA:cell markdown -->

## 4️⃣ Differentiate through an optimum

At a stationary optimum, $\nabla F(\hat\theta)=0$. Perturb the objective to
$F(\theta)+\epsilon q_i(\theta)$ and differentiate its stationarity equation:

$$H\frac{d\hat\theta}{d\epsilon}+\nabla q_i(\hat\theta)=0.$$

A query loss then has derivative

$$I_{\mathrm{up}}(i,q)=-\nabla\ell_q(\hat\theta)^T H^{-1}\nabla q_i(\hat\theta).$$

A positive number means that upweighting this training row increases the query
loss. For a first-order removal estimate, multiply by $-1/n$. That removal loss
change is positive for a helpful example. Write the sign convention beside your
plot; otherwise two equivalent analyses can appear to disagree.

This is the local calculation in [Koh and Liang (2017)](https://proceedings.mlr.press/v70/koh17a.html).
Our queries and counterfactuals below are a new teaching example.

<!-- ARENA:cell markdown -->

### Exercise 6 — Compute the signed influence matrix

```text
Difficulty: 🔴🔴🔴⚪⚪
Importance: 🔵🔵🔵🔵⚪

You should spend 15–20 minutes on this exercise.
```

Return influence shaped `[training examples, queries]`. Solve for the query directions once, then dot them with every training gradient. Support nonnegative added damping, but do not claim damping leaves the exact derivative unchanged.

<details><summary>Help</summary>

Use a linear solve rather than an explicit matrix inverse. Check symmetry and positive definiteness. A common sign error is forgetting the leading minus: this function returns the derivative under upweighting, not a helpfulness score.

</details>

<details><summary>Expected output</summary>

The predictions match central differences of independent exact quadratic optima, including both signs and unequal training/query counts.

</details>

<details><summary>Solution</summary>

```python
def upweight_influence(hessian: Tensor, train_gradients: Tensor, query_gradients: Tensor, damping: float = 0.0) -> Tensor:
    """d(query loss)/d epsilon for F + epsilon * one regularized training loss."""
    p = hessian.shape[0]
    if hessian.shape != (p, p) or train_gradients.ndim != 2 or query_gradients.ndim != 2:
        raise ValueError("Use a square Hessian and two example-by-parameter gradient matrices.")
    if train_gradients.shape[1] != p or query_gradients.shape[1] != p:
        raise ValueError("Every gradient must refer to the same parameter coordinates.")
    if not math.isfinite(damping) or damping < 0:
        raise ValueError("Damping must be finite and nonnegative.")
    if not torch.allclose(hessian, hessian.T, rtol=1e-10, atol=1e-12):
        raise ValueError("The objective Hessian must be symmetric.")
    system = hessian + damping * torch.eye(p, dtype=hessian.dtype, device=hessian.device)
    torch.linalg.cholesky(system)  # Fail explicitly if the local SPD premise fails.
    response = torch.linalg.solve(system, query_gradients.T)
    return -train_gradients @ response
```

</details>

<!-- ARENA:cell code -->

```python
def upweight_influence(hessian: Tensor, train_gradients: Tensor, query_gradients: Tensor, damping: float = 0.0) -> Tensor:
    'd(query loss)/d epsilon for F + epsilon * one regularized training loss.'
    raise NotImplementedError()

tests.test_upweight_influence(upweight_influence)
```

<!-- ARENA:cell code -->

```python
small_x = torch.tensor([[1., 0., 1.], [0., 2., 1.], [-1., 1., 1.], [2., -1., 1.], [.3, .8, 1.]], dtype=DTYPE)
small_y = torch.tensor([1., 0., 0., 1., 1.], dtype=DTYPE)
n = len(small_x)
l2 = .3
base = fit_weighted_logistic(small_x, small_y, torch.ones(1, n, dtype=DTYPE), l2)
theta = base["theta"][0]
_, hs = objective_derivatives(theta[None], small_x, small_y, torch.ones(1, n, dtype=DTYPE), l2)
qx = torch.tensor([[.2, 1.4, 1.]], dtype=DTYPE)
qy = torch.zeros(1, dtype=DTYPE)
g_query = logistic_gradients(theta, qx, qy)
g_full = logistic_gradients(theta, small_x, small_y, l2)
g_raw = logistic_gradients(theta, small_x, small_y)
influence = upweight_influence(hs[0], g_full, g_query)[:, 0]
wrong_normalization = upweight_influence(hs[0], g_raw, g_query)[:, 0]
strengths = torch.linspace(-1, 1, 25, dtype=DTYPE)
example = 1
weights = torch.ones(len(strengths), n, dtype=DTYPE)
weights[:, example] += strengths
refits = fit_weighted_logistic(small_x, small_y, weights, l2)
actual_loss = F.softplus(refits["theta"] @ qx.T).flatten()
base_loss = logistic_losses(theta, qx, qy)[0]
actual_change = actual_loss - base_loss
fig, axes = plt.subplots(1, 2, figsize=(11, 4))
axes[0].plot(strengths, actual_change, color="black", label="Independently refitted")
axes[0].plot(strengths, strengths / n * influence[example], "--", label="Matched-objective derivative")
axes[0].plot(strengths, strengths / n * wrong_normalization[example], ":", color="#d95f02", label="Data-gradient-only control")
axes[0].axhline(0, color=".6", lw=.8)
axes[0].axvline(-1, color=".6", lw=.8)
axes[0].set(xlabel="Change in one row's relative weight", ylabel="Change in query loss", title="-1 removes the row")
axes[0].legend(fontsize=8)
for label, values in [("Correct derivative", strengths / n * influence[example]), ("Wrong normalization", strengths / n * wrong_normalization[example])]:
    axes[1].plot(strengths, (actual_change - values).abs(), label=label)
axes[1].set(xlabel="Change in one row's relative weight", ylabel="Absolute approximation error")
axes[1].legend(fontsize=8)
show_figure(fig, "attribution_weight_perturbation")
tests.test_regularized_removal_normalization()
```

<!-- ARENA:cell markdown -->

<details><summary>Interpretation — why is the orange control different even near zero?</summary>

The solid line refits the normalized weighted objective with the same penalty.
Its infinitesimal direction includes the regularizer in the perturbed row.
The orange derivative instead upweights only its data loss. It differentiates a
different objective. Matching that derivative perfectly would still fail to
answer this experiment's question. Farther from zero, even the correctly matched
linear approximation has curvature error; the actual refits show its size.

</details>

## 5️⃣ Follow what happened during training

An optimum-based derivative does not explain the particular training trajectory.
For single-example SGD, every update has an identifiable training row. Assign
its observed query-loss reduction to that row. The assignments telescope to
the total reduction from initialization to the final state.

This exact accounting is the starting point for [TracIn](https://proceedings.neurips.cc/paper/2020/hash/e6385d39ec9394f2f3a354d9d2b88eec-Abstract.html).
A positive score means the training visits reduced the specified query loss.
It does not mean removing the example and retraining must increase that loss.

<!-- ARENA:cell markdown -->

### Exercise 7 — Record the optimization path

```text
Difficulty: 🔴🔴🔴⚪⚪
Importance: 🔵🔵🔵🔵⚪

You should spend 15–20 minutes on this exercise.
```

Implement single-example SGD, preserving the zero initialization, every following state, the exact row visitation order and the learning rate for every update. Validate that each epoch is a permutation of the training rows.

<details><summary>Help</summary>

An epoch learning rate is repeated once per training example. Apply the gradient of the regularized row loss. Common mistake: storing only the state after each update, which loses the first observed loss reduction.

</details>

<details><summary>Expected output</summary>

Every stored state matches an independent autograd training loop. An invalid epoch permutation fails.

</details>

<details><summary>Solution</summary>

```python
def sgd_trace(x: Tensor, y: Tensor, orders: Tensor, epoch_rates: Tensor, l2: float) -> dict[str, Tensor]:
    """Record the actual single-example optimization path, starting at zero."""
    if orders.ndim != 2 or orders.shape[1] != len(x) or epoch_rates.shape != (len(orders),):
        raise ValueError("Provide one permutation and one learning rate for every epoch.")
    expected = torch.arange(len(x), device=orders.device).expand_as(orders)
    if not torch.equal(orders.sort(dim=1).values, expected):
        raise ValueError("Each epoch must visit every training example exactly once.")
    if not torch.isfinite(epoch_rates).all() or (epoch_rates <= 0).any():
        raise ValueError("Epoch learning rates must be finite and strictly positive.")
    used_ids = orders.flatten()
    rates = epoch_rates.repeat_interleave(len(x))
    states = torch.zeros(len(used_ids) + 1, x.shape[1], dtype=x.dtype, device=x.device)
    with torch.no_grad():
        for t, index in enumerate(used_ids.tolist()):
            gradient = logistic_gradients(states[t], x[index:index + 1], y[index:index + 1], l2)[0]
            states[t + 1] = states[t] - rates[t] * gradient
    return {"states": states, "used_ids": used_ids, "rates": rates}
```

</details>

<!-- ARENA:cell code -->

```python
def sgd_trace(x: Tensor, y: Tensor, orders: Tensor, epoch_rates: Tensor, l2: float) -> dict[str, Tensor]:
    'Record the actual single-example optimization path, starting at zero.'
    raise NotImplementedError()

tests.test_sgd_trace(sgd_trace)
```

<!-- ARENA:cell markdown -->

### Exercise 8 — Attribute actual and first-order loss reductions

```text
Difficulty: 🔴🔴🔴⚪⚪
Importance: 🔵🔵🔵🔵⚪

You should spend 20–30 minutes on this exercise.
```

Return exact and first-order scores for every training-row/query pair, plus all per-step values. Include the full update gradient in the approximation. Also return a raw-data-gradient-only control. Check that the supplied states really follow the stated SGD updates.

<details><summary>Help</summary>

The Taylor loss reduction is $\eta_t\nabla\ell_q(\theta_t)^T\nabla q_i(\theta_t)$. For a logistic query, its gradient is its residual times its input, so you can avoid storing a `[steps, queries, parameters]` tensor. Use `index_add_` to sum visits into their actual training rows. Exact minibatch allocation is a different problem; do not silently split exact loss equally across a batch.

</details>

<details><summary>Expected output</summary>

Exact scores telescope separately for each query. First-order steps match autograd products. Changing the chunk size preserves every score; a tampered trajectory fails.

</details>

<details><summary>Solution</summary>

```python
def trace_loss_reductions(
    states: Tensor, used_ids: Tensor, rates: Tensor, train_x: Tensor, train_y: Tensor,
    query_x: Tensor, query_y: Tensor, l2: float, chunk_size: int = 128,
) -> dict[str, Tensor]:
    """Actual loss accounting and its Taylor approximation along recorded SGD.

The exact allocation is well-defined here because each update uses one row.
The calculation includes that update's regularizer contribution. The raw-only
control deliberately omits it. No tensor of per-step per-query full gradients
is needed: a logistic query gradient is its residual times its input vector.
"""
    steps = len(used_ids)
    if states.ndim != 2 or len(states) != steps + 1 or rates.shape != (steps,):
        raise ValueError("Every update needs a before/after state, training ID and learning rate.")
    if used_ids.dtype != torch.int64 or (used_ids < 0).any() or (used_ids >= len(train_x)).any():
        raise ValueError("Recorded training IDs must be valid integer row indices.")
    if chunk_size < 1 or not torch.isfinite(rates).all() or (rates <= 0).any():
        raise ValueError("Use a positive chunk size and positive finite learning rates.")
    exact_steps, first_order_steps, raw_steps = [], [], []
    for start in range(0, steps, chunk_size):
        stop = min(start + chunk_size, steps)
        before, after = states[start:stop], states[start + 1:stop + 1]
        x = train_x[used_ids[start:stop]]
        y = train_y[used_ids[start:stop]]
        raw_gradient = (torch.sigmoid((before * x).sum(1)) - y)[:, None] * x
        gradient = raw_gradient + l2 * before
        if not torch.allclose(after - before, -rates[start:stop, None] * gradient, rtol=1e-9, atol=1e-12):
            raise ValueError("Recorded states do not follow the stated single-example SGD update.")
        before_logits, after_logits = before @ query_x.T, after @ query_x.T
        before_loss = F.softplus(before_logits) - query_y[None, :] * before_logits
        after_loss = F.softplus(after_logits) - query_y[None, :] * after_logits
        query_residual = torch.sigmoid(before_logits) - query_y[None, :]
        exact_steps.append(before_loss - after_loss)
        first_order_steps.append(rates[start:stop, None] * query_residual * (gradient @ query_x.T))
        raw_steps.append(rates[start:stop, None] * query_residual * (raw_gradient @ query_x.T))
    exact_steps = torch.cat(exact_steps)
    first_order_steps = torch.cat(first_order_steps)
    raw_steps = torch.cat(raw_steps)
    shape = (len(train_x), len(query_x))
    def collect(values):
        return torch.zeros(shape, dtype=states.dtype, device=states.device).index_add_(0, used_ids, values)
    return {
        "exact": collect(exact_steps), "first_order": collect(first_order_steps), "raw_only": collect(raw_steps),
        "exact_steps": exact_steps, "first_order_steps": first_order_steps, "raw_only_steps": raw_steps,
    }
```

</details>

<!-- ARENA:cell code -->

```python
def trace_loss_reductions(
    states: Tensor, used_ids: Tensor, rates: Tensor, train_x: Tensor, train_y: Tensor,
    query_x: Tensor, query_y: Tensor, l2: float, chunk_size: int = 128,
) -> dict[str, Tensor]:
    "Actual loss accounting and its Taylor approximation along recorded SGD.\n\nThe exact allocation is well-defined here because each update uses one row.\nThe calculation includes that update's regularizer contribution. The raw-only\ncontrol deliberately omits it. No tensor of per-step per-query full gradients\nis needed: a logistic query gradient is its residual times its input vector."
    raise NotImplementedError()

tests.test_trace_loss_reductions(trace_loss_reductions)
```

<!-- ARENA:cell code -->

```python
orders = torch.stack([torch.randperm(n, generator=torch.Generator().manual_seed(100 + epoch)) for epoch in range(15)])
epoch_rates = torch.cat([torch.full((8,), .12, dtype=DTYPE), torch.full((7,), .04, dtype=DTYPE)])
trace = sgd_trace(small_x, small_y, orders, epoch_rates, .3)
path_scores = trace_loss_reductions(trace["states"], trace["used_ids"], trace["rates"], small_x, small_y, qx, qy, .3)
fig, axes = plt.subplots(1, 2, figsize=(11, 4))
for key, label, style in [("exact_steps", "Observed loss reduction", "-"), ("first_order_steps", "First-order full update", "--"), ("raw_only_steps", "Omit regularizer control", ":")]:
    axes[0].plot(torch.cumsum(path_scores[key][:, 0], 0), style, label=label)
axes[0].set(xlabel="Training update", ylabel="Cumulative query-loss reduction")
axes[0].legend(fontsize=8)
pos = np.arange(n)
for offset, key, label in [(-.25, "exact", "Exact path"), (0, "first_order", "Taylor"), (.25, "raw_only", "Raw-only control")]:
    axes[1].bar(pos + offset, path_scores[key][:, 0], width=.25, label=label)
axes[1].axhline(0, color="black", lw=.7)
axes[1].set(xlabel="Training row", ylabel="Assigned query-loss reduction", xticks=pos)
axes[1].legend(fontsize=8)
show_figure(fig, "attribution_exact_training_path")
```

<!-- ARENA:cell markdown -->

## 6️⃣ Replace a long path with saved checkpoints

TracInCP replaces gradients at actual visits by gradients evaluated at selected
checkpoints. It sums learning-rate-weighted products across those checkpoints.
It does not preserve exact telescoping, and a checkpoint subset does not account
for training visits that it omits. We will retain early, late, all and last-only
choices instead of choosing whichever agrees best with final outcomes.

<!-- ARENA:cell markdown -->

### Exercise 9 — Compute TracInCP scores

```text
Difficulty: 🔴🔴🔴⚪⚪
Importance: 🔵🔵🔵🔵⚪

You should spend 10–15 minutes on this exercise.
```

Take training gradients `[checkpoints, training examples, parameters]`, query gradients with the analogous query axis, and a vector of checkpoint learning rates. Return the weighted score for each training/query pair.

<details><summary>Help</summary>

Multiply gradient matrices within the same checkpoint, weight that checkpoint, then sum. Common mistakes: pairing gradients from different checkpoints, averaging away the learning-rate scale, and treating a checkpoint heuristic as an exact observed loss reduction.

</details>

<details><summary>Expected output</summary>

The hand-computed unequal-axis example returns [[1.2, 2.4], [-2.1, 1.9], [-0.2, 1.9]]. Reordering checkpoints with their rates leaves the answer unchanged.

</details>

<details><summary>Solution</summary>

```python
def tracin_checkpoint_scores(train_gradients: Tensor, query_gradients: Tensor, rates: Tensor) -> Tensor:
    """Weighted gradient products; positive means first-order loss reduction.

The input is [checkpoints, examples, parameters]. Rates are actual checkpoint
learning-rate weights. A checkpoint subset covers only its selected visits;
this function does not rescale scores to pretend they sum to observed loss.
"""
    if train_gradients.ndim != 3 or query_gradients.ndim != 3:
        raise ValueError("Keep checkpoint, example and parameter axes distinct.")
    k, _, p = train_gradients.shape
    if query_gradients.shape[0] != k or query_gradients.shape[2] != p or rates.shape != (k,) or k == 0:
        raise ValueError("Checkpoint counts, parameter coordinates and rate counts must match.")
    if not torch.isfinite(rates).all() or (rates < 0).any():
        raise ValueError("Use finite nonnegative learning-rate weights.")
    return torch.einsum("knp,kqp,k->nq", train_gradients, query_gradients, rates)
```

</details>

<!-- ARENA:cell code -->

```python
def tracin_checkpoint_scores(train_gradients: Tensor, query_gradients: Tensor, rates: Tensor) -> Tensor:
    'Weighted gradient products; positive means first-order loss reduction.\n\nThe input is [checkpoints, examples, parameters]. Rates are actual checkpoint\nlearning-rate weights. A checkpoint subset covers only its selected visits;\nthis function does not rescale scores to pretend they sum to observed loss.'
    raise NotImplementedError()

tests.test_tracin_checkpoint_scores(tracin_checkpoint_scores)
```

<!-- ARENA:cell code -->

```python
checkpoint_theta = trace["states"][n::n]
train_gradients = torch.stack([logistic_gradients(t, small_x, small_y, .3) for t in checkpoint_theta])
query_gradients = torch.stack([logistic_gradients(t, qx, qy) for t in checkpoint_theta])
choices = {"All epochs": slice(None), "Early epochs": slice(0, 8), "Late epochs": slice(8, None), "Last epoch": slice(-1, None)}
fig, axes = plt.subplots(1, 2, figsize=(11, 4))
for label, selected in choices.items():
    scores = tracin_checkpoint_scores(train_gradients[selected], query_gradients[selected], epoch_rates[selected])[:, 0]
    axes[0].plot(pos, scores, "o-", label=label)
    axes[1].scatter(path_scores["exact"][:, 0], scores, label=label)
axes[0].axhline(0, color=".5", lw=.8)
axes[0].set(xlabel="Training row", ylabel="Checkpoint score", xticks=pos)
axes[0].legend(fontsize=8)
axes[1].axhline(0, color=".7", lw=.8)
axes[1].axvline(0, color=".7", lw=.8)
axes[1].set(xlabel="Exact observed path contribution", ylabel="Checkpoint score")
axes[1].legend(fontsize=8)
show_figure(fig, "attribution_checkpoint_choices")
```

<!-- ARENA:cell markdown -->

<details><summary>Interpretation — why are these not all on the diagonal?</summary>

The checkpoint calculation evaluates a training row at an epoch endpoint instead
of its actual visit. Early-only and late-only scores cover different pieces of
training; last-only uses just one checkpoint. The exact path uses the observed
updates. Similar rankings can be useful even when scales differ, but neither
ranking agreement nor a scatter correlation establishes an exact deletion effect.

</details>

## 7️⃣ A faster gradient product for an affine layer

For one affine invocation, a weight gradient is an outer product of a
preactivation derivative and an input. Its dot product with another example's
weight gradient factors into two much smaller dot products. The bias contributes
one additional preactivation-gradient dot product. This is the gradient-product
identity behind a useful memory saving; derive it before implementing it.

A tied layer applied at several token positions has a sum of outer products.
Its product contains all cross-position terms. The one-invocation identity below
must not be applied to it by summing only matching positions.

<!-- ARENA:cell markdown -->

### Exercise 10 — Compute the affine gradient product without flattening it

```text
Difficulty: 🔴🔴🔴⚪⚪
Importance: 🔵🔵🔵🔵⚪

You should spend 10–15 minutes on this exercise.
```

Return all left-example/right-example gradient dot products using only layer inputs and preactivation derivatives. Support bias and bias-free affine layers. This exercise concerns the layer data-loss gradients; shared regularizers are separate contributions.

<details><summary>Help</summary>

Use $\langle\delta a^T,\delta\prime a\prime^T\rangle=(\delta^T\delta\prime)(a^Ta\prime)$. With a bias, add one to the input dot product before multiplying. Common mistake: adding the two factor products instead of multiplying them.

</details>

<details><summary>Expected output</summary>

Both bias settings match full autograd gradients through a nonlinear loss. Unequal numbers of examples on the two sides prevent an accidental elementwise shortcut.

</details>

<details><summary>Solution</summary>

```python
def ghost_linear_products(left_inputs: Tensor, left_deltas: Tensor, right_inputs: Tensor, right_deltas: Tensor, bias: bool = True) -> Tensor:
    """Exact gradient products for one affine layer with one invocation per example.

Deltas differentiate scalar losses with respect to preactivations. This is not
a formula for tied parameters used at several token positions; those require
all pairs of positions. Shared regularizers are also separate gradient terms.
"""
    arrays = (left_inputs, left_deltas, right_inputs, right_deltas)
    if any(a.ndim != 2 for a in arrays):
        raise ValueError("Inputs and preactivation derivatives must be two-dimensional.")
    if len(left_inputs) != len(left_deltas) or len(right_inputs) != len(right_deltas):
        raise ValueError("Every example needs its own input and preactivation derivative.")
    if left_inputs.shape[1] != right_inputs.shape[1] or left_deltas.shape[1] != right_deltas.shape[1]:
        raise ValueError("Both sides must describe the same affine layer.")
    return (left_inputs @ right_inputs.T + int(bias)) * (left_deltas @ right_deltas.T)
```

</details>

<!-- ARENA:cell code -->

```python
def ghost_linear_products(left_inputs: Tensor, left_deltas: Tensor, right_inputs: Tensor, right_deltas: Tensor, bias: bool = True) -> Tensor:
    'Exact gradient products for one affine layer with one invocation per example.\n\nDeltas differentiate scalar losses with respect to preactivations. This is not\na formula for tied parameters used at several token positions; those require\nall pairs of positions. Shared regularizers are also separate gradient terms.'
    raise NotImplementedError()

tests.test_ghost_linear_products(ghost_linear_products)
```

<!-- ARENA:cell markdown -->

## Try It Yourself — make the first-order approximation fail

Change the learning-rate multiplier below. Predict what happens to the Taylor
error and whether the helpful/harmful assignment can change. This reruns training
and loss accounting; the exact path remains the control. Keep a stable small-step
case beside the larger step. A large mismatch is an outcome to explain.

Then change `query_row` or flip `query_label`. The image is not intrinsically
helpful: its assigned effect depends on the question asked of the model.

<!-- ARENA:cell code -->

```python
learning_rate_multiplier = 4.0
query_row = 2
query_label = 1.0
play_x = small_x[query_row:query_row + 1]
play_y = torch.tensor([query_label], dtype=DTYPE)
fig, axes = plt.subplots(1, 2, figsize=(11, 4))
for multiplier, color in [(1.0, "#1f77b4"), (learning_rate_multiplier, "#d95f02")]:
    changed_trace = sgd_trace(small_x, small_y, orders, epoch_rates * multiplier, .3)
    changed_scores = trace_loss_reductions(changed_trace["states"], changed_trace["used_ids"], changed_trace["rates"], small_x, small_y, play_x, play_y, .3)
    exact = changed_scores["exact_steps"][:, 0].cumsum(0)
    linear = changed_scores["first_order_steps"][:, 0].cumsum(0)
    axes[0].plot(exact, color=color, label=f"Exact, rate × {multiplier:g}")
    axes[0].plot(linear, "--", color=color, label=f"Taylor, rate × {multiplier:g}")
    axes[1].plot((exact - linear).abs(), color=color, label=f"Rate × {multiplier:g}")
axes[0].set(xlabel="Training update", ylabel="Cumulative query-loss reduction")
axes[1].set(xlabel="Training update", ylabel="Absolute cumulative Taylor error")
for ax in axes:
    ax.legend(fontsize=8)
show_figure(fig, "attribution_step_size_play")
```

<!-- ARENA:cell markdown -->

## What the foundation establishes

You have implemented an optimum derivative, a real training path and a checkpoint
heuristic, and checked each against its own mathematical target. The small
fixtures make signs, normalization and failures inspectable. They do not yet
show that the rankings predict useful interventions on real data.

The next stage will train the digit classifier, retain all leave-one-out refits,
compare image galleries and evaluate deletion policies using separate ranking
and final queries. The prospective settings are in `native_protocol.md`. That
stage and the complete paired notebook publication are still in development.

Further questions to keep beside the results: Does a mislabeled example always
harm this query? Does local derivative accuracy survive a large deletion? Does
changing the training order change a checkpoint ranking even when the converged
objective has a unique optimum?

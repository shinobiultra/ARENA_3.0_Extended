# ARENA 3.0 Extended Salvage Handoff

Snapshot date: 2026-09-06 (Asia/Tokyo)

## Current work — 16.9 foundation complete, digit study pending

This is the next active work after the completed 11.5 checkpoint below. The full
course goal remains active. Original chapters and the selected syllabus remain
binding. No subagents were requested or used. Preserve the dirty tree and the
user's unrelated GPU process. The new work runs on CPU.

The new development directory is
`chapter16_shapley_attribution_baselines/exercises/part9_influence_and_tracin`.
The canonical `lesson.md` has **39 cells, 17 code cells, ten exercise groups,
twelve student functions, thirteen immediate check calls, six controlled figures
and one editable play**. This is a mathematical foundation, not a released
native section. Influence, TracIn and GhostSuite remain UNIMPLEMENTED.

`attribution_methods.py` exposes per-example logistic losses/gradients,
independently weighted objectives and derivatives, a Hessian-vector product,
checked conjugate gradients, independent batched Newton refits, signed upweight
influence, exact SGD states, exact/Taylor path accounting, TracInCP and affine
gradient products. `class_matched_removals` is also implemented and tested but
still needs its learner exercise. All core method bodies used by the foundation
are visible in the lesson's solution dropdowns. `build_notebooks.py` fills stubs
only from those answers; `execute_learner.py` currently reports foundation scope.

The own-answer run at
`/home/bitwise/.cache/arena_extended/data_attribution/own-foundation-v3`
passes all seventeen code cells in **4.127 s**, with all eight inputs unchanged
during execution. The preceding polished v2 run passes in 4.517 s. All six
current figures are byte-identical to inspected v2 figures. Browser checks open
33 dropdowns and render 36 math expressions without errors. All seven v2 views
and the credited v3 data/derivation views were inspected. The 17 current method
and data tests pass, including independent SciPy root, autograd, exact quadratic,
telescoping, corrupted-trajectory and source-data checks.

The six figures show real labelled digit images, curvature and CG residuals,
actual refit versus influence curves with a local-derivative zoom, exact versus
Taylor training-path contributions, all declared foundation checkpoint choices,
and a learning-rate/query play. Controls include identity curvature, zero solve,
wrong regularization normalization, omitted regularizer in SGD, exact path and
smaller learning rate. In particular, the local zoom exposes a nonvanishing
error for the mismatched normalization. These fixtures establish the mathematics;
they do not yet establish real-digit attribution performance.

The first test collection failed on a module import path, which was corrected.
An independent five-row refit test then exposed a Newton line search stalling at
3.56e-10 because rounded losses rejected the final useful step. An eight-machine-
epsilon objective allowance fixes that issue while retaining the 1e-10 gradient
criterion. The initial figure review found overlapping image titles and an
insufficiently resolved derivative comparison; both were repaired. Preserve the
failed/intermediate evidence rather than overwriting it.

Read-back archives are under the part's `development_evidence`:
`own_foundation_v1` (17 members), `own_foundation_v2` and `own_foundation_v3`
(27 members each), plus `checkpoint_v1` for tests, current source/protocol and
integration logs. No external tensor payload is needed for these foundation
archives. Raw UCI source files stay in
`/home/bitwise/.cache/arena_extended/data_attribution` with pinned hashes.
Do not rerun the one-time cache writer over `lesson.md`; it predates the polished
figures, wrapped prose and explicit dataset credit.

### Prospective real-data protocol

The full primary methods and relevant supplements for Koh/Liang influence and
Pruthi et al. TracIn were read, including the regularization convention, exact
single-row path accounting, minibatch limitation, checkpoint heuristic and
factored affine gradient product. The original 0.3 optimization learner and
existing 16.7 exercise/solution/page were inspected before the plan was written.
Keep the released 16.7 lesson unchanged.

`native_protocol.md`, `attribution_data.py` and `data_manifest.json` specify the
next study before any digit-model fit. UCI's original training/test files are
pinned by SHA-256. The test file matches sklearn's independent bundled copy.
Digit 1/7 selection is outcome-independent: 128 training, 48 ranking and 64
final examples, with original train/test writer groups separated. No exact
pixel duplicates occur among selected images. The clean and deliberately
12/128-flipped training-label conditions retain original labels and row IDs.
The manifest SHA-256 is
`a009ed80855932e774a427cc0b727cb30cfdfa7c228b1d5d7b7dee8f569b0a7c`.

Use 65 parameters (pixels / 16 plus bias), float64, lambda .02 including the
bias, and independently converged Newton refits from zero. Six complete SGD
paths cover clean/corrupted labels and order seeds 0/1/2, each with 40 epochs,
rate .05 for twenty epochs and .01 for twenty. Retain all/early/late/last epoch
checkpoint choices. Query losses omit regularization; the training row gradient
includes it so deletion matches the normalized fixed-penalty objective.

For each label condition, refit all 128 leave-one-out models and twelve prescribed
weight-perturbation examples at eight sizes. Retain all damping and convergence
controls. Forty-eight class-matched deletion policies cover influence, gradient,
signed pixel similarity, actual ranking-query leave-one-out, twelve checkpoint
policies and 32 random seeds. Evaluate budgets 2/4/8/16/32. Ranking queries alone
choose deletion sets; fixed final galleries use the first two source rows per
class. All cases, errors and random draws remain. Details and exact source
citations are in the protocol. No digit model has been fitted, and no digit-query
loss has been evaluated. Raw final data/labels are loaded for hashing only.

After own v3, the protocol's opening was clarified to say "digit-model" fitting
and distinguish the five-row mathematical fixtures. This changes no scientific
setting or learner code. `protocol-scope-clarification.json` records that exact
prose-only difference. The original protocol bytes remain in all run snapshots.
No repeated model execution is needed for that clarification.

### Concrete completion route

1. Implement a readable native orchestration module whose method calls can be
   copied into the notebook and bound to the student's functions. Snapshot every
   scientific source and the prospective manifest before fitting. Begin with
   ranking queries only; do not select settings from final outcomes.
2. Run both label conditions, all six SGD paths, all prescribed reference,
   deletion and reweighting refits. Verify each convergence residual, exact path
   telescoping, all first-order steps and individual-versus-batched refit parity.
   Keep the actual states, IDs, scores, losses and probabilities in run artifacts.
3. Append the class-matched removal exercise and visible native analysis to the
   learner: actual-image helpful/harmful galleries, all leave-one-out scatter
   panels, wrong-sign cases, damping/convergence curves, checkpoint/path comparison
   and final matched-deletion curves with every random control. Add a real query
   play. Derive the normalization and separate the different estimands in prose.
4. Finish and execute the complete own-answer notebook, including the predeclared
   final stage only after every fit and deletion policy is frozen. Do not claim
   checkpoint scores are exact removal effects or that this convex digit model
   reproduces large nonconvex neural experiments.
5. Add an independent fresh source reload, retraining and every-counterfactual
   reproduction. Compare actual outputs, not a saved scalar report. Inspect the
   complete rendered learner and all native figures, then publish paired notebooks,
   page/assets and the normal CPU report through the existing course gates.
6. Only then update the corresponding selected-topic rows. GhostSuite is
   conditional on a full visible gradient-product learner/reference comparison;
   this foundation alone is not sufficient. Datamodels, dataset cartography,
   multi-step In-Run Shapley and Adam-aware attribution remain separate open work.

The last complete course checkpoint has 43 TAUGHT, 36 PREFLIGHT_ONLY, 20 TOY_ONLY,
13 DEFERRED and 93 UNIMPLEMENTED requirements. The separate readability gate
still reports 78 older issues, with none in this new part. Do not narrow the full
course goal to this foundation or to passing structural checks.

## Current checkpoint — 11.5 Contrast-Consistent Search complete

This checkpoint supersedes all earlier CCS development and publication status
below. Continue the full active goal. Original chapters and the selected syllabus
are binding; legacy extension implementation may be replaced. Preserve the dirty
tree. No subagents were requested or used. Do not broadly stage, reset, commit
or push. The user's unrelated GPU job remains untouched; CCS runs on CPU.

### Current learner

`chapter11_representation_geometry/exercises/part5_contrast_consistent_search/11.5_Contrast_Consistent_Search_exercises.ipynb`
is published with its paired solutions notebook, fifteen assets and
`chapter11_representation_geometry/instructions/pages/05_[11.5]_Contrast_Consistent_Search.md`.
The canonical source is the part's `lesson.md`. Both course configurations,
root README, method registry, hard-exercise ladder and style registry include it.

The 65-cell learner contains 32 code cells, nine exercise groups, twelve
student-implemented functions with immediate checks, fifteen controlled figures
and two editable plays. Help, expected-output, interpretation and solution
dropdowns follow the original ARENA examples. The method is visible: mean-only
branch centering, the original asymmetric loss, independent restart fitting,
unlabelled selection, calibration-only orientation, PCA, padding-safe token
capture, paired opinion changes and actual full-vocabulary metrics. Every
restart and random control remains visible. Plays vary the exact distractor's
strength and an actual GPT-2 review with an independently changed reader opinion.

### Scientific result and scope

Frozen GPT-2 revision `607a30d783dfa663caf39e06633721c8d4cfcd7e` runs on CPU in
float32 with eager attention; reporter fitting uses float64. The predeclared
split has 256 training base reviews and 64 each for calibration, development
and final. Final uses new frames and adjective pairs. All three sites, two
wrappers and three text conditions are retained. Ten centered, ten raw and ten
shuffled-pair CCS restarts, PCA, supervised logistic and 32 random directions
produce 64 reporters per condition. Training loss selects restarts; only
calibration labels orient unsupervised reporters. Final is now evaluated and
was never used for selection, refitting, recentering or orientation.

Plain customer layer 8 CCS gets 64/64 final targets right. When an independent
reader's opinion is added, every selected CCS condition has 50% target accuracy
and flips on all 64 paired opinion changes. Supervised controls retain
103/128 to 128/128 target accuracy. The figures expose this failure beside raw,
shuffled-pair, PCA and every matched random control; those controls sometimes
find useful structure too. Restricted two-answer output accuracy is separate
from GPT-2's actual next token: none of the 512 final unrestricted winners is
the requested sentiment word, and mean candidate probability mass ranges from
about 0.044% to 1.14%. The actual review gallery shows the examples and outputs.

These are controlled adjective-based reviews, not a truth or belief benchmark,
causal necessity result, whole-paper replication or claim about larger models.
There are 64 distinct final base reviews, 512 repeated contrast pairs, 98,304
reporter scores, and 3,586 actual full-vocabulary prefix outputs across all
splits plus play. Do not call the reporter scores full-vocabulary predictions.

### Current execution and evidence

All paths in this paragraph are under `/home/bitwise/.cache/arena_extended/ccs`.
`full-own-answer-v3` passes all 32 code cells in **224.500 s** with all thirteen
scientific inputs unchanged. `fresh-native-v4` independently reloads the model,
recaptures features and refits all **1,152 reporters** in **228.792 s**. All
**5,408 tensor comparisons**, scalar comparisons and token winners match exactly;
all fourteen fresh inputs and model weights remain unchanged, with no gradients.
Every one of the fifteen PNGs and the complete native summary is byte-identical
to the polished v2 learner. V3 only improves method-test explanations and success
feedback; test inputs, oracles and mathematical predicates are unchanged.
The current browser render opens all 34 dropdowns and renders 33 math expressions
without errors. Fifteen figures and eight screenshots have been inspected.

The current normal `verification_report.json` is accepted with no known failures.
It explicitly reuses `fresh-native-v4`: `native_evidence_reused=true` and
`native_model_reloaded_in_this_report=false`. Before reuse, it verifies all
fourteen scientific sources, all 43 fresh tensor files, learner identity and
published notebook/page/figure hashes. Running without the reuse environment
variable performs another independent native run. This avoids redundant model
execution during a publication-only refresh without claiming a new reload.

Read-back-verified archives in the part's `expected_outputs` are
`full_own_answer_v3`, `fresh_native_v4`, `normal_report_source_v2` and
`release_gate_v3`. The source archive preserves all 47 exact normal-report input
files plus the report. Each full model run has 43 external tensor files totaling
851,618,524 bytes; their hashes, sizes and persistent cache paths are recorded
in the archive manifest. Do not delete these cache directories.
Current normal-report fresh evidence SHA-256:
`34d376e70a5868ce3204eb73534eb6b702708a8b33cd536ef28f371aba916df3`.
Current learner evidence SHA-256:
`1f1407df131b90e097b5aad5b51f64c26f48b3e6a85a03561cbef30030d32cb3`.

Historical own v1/v2 and fresh v1/v3/normal-v1 archives remain. Fresh v2 was
interrupted by SIGTERM after sixteen cases; the cause is unknown. Its original
RUNNING record and explicit interruption record are archived under
`development_evidence/fresh_native_interrupted_v2`; it is not release evidence.
No CCS model process remains running.

### Checks and remaining work

The current focused suite passes **96 tests**. Original preservation, course
surface (13 chapters), style depth (50 pages), exercise ladder (49 rows) and
evidence contracts (52 reports) pass. Original chapters 0–4 remain unchanged
against `f9f034bdb5b8748f44e8b4533b5c5bea68dc8bc0`.
The 205-item roadmap now has **43 TAUGHT, 36 PREFLIGHT_ONLY, 20 TOY_ONLY,
13 DEFERRED and 93 UNIMPLEMENTED**. Its 93 blockers are exactly the remaining
UNIMPLEMENTED items. The separate readability audit has 78 older issues and
none in CCS. Passing the current section's checks does not complete the course.

Next selected work is influence functions and TracIn. The concrete preparation
is in `docs/arena_salvage/2026-09-06_data_attribution_next_plan.md`: extend the
existing data-attribution material with visible influence and checkpoint-gradient
implementations, real training images, all leave-one-out retraining effects and
matched deletion controls. Primary papers and the original optimization learner
have been located; the full paper reading and a prospective native protocol
remain to do. Do not promote those requirements on the existing 16.7 toy study.

## Historical checkpoint — 11.4 concept erasure complete

This checkpoint supersedes the older next-topic and completion counts below.
Continue the full active goal. Original chapters and the selected syllabus are
binding; legacy extension implementation may be replaced. Preserve the dirty
tree. No subagents were requested or used. Do not broadly stage, reset, commit
or push. The user's unrelated GPU job remains untouched; this section runs on CPU.

### Active continuation — 11.5 CCS foundation and native development complete

Continue from
`docs/arena_salvage/2026-09-06_ccs_next_plan.md`, which records the exact completion
route. The new `chapter11_representation_geometry/exercises/part5_contrast_consistent_search`
is an **unpublished development section**, still UNIMPLEMENTED in the roadmap.
Its canonical foundation `lesson.md` has 32 cells, 16 code cells, six implementation
groups, nine immediate check calls, seven controlled figures and one play.
Ten standalone method checks and three pinned-author primitive comparisons pass.
The source author revision is `be10d7b912b17e8eacb45de794e9dca044e4ed37`.

`/home/bitwise/.cache/arena_extended/ccs/own-foundation-v2` executes all own
answers in a fresh kernel: **PASS 9.172 s**, all six inputs unchanged. All seven
figures were inspected, and the current browser review opens 23 dropdowns and
renders 31 math expressions without errors. The exact counterexample exposes
an independent distractor with the same consistency structure as the target.
Default loss selection picks the distractor despite another seed finding the
target. Independent restart batching is checked against separate fits.

`ccs/native-development-v1` performs actual frozen GPT-2 extraction and fitting:
**PASS 197.444 s**, all 18 site/wrapper/variant cases and 64 reporters per case
retained, all six scientific inputs and model weights unchanged, no gradients.
Data were specified before first native access: 256 training base reviews,
64 calibration, 64 development and 64 final. The independent reader's opinion
is crossed with each customer label. The three sites, two wrappers, centered/
raw/corrupted-pair CCS fits, PCA, supervised and random baselines are all retained.
Only calibration labels orient unsupervised reporters; training loss selects
restarts. No final model evaluation has occurred.

In v1 development, layer 8 reads 62/64 plain customer reviews and 64/64 plain
quoted reviews. With the independent opinion, all six selected CCS reporters
(three sites × two wrappers) have 50% target accuracy and 100% retrospectively
oriented distractor agreement. The supervised probes recover the target perfectly.
These are scoped development results, not final or general truth-discovery claims.

V2 corrects one development template's indefinite article. Train, calibration
and final row hashes are unchanged, and no fitting setting changed. The next
full own-answer run must recapture current development text along with the
predeclared final set. The 512 final contrast pairs are repeated measurements
of 64 base reviews. Across three sites and 64 reporters they yield 98,304
reporter scores; do not call those separate native full-vocabulary predictions.

Read-back-verified foundation/native archives are in part 5's
`development_evidence`; 36 native tensor files stay outside Git at manifest
paths. Source files are `ccs_methods.py`, `ccs_methods_tests.py`,
`reference_parity.py`, `ccs_data.py`, `ccs_native.py`, `native_protocol.md`,
`run_development.py`, `build_notebooks.py`, `execute_learner.py` and `lesson.md`.
Next: append the visible native learner, add paired opinion-flip analysis and
native play, run the complete own-answer notebook, freshly recapture/refit every
condition, inspect renders and publish through the normal course gates. Do not
promote CCS on foundation/development evidence. No CCS process remains running.

After these draft additions, preservation passes with 1,235 changed paths and
zero blockers. Course surface (13 chapters), style (49 pages) and evidence
contracts (51 reports) still pass. The roadmap still has exactly 94 unimplemented
blockers. The current CCS method pytest run passes all 10 tests. These logs and
the v1/v2 data manifests are preserved in part 5's
`development_evidence/checkpoint_v1`. The last separate readability audit has
78 older issues; it is not a whole-course completion pass.

### Learner and scientific result

The complete **52-cell / 24-code-cell** learner is
`chapter11_representation_geometry/exercises/part4_concept_erasure/11.4_Concept_Erasure_exercises.ipynb`,
with its paired solutions notebook and
`chapter11_representation_geometry/instructions/pages/04_[11.4]_Concept_Erasure.md`.
Both course configurations and the root README link it. Canonical source:
`part4_concept_erasure/lesson.md`.

Eight implementation groups teach centered moments, singular whitening,
orthogonal removal, the affine LEACE map, refitted probes, magnitude-matched
random edits and actual full-vocabulary metrics. Eleven immediate checks include
an independent constrained oracle and three pinned-author comparison cases.
Twelve controlled figures and two plays connect exact geometry, nonlinear
counterexamples, refitting, actual GPT-2 answers and collateral damage. The
current browser render has 28 working dropdowns and 42 math expressions without
render errors. Every final figure was inspected individually.

The native experiment uses frozen GPT-2 revision
`607a30d783dfa663caf39e06633721c8d4cfcd7e`, CPU float32/eager attention;
moments and probes use float64. Data: 512 eraser-fitting rows, a separate 320-row
probe-fitting split, 160 development roles, 288 final roles and 384 final
unrelated-object prompts. All definitions predate first native access. Sites
are prescribed block 6 subject and block 9 end, with empirical and fixed .01
covariance fits. Every native error and all random draws remain in the result.

Early empirical LEACE gives zero fitting covariance, yet a newly fitted reader
recovers **286/288** final roles. Late empirical LEACE has 50% reader accuracy
but cross-entropy **5.205**, which is not evidence of unrestricted information
removal. Recipient accuracy changes from **260/288** to **228/288** early or
**214/288** late; unrelated-object accuracy changes from **192/384** to
**191/384** or **96/384**. Controls include old-probe removal, orthogonal
covariance removal, 16 random rank-one edits per site and 16 per-example
norm-matched edits for each LEACE fit per site. Those 106 conditions produce
71,232 final outcomes. The lesson shows refit loss, covariance transfer, edit
size, native KL and token panels beside the accuracies. Shuffled-label fitting
is further research, not an executed control. Single-site edits do not establish
all-layer scrubbing, unique causal identification or statistical independence.

### Execution and evidence

Persistent root: `/home/bitwise/.cache/arena_extended/erasure`.

- `full-own-answer-v1`: full learner **PASS 324.554 s**, all 12 scientific
  inputs unchanged while executing. Later prose refinements preserve the AST of
  all 24 code cells and have a separate current visual review.
- `fresh-native-v1`: independent model reload, recapture, eraser/probe refits
  and full native comparison **PASS 329.615 s**. All **106 conditions / 71,232
  full-vocabulary outputs** agree exactly; no winner mismatches. All 13 source
  inputs and pretrained weights remain unchanged.
- `full-own-answer-v1/visual_review.json` and `html_review_final_v1`: current
  lesson, figures, browser math/dropdown review and screenshots bound by hashes.
- Normal verification report performs another complete fresh CPU run at
  `fresh_reproductions/run-uv_8ru7l/fresh_cpu`: **PASS 302.198 s**, all maps and
  probes refitted, all 71,232 outputs exactly equal, no model gradients.
  Report input hash:
  `be61a0f1a268e7fc0604873b7db9fa64e77dccd43dfa79027d959a4ae237bf6c`.

`expected_outputs` retains verified archives for `full_own_answer_v1`,
`fresh_native_v1`, `fresh_native_normal_v1`, `native_development_v1`,
`own_foundation_v1` and `author_source_revision`. Large `.pt` tensors stay outside
Git at the persistent manifest paths; do not delete them. The full run and each
fresh reproduction require roughly 16 GB of disk. Normal execution command:

```bash
CUDA_VISIBLE_DEVICES='' uv run python scripts/run_extension_verification_reports.py --section 11.4
```

The accepted report, normal-run log, all final gate logs and integration tests,
plus the earlier integration/readability diagnostics, are retained with hashes
in part 4's `expected_outputs/release_gate_v1` (12 read-back-verified files).

Scientific implementation is in `erasure_methods.py`, tests, data/protocol,
`erasure_native.py`, `reference_parity.py` and `lesson.md`. Execution and
publication use `build_notebooks.py`, `execute_learner.py`,
`erasure_reproduction.py`, its guard tests, `publish_study.py`, `solutions.py`
and the artifact lock. Core methods remain visible in the learner. The shared
11.3 native capture/continuation plumbing was reused without modification.

The course-surface audit now recognizes actual separate eraser construction,
inference and edit calls, and singular/plural CPU runtime descriptions. Tests
reject removal of required native calls or controls. Method registry CSV/lock/
Markdown and generator, hard ladders, style status and roadmap are synchronized.
Only `representation.concept_erasure` was promoted by this checkpoint.

### Verified boundary and continuation

Final checks: **70 integration/reproduction-guard tests pass**, plus the normal
report's 11 immediate method tests. Original preservation **PASS** (1,205 changed
paths checked, zero blockers); style **PASS** (49 pages); course surface **PASS**
(13 chapters); hard ladders **PASS** (48 sections); report evidence **PASS**
(51 reports). The roadmap audit has **exactly 94 unimplemented-item blockers**
and no additional course/style/evidence blockers. Counts: **205 requirements,
42 TAUGHT, 36 PREFLIGHT_ONLY, 20 TOY_ONLY, 13 DEFERRED, 94 UNIMPLEMENTED**.
The separate global readability audit still reports **78 older issues**, none in
part 4. Do not casually reformat earlier native source files: doing so invalidates
their source-bound execution evidence.

No model process from 11.4 remains running. The local rendered-preview server on
port 8768 is separate. Next selected topic is `representation.ccs`, already in
the final amended syllabus. Read the completed concept-erasure plan at
`docs/arena_salvage/2026-09-06_concept_erasure_next_plan.md` for exact scope and
historical decisions. The remainder of this handoff retains earlier evidence and
the route to full-course completion. Do not mistake this section checkpoint for
completion of the full user goal.

## Previous checkpoint — full 11.3 learner and fresh native reproduction complete

This checkpoint supersedes every older 11.3 draft statement below. Continue the
full active goal. The user requires the selected topics, preserved original
chapters and original ARENA style; legacy extension implementation is ours to
replace. No subagents were requested or used. Preserve the dirty tree; do not
broadly stage, reset, commit or push it.

### New self-study section and files

`chapter11_representation_geometry/exercises/part3_causal_abstraction_das`
now contains the complete **63-cell / 32-code-cell** CPU learner. Open
`11.3_Causal_Abstraction_and_Distributed_Alignment_Search_exercises.ipynb` or
the paired solution notebook. The page is
`chapter11_representation_geometry/instructions/pages/03_[11.3]_Causal_Abstraction_and_Distributed_Alignment_Search.md`.
Both course configs and root README include it.

Nine implementation groups teach explicit high-level interventions, a thin-QR
subspace swap, the full-vocabulary objective, exact and minibatch alignment,
a differentiable native continuation and an observational ridge probe. Thirteen
immediate tests accompany the methods; seven additional reproduction-guard tests
reject missing/extra conditions, bad shapes, nonfinite logits and invalid bases.
Twelve inspected figures and three plays show exact counterexamples, native
site/rank comparisons, all final controls, generalization and actual tokens.
The prescribed native play fails to change the answer; that failure is retained.

`lesson.md` is canonical. Native additions are `das_ioi_data.py`,
`das_native.py`, `das_training_methods.py`, corresponding tests,
`run_native_development.py`, `run_das_screen.py`, `das_protocol.py` and
`native_protocol.md`. `execute_learner.py` fills the notebook from its own
answers, snapshots all 15 scientific inputs and executes a fresh Jupyter kernel.
`das_reproduction.py` independently reloads the model and checks every final
condition. `publish_study.py` requires that evidence plus actual visual review.
Normal reports use `solutions.py`, `artifacts.lock.yml` and the published hashes.

### Native scientific result and its limits

Pinned GPT-2 revision `607a30d783dfa663caf39e06633721c8d4cfcd7e`, CPU float32,
eager attention, frozen weights. Data: 72 train, 48 development and 96 final
prompts; four interventions per base. Cross-name donors transfer which of the
first two people repeats while the requested answer uses the base's names.
All split definitions predate native access. Six development sites, four ranks
and all controls are retained. Development selected block 9 input, final token,
rank 8, 240 Adam updates, batch 16 and learning rate .01. Final evaluation first
occurred in own run v1 after this choice; later reruns changed no selection.

On all **96 changed cross-name final interventions**, three DAS seeds get
**71/96, 73/96, 72/96**. Whole-position donor gets **72/96**; the observational
mean gets 54/96; the role probe 9/96; no intervention 10/96. All 32 random
rank-eight subspaces are retained (best 11/96), alongside shuffled-target fits
22/96, 28/96 and 27/96. Explicit counterfactual prompts get 76/96: this is a
native reference, not a mathematical upper bound. The separate jointly native-
correct subset contains 56 pairs; it never replaces the unconditional score.
Three display examples were selected by row order before final observation.
Output agreement is neither uniqueness/minimality nor evidence that DAS beats
whole donors. This teaches alignment training with frozen weights, not IIT.

### Execution, review and preserved evidence

Persistent root: `/home/bitwise/.cache/arena_extended/das`.
- `native-checks-v1`, `native-screen-v1`, `native-ranks-v1`,
  `native-controls-v1`: native path/gradient parity and all development results.
- `full-own-answer-v1`: first complete native learner, PASS 292.081 s.
- `full-own-answer-v2`: refined 63-cell learner, PASS 283.183 s.
- **`full-own-answer-v3`: final learner, PASS 306.270 s; all 15 inputs unchanged.**
- **`fresh-native-v4`: independent final reproduction, PASS 47.099 s.**
  All **43 conditions / 16,512 full-vocabulary outputs** agree exactly, with
  zero winning-token mismatches. It executes **17,232 native forward rows**:
  96 baseline, 16,128 cached-tail and 1,008 independent full-hook rows.
  Weights and all seven reproduction inputs are unchanged. Primary IIA is
  recomputed from the actual winning tokens.
- All twelve final figures exactly equal inspected v2. Browser review of current
  native equations, expected-output/solution dropdowns and the signature heading
  is recorded in `full-own-answer-v3/visual_review.json`.

`expected_outputs` contains read-back-verified archives for every development
run and own/fresh candidate, including the earlier parse failure. Large `.pt`
tensors remain at manifest-named persistent paths with recorded hashes.
`normal_report_v3` retains the first normal-report CUDA-initialization failure
and the first accepted CPU report. The failure occurred before the section ran;
an unrelated GPU job occupies device memory. Never stop that job. Use:

```bash
CUDA_VISIBLE_DEVICES='' OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 uv run python scripts/run_extension_verification_reports.py --section 11.3
```

### Course integration and remaining work

Two existing roadmap requirements, `representation.causal_probes_das` and
`representation.causal_abstraction`, now point to the complete 11.3 learner.
The method CSV/Markdown/lock and generator, style status and hard-exercise ladder
are updated. Three stale generator descriptions were synchronized to their
existing verified registry rows; the legacy generator was not run wholesale.
The course-surface checker now recognizes actual DAS continuation and full-hook
calls; seven mutation cases reject incomplete execution paths. CPU reporting
still requires own-answer and independent native-model evidence.

Broader verification-asset tests exposed missing 11.2 schema/fixture metadata,
which was completed without scientific changes. Its new normal CPU report
reproduces all **5,184 outcomes / 108 conditions** again; the fresh source is
`/home/bitwise/.cache/arena_extended/alignment/fresh_reproductions/run-uyk1v864/fresh_cpu`.
Archive: `part2_cca_svcca_alignment/expected_outputs/fresh_cpu_metadata_refresh_v4`;
accepted report/log archive: `expected_outputs/normal_report_metadata_v4`.

Final normal 11.3 report **PASS** performs another fresh CPU execution in
**46.767 s**, reproducing all 16,512 outputs / 43 conditions exactly. Native source:
`das/fresh_reproductions/run-dy2cd_lc/fresh_cpu`; report input hash:
`e3b875be95b10d6809a066b31246cca96e2e3b3ed646f161f6f6d72d762a1891`.
Archive: `expected_outputs/fresh_native_normal_release_v4`. Final report, all
six gate logs, test results and earlier diagnostics are retained with hashes in
`expected_outputs/release_gate_v4`.

Final audits: original preservation **PASS** (1,130 changed paths checked,
zero blockers); style **PASS** (48 pages); hard ladders **PASS** (47 sections);
course surface **PASS** (13 chapters); evidence contracts **PASS** (50 reports).
**56 integration/reproduction-guard tests pass**, plus the normal report's
13 immediate method tests. The earlier integration test ran before the refreshed
normal report had completed and rejected its stale inputs; the final run passes.
No native/model job from this section remains running. The local preview HTTP
server on port 8768 remains available; it is separate from model execution.
The full-roadmap audit remains **FAIL with exactly 95 unimplemented-item
blockers**, and no additional course/style/evidence blockers.
The registry has **205 requirements: 41 TAUGHT, 36 PREFLIGHT_ONLY, 20 TOY_ONLY,
13 DEFERRED, 95 UNIMPLEMENTED**. Whole-course completion remains open.

Next selected work is concept erasure. Read
`docs/arena_salvage/2026-09-06_concept_erasure_next_plan.md`: it connects linear
probe failure, a visible closed-form eraser, nonlinear counterexamples and
native side effects. Only planning/source review has begun; no eraser or new
native final experiment exists. CCS, broader space/time and IIT remain separate
open requirements. Do not promote them from DAS or from a planning document.



## Historical checkpoint — 11.1/11.2 complete and 11.3 foundation only

This supersedes the queued-GPU status below. Continue the full active goal. The
user's constraints are selected topics plus preserved original chapters and their
ARENA style; legacy scaffolding may be replaced. No subagents were requested or
used. The tree remains dirty; do not broadly stage, reset, commit or push it.

### 11.1 corrected full learner and independent CUDA both pass

`chapter11_representation_geometry/exercises/part1_pca_svd_geometry_controls`
now publishes **71 cells / 35 own-answer code cells, eleven exercise groups,
sixteen immediate numerical tests, thirteen inspected figures and four play
cells**. Corrected own run `~/.cache/arena_extended/geometry/full-own-answer-v3`
PASS in **384.4146 s**, all nine declared inputs unchanged. Actual model work:
105,484 main forward rows, 120,649 retained outcomes, 579 new prompts, all 5,634
donor pairs, 32 draws of each of three nulls, 120 nonlinear fits, 3,196 angle-play
rows and four single-play rows. Peak CUDA allocation **13.61124 GiB**. CPU `gelsd`
fixes the earlier least-squares/BF16 repeatability failure.

Two independently loaded native Mistral comparisons PASS, each **6,656 examples /
208 condition batches**, zero calendar-logit error and zero changed full-vocabulary
winners. Runs `geometry/fresh_reproductions/run-xddqswg1/fresh_cuda` and
`run-hp2xauhn/fresh_cuda` took **21.7710 / 21.5343 s**. The latter is the accepted
native source for final documentation. The original queue supervisor PID 748170
has exited successfully; do not restart it. No geometry model job is live.
Another user experiment currently occupies about 22.5 GiB of GPU memory; never
stop unrelated work.

After the full run, 36 of 46 lesson Python blocks were reformatted with **strict
unchanged ASTs**, using Ruff 0.12.11. Ten suggestions which would alter docstring
values were skipped. `expected_outputs/formatting_equivalence_v4.json` records
that formatting step; final strict executed-code comparison is in the release
validator and final render archive. Section numbers were repaired, and a BF16
tie explanation was added. All 178 full-correct/different-calendar-winner rows
are exact tied calendar logits (`argmax_tie_audit.json`). No metric was changed.
Browser inspection checked equations and solution dropdowns. All thirteen final
figure files equal the inspected full-run files.

Primary shift results remain partial: weekday pure/author-mean/full-donor
calendar accuracy **.22449/.45578/.62585**; month **.07176/.51620/.79167**.
Mean-only gives .12925/.08796. Chronological permutations sometimes work; the
month pure-coordinate effect is weak. New-template coordinate R² is
.83557/.97174, falling to .47619/.82176 angular accuracy when a calendar class
is excluded. UMAP transforms new points; t-SNE fits them jointly and is explicitly
transductive. Years, cities and broader space/time experiments remain unfinished.

### Avoid rerunning GPU work for prose edits

The last documentation refresh collided with a newly started unrelated GPU job
and failed on allocation **before comparing any examples**. That attempt is
retained in `expected_outputs/fresh_cuda_resource_failure_v4`. It does not erase
the two successful native runs.

`geometry_reproduction_cache.py` now permits explicit reuse of completed native
evidence. It checks the archived tarball/hash manifest, every retained file, all
six unchanged native scientific sources and their snapshots, the current learner's
strict executed Python equivalence, all 6,656 measured rows, all 208 conditions,
logits and winning tokens. Eight mutation tests reject changed sources, missing
or duplicate rows, changed metadata, logits, tokens and nonfinite values.
Default reporting still launches a new native comparison. For documentation-only
refreshes use:

```bash
ARENA_GEOMETRY_LEARNER_DIRECTORY=/home/bitwise/.cache/arena_extended/geometry/full-own-answer-v3 ARENA_GEOMETRY_REPRODUCTION_MANIFEST=/home/bitwise/Documents/ARENA_3.0_Extended/chapter11_representation_geometry/exercises/part1_pca_svd_geometry_controls/expected_outputs/fresh_cuda_release_v3/manifest.json uv run python scripts/run_extension_verification_reports.py --section 11.1
```

Current normal report **PASS** explicitly records `reused_native_reproduction=true`
and `native_cuda_executed_this_report=false`, with native record/row/manifest
hashes. Never describe this last refresh as new CUDA execution. The native
scientific sources remain unchanged; changing them rejects reuse and requires
new own/fresh execution. Preserve the retained native directory exactly: its
original report is also hash-bound, so **do not overwrite that report** with a
later reuse report. Final documentation-bound report and render validation live
in `expected_outputs/validated_cache_report_v5`. Full/fresh v3 sources and the
older failures are archived with verified member hashes; large own-run tensors
remain in persistent cache.

### Global state

11.1 README, root README, style status, method registry and its generator now
match the Mistral lesson. Only PCA/SVD controls and UMAP/t-SNE validation were
promoted this continuation. Registry: **205 requirements; 39 TAUGHT, 36
PREFLIGHT_ONLY, 20 TOY_ONLY, 13 DEFERRED, 97 UNIMPLEMENTED**. Broader space/time
and DAS/IIT are not promoted.

Latest validation under `~/.cache/arena_extended/geometry`:
- `final-tests-v6.log`: **65 passed**, including both released section tests and
  supporting report/roadmap/ladder/cache tests. An eighth DAS immediate test was
  subsequently added and passed in the complete own-foundation v3.
- `final-contracts-v5.log`: all **49 reports pass** current evidence contracts.
- `final-ladders-v5.log`: all **46 hard ladders pass**.
- `final-style-v6.log`: all **47 pages pass**.
- `final-surface-v4.log`: all **13 chapter surfaces pass**.
- `final-preservation-v6.log`: **1,045 paths checked, zero blockers**; original
  chapters 0–4 at f9f034bdb5b8748f44e8b4533b5c5bea68dc8bc0 untouched.
- `final-roadmap-v6.log`: exactly the **97 known UNIMPLEMENTED blockers**, no
  additional report or registry errors. Two subsequent draft-description edits
  retain those statuses; rerun the lightweight roadmap audit if needed.

Final lightweight recheck after archiving and draft-description updates:
`final-contracts-v7.log` confirms all 49 reports pass; `final-roadmap-v7.log`
confirms exactly 97 unfinished requirements; `final-preservation-v7.log` checks
1,055 paths with zero blockers. `final-draft-and-roadmap-tests-v7.log` passes
all eight DAS tests and ten roadmap tests (18 total). The report-bound native
archives were not modified by these documentation updates.

### 11.3 next work: native-model DAS

New source directory:
`chapter11_representation_geometry/exercises/part3_causal_abstraction_das`.
`lesson.md` is a **29-cell / 14-code** exact-model foundation draft with five
exercise groups, eight mathematical/gradient/training tests, four inspected
figures and an angle play. It exposes all seven methods and the full encoder /
readout. Own-answer v3 `~/.cache/arena_extended/das/own-foundations-v3` PASS in
**4.08325 s**, six declared inputs unchanged. It is not in course navigation and
is explicitly not a pretrained-model result. The code builder can write draft
paired notebooks; the completed actual notebook is inside the persistent run.
All development candidates, including an early plot-string parse failure before
kernel execution, are archived in the part3 `expected_outputs` directory.

The exact model has a used routing coordinate, a side decision and an unused
perfect copy of routing, mixed by an eight-dimensional rotation. Three rank-one
DAS fits achieve 100% held-out IIA on 1,024 fresh-nuisance pairs; an unused-copy
swap has 0% changed-routing IIA, and full-donor swaps damage the side decision.
The 32 random controls average .06372 changed IIA, strongest .59375. Shuffled
supervision's partial effects remain visible. A mean direction also succeeds;
DAS is not necessary for this model. DAS coordinate errors around .21–.23 remain
despite perfect output classes, illustrating limited identifiability.

Continue from `docs/arena_salvage/2026-09-06_causal_alignment_next_plan.md`.
Original IOI notebook and primary method definitions were read. No pretrained
DAS model or new final prompt set has been accessed. Next implement a frozen
GPT-2 differentiable continuation, verify native no-op/donor and gradient parity,
then study a source repetition-role intervention using the base example's names.
Different-name donors test whether the method copies a role or merely a name.
Define fresh final templates before model access; develop layer/position/rank
choices separately and retain all final failures. Keep IIT distinct from learning
an alignment. Read the remaining relevant source details as the native protocol
is finalized. No source PDFs were archived in the repo.

All new runtime/cache directories must remain under `~/.cache/arena_extended`,
not `/tmp`. The optional review server on 127.0.0.1:8768 is only a disposable HTML
preview. The goal remains active; these two released lessons and one draft are
not completion of the whole extension.


## Current checkpoint — 11.2 alignment released; 11.1 queued for shared GPU memory

The user explicitly prioritizes selected topics and the original chapters' exact ARENA style over all legacy scaffolding. Continue the full goal; do not interpret this completed section as completion of the extension. No delegation was explicitly requested and no subagents are running.

**11.2 is now released** under `chapter11_representation_geometry/exercises/part2_cca_svcca_alignment`. Its canonical `lesson.md`, paired `11.2_CCA_SVCCA_and_Representation_Alignment_{exercises,solutions}.ipynb`, and `instructions/pages/02_[11.2]_CCA_SVCCA_and_Representation_Alignment.md` contain 43 cells / 20 executed code cells, eight student-implemented core methods, five implementation groups plus a conceptual exercise, nine figures and three play cells. The browser review checked actual dropdowns, formula rendering and readable code. It caught a malformed multiline norm and dense code; v3 repairs both. `expected_outputs/formatting_equivalence_v3.json` verifies normalized AST equivalence for all 25 Python blocks and nine source files, allowing only docstring indentation changes. The final nine figure files are byte-identical to inspected v2 figures.

Full own-answer v3 `/home/bitwise/.cache/arena_extended/alignment/full-own-answer-v3` PASS in **116.365 s**, all eleven declared inputs unchanged. Native GPT-2 (`607a30d783dfa663caf39e06633721c8d4cfcd7e`, CPU FP32 eager attention) ran 72 train / 48 development / 96 new final prompts, three layer pairs, all 17 method/rank candidates and 16 same-norm null draws per pair. Main experiment: 12,888 forward rows / 12,816 retained outcomes; live play: five additional rows. Every saved KL and winning token agrees with the actual full-vocabulary logits. Methods include rank-aware whitening, CCA, SVCCA, held-out signed correlations, Procrustes, canonical difference transport, ridge, and full-vocabulary KL.

Final result is deliberately partial: at 6→10, unchanged KL is about .61 nats, CCA16 .3480, ridge .3235, shuffled CCA16 .7135. CCA agrees with the native donor's winner on 46/96 prompts, ridge on 62/96. The changed recipient wins on 31/96 CCA, 46/96 ridge and 60/96 native-donor prompts. First fixed gallery rows retain native Mary→John changes which the fitted maps fail to transfer; native donor failures remain too. SVCCA's 99% variance cutoff retains only 8/9/8 canonical dimensions. Training correlations near one do not reliably survive new templates. These are cross-layer results in one checkpoint, not a full IOI circuit or cross-model equivalence claim.

**Independent CPU reproduction and normal report PASS.** Fresh v3 and the normal report each recaptured the model, refitted all maps and compared 108 conditions / 5,184 outcomes across the first and last final batches, with maximum full-logit error **0.0** and zero changed winning tokens. The normal report took 50.008 s, native reproduction 47.700 s, at `/home/bitwise/.cache/arena_extended/alignment/fresh_reproductions/run-jltu82dq/fresh_cpu`. Completed full→fresh→publish→normal pipeline: `/home/bitwise/.cache/arena_extended/alignment/release_pipeline_v3.json`, PASS in 225.728 s; no alignment model job remains live. Preserve source snapshots. Large `.pt` tensors remain in persistent cache; all other run files are archived with verified member hashes under `expected_outputs/own_full_release_v3`, `fresh_cpu_release_v3`, and `fresh_cpu_normal_report_v3`. Earlier runs, Pythia's generic-token development negative, GPT-2 development and an early fresh-check invocation rejected before model loading are retained in the neighboring versioned archives.

The published CPU lesson is explicitly classified as CPU evidence. Report/hard-ladder/final-roadmap audits now accept an explicitly declared CPU model study only with completed own-answer and independent fresh-model evidence; GPU-declared sections retain their CUDA requirement. No CPU budget placeholder is accepted as a model experiment. Surface checks recognize visible native CPU capture/replacement/fit calls and keep report machinery out of the lesson. The GPU inventory tool can still report that CPU sections do not supply CUDA evidence; that is accurate.

Navigation is synchronized in `infrastructure/core/config_extension.yaml` and regenerated `config.yaml`; the original config remains unchanged. Style/hard-ladder/method/roadmap registries and the root README include 11.2. Only `representation.cca_svcca_procrustes` was promoted. Counts: **205 requirements; 37 TAUGHT, 38 PREFLIGHT_ONLY, 20 TOY_ONLY, 13 DEFERRED, 97 UNIMPLEMENTED**. Nine numerical tests and 37 supporting audit tests passed (one subsequent registry mapping correction reran all ten roadmap tests successfully). Course surface and all 47 style pages pass. Original preservation PASS, 1,025 paths checked at the final audit. Global reports/ladders/completeness still fail for 11.1's known failed/stale report, plus the 97 unimplemented requirements. Do not claim global completion.

**11.1 current GPU queue:** the HTTP Mistral download is complete in `/home/bitwise/.cache/arena_extended/geometry/model_cache`. `run_when_gpu_available.py` is running as PID 748170 (revalidate the PID; processes may end between continuations), with `pipeline_state.json` and `pipeline.log` in the same persistent directory. It waits for 16,000 MiB free; the last check had about 1,594 MiB because another user experiment is using the GPU. Never stop that unrelated work. The previous PID 508292 had ended before this continuation, so the queue was resumed only after confirming no existing geometry runner. No corrected full v3 geometry output existed when it resumed. The queue will run full own learner → publisher → normal report automatically.

Keep these nine queued 11.1 inputs frozen: `lesson.md`, `geometry_methods.py`, `geometry_methods_tests.py`, `geometry_study.py`, `geometry_data.py`, `geometry_protocol.json`, `geometry_plotting.py`, `build_notebooks.py`, `execute_learner.py`. CPU `gelsd` repair, sixteen tests and foundations v9 already pass. The 11.1 README and style status now honestly say revalidation/prototype; its old published Mistral v1 and failed fresh comparison remain available. After the queue passes, inspect all thirteen outputs, archive the persistent full/fresh run, synchronize metadata and rerun the global gates. Do not rerun the released 5.5, 8.3, 9.1 or 12.3 GPU work unnecessarily.

Next independent work is outlined in `docs/arena_salvage/2026-09-06_causal_alignment_next_plan.md`: selected causal abstraction and Distributed Alignment Search, following 11.2's correlation-versus-intervention distinction. Read the primary sources and closest original IOI section before implementing. Reuse cached GPT-2 on CPU, create a differentiable native path (the current capture helpers use inference mode), use an exact high-level/low-level oracle, and define fresh final prompts before any DAS model access. No DAS model or final dataset has been run yet; no DAS/IIT requirement was promoted. IIT remains a separate training-method requirement.

All new run/cache directories must be persistent under `~/.cache/arena_extended`, not `/tmp`. The optional HTML review server was started on 127.0.0.1:8768 from `alignment/rendered-preview`; it is just a disposable preview, not part of the course runtime. The repository remains intentionally dirty; do not reset, broadly stage or commit inherited changes.

## 2026-09-06 recovery checkpoint — geometry numerical repair awaits durable release run

The current environment no longer contains the previous `/tmp/geometry-*` runs or the completed temporary Mistral HTTP cache. The completed first learner, its figures and measured rows were archived and remain in the repository. The corrected second learner had reached its final cells in the previous tool session, but its execution record was not archived before temporary storage disappeared; do not count that missing run as accepted release evidence. Other published course artifacts and their existing archives remain intact.

11.1 now has a published 71-cell / 35-code / 11-exercise / 13-figure replacement from first full run v1. That v1 completed all 105,484 main model rows, 120,649 retained outcomes, 120 nonlinear fits and 3,200 play rows in 406.129 s at 13.612 GiB. Its fresh comparison failed: default CPU pivoted-QR least squares differed by up to 5.96e-7 across repeated identical fits, producing 0.125 maximum logit error and three changed winning tokens after BF16 rounding. `expected_outputs/reproduction_failure_v1` retains the failure and repeatability proof. Current `geometry_methods.py` and own answers use CPU `gelsd`; 16 numerical tests and foundation v7 passed before the temporary files disappeared. The full corrected run needs re-execution and fresh reproduction from persistent storage.

Persistent geometry work directory: `/home/bitwise/.cache/arena_extended/geometry`. A fresh HTTP-only download is started through `download_checkpoint.py`; inspect `download_state.json`, `download.log` and its live process before retrying. Model cache is `model_cache` there. The default Hugging Face Mistral cache has only valid metadata and incomplete Xet weight blobs, which must not be treated as complete or copied into the HTTP cache. Another user experiment was using the GPU; inspect current GPU/process state before starting the learner and do not stop unrelated work.

Current geometry scientific sources: `lesson.md`, `geometry_methods.py`, `geometry_methods_tests.py`, `geometry_study.py`, `geometry_data.py`, `geometry_protocol.json`, `geometry_plotting.py`; own executor/builder and `geometry_evidence.py`, `geometry_cuda.py`, `publish_study.py` validate and publish actual own-answer results. The first release is archived in `expected_outputs/own_full_release_v1`, the old Pythia lesson in `legacy_pythia_release`, and development sweeps in `mistral_*`. The normal section report currently says FAIL; do not promote this section before the corrected run and fresh comparison pass.

Remaining release work: add explanatory messages to four bare assertions and success feedback to numerical tests; finish the small style checks (current notebook uses em-dash Help labels and semantic result/limitations headings rather than legacy exact strings); run final source once from its own answers in a persistent directory; publish exact outputs; execute normal report with persistent cache; inspect all figures and unchanged controls; archive full/fresh artifacts; synchronize README, method and topic registries, style status and global audits. Original chapters remain untouched. Whole goal remains active, with 98 UNIMPLEMENTED registry topics at the last accepted global audit.

## Current checkpoint — 5.5 text learner released; geometry repair in development

User clarification: preserve the selected topics and original chapters and their **exact ARENA style**. Everything else in the extension, including legacy scaffolding and release rules, may be replaced at our discretion. Avoid spending time reproducing verification-shaped learner content. No delegation has been explicitly requested; no subagents are running.

5.5 is now released: 90 cells / 43 executable code cells / 23 exercise groups / 12 inspected figures / four play cells. Final own-answer run `/tmp/diffusion-text-full-own-answer-release-v1` PASS in 432.090 s with all sixteen inputs unchanged. Twelve fits, 126 final conditions, 64,512 examples, 78 timing conditions / 390 repetitions and all plays ran. Published through `publish_study.py`; numerical builder check PASS. Section tests: 48 original/current tests passed plus the new story-report regression (four audit tests now pass, 49 total tests across the section). No learner source changed after its successful full run.

Normal section report v2 PASS in 160.636 s; fresh CUDA experiment 139.647 s / 0.126704 GiB text peak. All four seed-zero models refit, all 42 configurations / 21,504 examples regenerated; checkpoint and trace maximum errors **0.0**. Actual fresh run `/tmp/arena-diffusion-text-report-um7v_99l/fresh_cuda`. Its 69 non-weight files and source snapshot are archived with verified hashes under `expected_outputs/fresh_cuda_release_v2`; own full source/execution under `own_full_release_v1`. The previous normal report failed only after its CUDA work passed, because aggregation tried to score open-ended stories as exact-answer tasks. That failure and successful CUDA evidence are retained in `report_aggregation_failure_v1`. The fix keeps story reference diagnostics separate from task correctness.

Only `modern.diffusion_language_model` promoted to TAUGHT; DiffusionGemma inference/time interventions remain scoped preflight/unfinished. Registry and README synchronized. Counts: **205 requirements; 36 TAUGHT, 38 PREFLIGHT_ONLY, 20 TOY_ONLY, 13 DEFERRED, 98 UNIMPLEMENTED**. Final roadmap gate has exactly the 98 known UNIMPLEMENTED blockers and no extra failures. All 48 report freshness contracts, 45 hard ladders, 46 style pages and 13 chapter surfaces pass. Preservation PASS (897 paths checked at that point; 180 tracked / 717 untracked), no original chapters changed. Thirteen style/surface regression tests and ten roadmap tests pass. Release IDs are no longer mandatory on lesson pages; truth checks for existing IDs remain.

11.1 geometry is now in active development; see `docs/arena_salvage/2026-09-05_geometry_real_learner_repair_plan.md`. New `lesson.md` is a **32-cell / eight-group foundation draft**, not published. `geometry_methods.py`, `geometry_methods_tests.py`, `build_notebooks.py` and `execute_learner.py` are new development files. Thirteen numerical tests now pass (the last two cover actual native capture and raw versus affine-centered mean ablation). Foundation own-answer v3 `/tmp/geometry-foundations-own-answer-v3` PASSes all 13 code cells and four inspected figures; the method inventory later expanded for the next real-model exercises, so do not call v3 a full current-source release. Previous v1 failed in execution plumbing (`nbformat.from_dict` kept list-valued cell sources); fixed via serialized `nbformat.reads`. Its failed execution record is retained. v2 and v3 foundation methods actually ran from their own answers. Published 47-cell legacy 11.1 notebooks/page remain unchanged.

Mistral weights are now available at `/tmp/arena-geometry-mistral-http-cache-v1/models--mistralai--Mistral-7B-v0.1/snapshots/27d67f1b5f57dc0953326b2601d68371d40ea8da`. Original Xet download stalled with request errors and was terminated (owned PID 2153839); its incomplete files remain untouched. The isolated HTTP download + development supervisor `/tmp/geometry-mistral-pipeline-v2.json` **PASSed** in 1267 s. No download remains live. Use `HF_HUB_CACHE=/tmp/arena-geometry-mistral-http-cache-v1` and `HF_HUB_DISABLE_XET=1` for this model. All other released model caches remain unchanged.

Mistral development `/tmp/geometry-mistral-development-v1` **PASSed in 9.312 s**, peak 13.547 GiB BF16, 49 weekday and 144 month questions. Baseline restricted accuracy 32/49 and 128/144 is close to the paper's 31/49 and 125/144; retain the actual differences. No high/full accuracy was assumed. Captured all 33 native residual input boundaries at the semantic start-word position. Layer-17 five-PC circular probes give held-out-offset R² .9727/.9649, but pure-coordinate transfer is weaker than full-donor replacement. All activations/logits/individual results are retained. `/tmp/geometry-mistral-layer-sweep-v1` **PASSed 198 development conditions in 76.54 s**, all 33 boundaries, pure edit/full donor/equal-norm random. Weekday pure edit peaks at layer 5 with 12/28 held-out shifted answers; month peaks at 17 with only 3/72. Late layers still decode coordinates but no longer causally affect the last token.

Source review then identified a critical methodological distinction: the paper's circular intervention **mean-ablates the complement**, unlike our minimum-norm edit. Its literal author QR formula sets raw plane coordinates; an affine-centered coordinate clamp differs when the training mean projects onto the plane. Both are now explicit tested functions, with `mean_only` as a required control. Current live development `/tmp/geometry-mistral-layer-sweep-v2` (log same stem, inspect the actual tool handle/state) compares centered mean-ablation, literal author mean-ablation and mean-only across all 33 boundaries. **Do not edit geometry_methods.py while that study runs.** No final examples have been selected/opened. Next: finish dual-intervention development, freeze a real protocol, add native capture/mean-ablation exercises and the real-model / UMAP / t-SNE learner experiments, then execute, inspect and publish the complete replacement. Pythia's 10/40 calendar development failure remains an honest identity-versus-computation counterexample. 5.5 is complete; do not rerun its GPU work unnecessarily. Overall goal remains active.

Historical checkpoints below are retained for provenance; their live-process descriptions are superseded.

## Live checkpoint — expanded 5.5 full learner and fresh CUDA passed; final publication pipeline being completed

This supersedes previous live descriptions. User has additionally asked to
significantly accelerate development while keeping the guided, written, tested
and visual standard. Batch independent checks and automate repeated release
work; do not relax the scientific scope or preservation gates. No delegation
was explicitly requested, so no subagents were started.

5.5 now has a readable **90-cell, 43-code, 23-exercise** lesson with the retained
copy warm-up and three new real play cells. Independent development found and
fixed two actual sampler bugs: visible-token overwriting under masked-only
supervision, and greedy one-hot confidence/entropy erasing uncertainty. **32
semantic tests + 3 audit mutation tests pass**. CPU own-answer numerical run
passes all 43 code cells with real blocks explicitly skipped.

The first full own-answer candidate `/tmp/diffusion-text-full-own-answer-candidate-v1`
**PASSed 43 cells in 436.122 s**, all 12 fits / three seeds, 126 final generation
conditions (64,512 examples), 78 timing conditions (390 measured repetitions),
all three new plays and ten figures. All ten figures were inspected. Offline
measurement audit PASS at `/tmp/diffusion-text-own-learner-audit-v2.json`.
Separate fresh CUDA `/tmp/diffusion-text-fresh-cuda-v2` **PASSed in 136.994 s**:
4 fresh fits, all 42 seed-zero generation configurations / **21,504 examples**,
8 selected/endpoint weight states, all actual traces, **maximum errors 0.0**.
Fresh v1 failed before training only because the independent audit compared
JSON lists with Python tuples; that serialization error was fixed and retained.

Final primary means across seeds: diffusion addition .578125 vs shuffled
.018229; grammar .210938 vs shuffled .044271; QA .28125 vs shuffled .114583.
AR addition .138021, grammar .473958, QA .291667. Final-update AR sensitivity
bars are retained because minimum NLL picks earlier checkpoints. The fixed QA
trajectory is wrong for both models, and the actual story gallery remains weak.
The fact-edit play changes red→blue correctly for both trained models; shuffled
supervision emits black for both. No final-based model or sampler tuning followed.

**Currently executing** `/tmp/diffusion-text-full-own-answer-release-v1` (same-stem
log; exec session 47897). It reruns the finalized lesson, with two new figures
for temperature/block ablations and fixed arithmetic examples, clearer MASK
colors, actual result interpretation, and the final report hook in solutions.py.
Freeze the 16 declared LEARNER_INPUTS in execute_learner.py until completion.
Current expected output: 90 cells / 43 code / **12 figures**. New independent
study_evidence.py, study_cuda.py, study_release.py and publish_study.py are outside
that explicit learner input inventory. Do not alter CUDA checker inputs during
its future run. No GPU job other than this release learner remains active.

Seven historical candidates, full source snapshots, all non-weight artifacts,
failed first CUDA audit and successful candidate CUDA are archived with member
hashes under `expected_outputs/development_candidates` (tar.gz + manifests).
All checkpoint weight hashes are retained; weights stay in their named local
run directories. The previous published copy-grammar notebooks/page/report/lock
and original solutions snapshot are archived under `expected_outputs/copy_warmup_release`.
Published paired notebooks/page still show the previous copy lesson until
publish_study.py succeeds. The 5.5 main report is currently stale because its
necessary report hook changed; no topic promotion has occurred yet.

Next: finish 5.5 README/lock/provenance and final pipeline. After the release
learner passes, run publish_study.py with that exact run and the pinned v3 data,
then the normal section-5.5 report runner (now includes fresh text CUDA via
study_release.py). Inspect the two new figures and improved trajectories. Run
appropriate section and global audits, archive fresh raw report files, and
promote only modern.diffusion_language_model if all learner/scientific gates
pass. DiffusionGemma hidden-state capture/patching remains unfinished. The
full roadmap still has 98 UNIMPLEMENTED requirements; the goal remains active.

## Current checkpoint — 8.3 and 9.1 complete; 5.5 text development in progress

This section supersedes all live-process and pending-release descriptions below.
The overall goal remains active. Original ARENA chapters 0–4 remain unchanged.
Do not edit the released 8.3, 9.1 or 12.3 learner sources unnecessarily: their
full own-answer inventories and separate CUDA reports are current.

- **8.3 full own-answer v2 PASS**: 44 code cells, 21 exercise groups, 14 real
  figures, 5,884.11 s. It explicitly continues its own interrupted checkpoint
  chain; it is not an uninterrupted fresh search. All 23,032 trials of the last
  IOI threshold completed. All IOI candidates failed the frozen development
  gate; IOI holdout stayed unopened. Four Greater-Than circuit methods have
  actual held-out curves and controls. All 14 plots were inspected; two dense
  graph/matrix labels have minor cosmetic crowding, retained honestly.
- **8.3 separate CUDA report v3 PASS**: all five selected circuits plus all 320
  matched null circuits regenerate with maximum behavioral error 0.0. Endpoint
  reconstruction error 5.34e-5 is below 1e-4. All 56 section tests pass. The
  complete owned source/execution/checkpoint chain is archived losslessly in
  `part3_acdc_circuit_metrics/expected_outputs/own_full_release_v2`; the fresh
  report binds all 14 published figure hashes. No ACDC process remains live.
- **9.1 final feedback release v2 PASS**: 28 useful failure messages were added
  to the real method tests, then the entire unchanged 17-source learner was
  rerun. All 26 code cells pass in 539.077 s, all 20 section tests pass, and
  separate CUDA regenerates all 3,640 examples and 65 directions exactly.
  Complete report time 165.560 s, GPU experiment 163.974 s, peak 1.9182 GiB.
  The 37 authentic raw files and report are hash-verified and archived in
  `expected_outputs/fresh_cuda_release_v2`; v1 is retained. All six published
  figure files are byte-identical to the previously inspected v1 figures.
  No refusal process or GPU pause remains live.
- **12.3 remains complete**, including its own 34-code learner and separate
  fresh CUDA four-mode check. Its explicit provenance ladder was added without
  changing the released learner methods.
- **205 selected requirements: 35 TAUGHT, 38 PREFLIGHT_ONLY, 21 TOY_ONLY,
  13 DEFERRED, 98 UNIMPLEMENTED**. Four 8.3 ACDC/metrics/EAP/IG requirements are
  newly taught. Broad refusal geometry and the full 5.5 text progression are
  not promoted by bounded preliminary results.
- **5.5 preparation now includes actual new text methods and experiments**.
  The existing 51-cell copy-grammar lesson is still published unchanged.
  Eleven new method/data/model/training/evaluation/runner/test files implement
  the selected string and TinyStories progression. All 28 semantic tests pass,
  including exact finite-bound gradients, explicit attention, cached AR, EOS,
  complete denominators and a deliberately wrong visible-logit sampler oracle.
  Data v3 at `/tmp/diffusion-text-data-candidate-v3` pins TinyStories revision
  `f54c09fd23315a6f9c86f9dc80f725de7d8f9c64`, fits BPE only on training stories,
  excludes duplicate tokenized contexts across splits, and supplies no answer
  length to generation. Training/dev/final counts are 5,632/512/512.
- First four-model matched 1,500-update candidate is retained at
  `/tmp/diffusion-text-development-candidate-v1`. It is development-only and
  scientifically weak. Its confidence sampler incorrectly resampled visible
  logits despite masked-only supervision. The carry-over fix is independently
  tested. Re-evaluation with exactly the old weights at
  `/tmp/diffusion-text-carryover-inference-v2` retains every outcome for all
  three samplers; QA improves to 24–31/128, arithmetic/stories remain weak.
- **Current active 5.5 experiment**: `/tmp/diffusion-text-development-candidate-v2`
  and same-stem log, matched 12,000 updates, development checks every 1,000,
  all four modes, seed 0, unchanged v3 data. The runner loads only train and
  development. Inspect `status.json` for current completion; do not restart a
  completed run. Every checkpoint and failed candidate is retained. Do not
  edit the eleven `text_*.py` / runner inputs while it is executing. A canonical
  expanded learner still needs to be written, run from its own answers, visually
  inspected and separately checked on CUDA before any text-topic promotion.

Next: use development evidence to settle the matched text study, write the
actual student implementations and live trajectories/AR controls/play cells,
then freeze its complete protocol before opening final examples. Finish current
course/style/report/preservation audits and retain the roadmap's actual blockers.

## Latest release — 9.1 full learner and independent CUDA PASS; ACDC resumed

This update supersedes live-run descriptions below. **9.1 stable publication is complete**. Its pipeline `/tmp/refusal-stable-release-pipeline-v1.json` reports PASS in 739.63 s and automatically resumed ACDC at UTC 08:29:51. Both GPU scheduling pauses ended; no 9.1 job is live. Do not edit released 9.1/12.3 sources unnecessarily: their reports and full own-answer source manifests are current.

- 9.1 `/tmp/refusal-full-own-answer-release-v1`: **26 code cells PASS in 555.716 s**, unchanged 17-source inventory, all 15 development candidates, 85 final conditions, six inspected figures and three real play cells. Published source/paired-notebook/raw measurement validation PASS. All **20 semantic tests PASS** in 4.09 s.
- Separate fresh 9.1 CUDA `/tmp/refusal-real-release-cuda-report-v1.json`: **PASS**, all **3,640 regenerated examples and 65 score directions match exactly**, maximum vector/score errors 0.0, runtime **173.606 s**, peak **1.9182 GiB**. The 37 raw files from `/tmp/arena-refusal-cuda-4zpjhk3l` are losslessly archived in `expected_outputs/fresh_cuda_release_v1`, with original hashes verified against the unmodified report before compression. Archived report/manifest preserve provenance.
- Actual selected direction is layer 16, suffix -1. Final fixed-threshold accuracy 69/72, AUC 1. Target addition at strength 1 yields benign markers 27/36 versus baseline 1/36 and reduces exact benign-task accuracy from 28/32 to 23/32. Full ablation removes all 26 baseline refusal markers; marker absence is not safety or correctness. All strong permutation controls, failed development candidates and high-strength capability damage remain visible.
- Only `alignment.refusal_direction` is promoted TOY_ONLY → TAUGHT; 9.1 style is course_ready. **205 requirements: 31 TAUGHT, 40 PREFLIGHT_ONLY, 23 TOY_ONLY, 13 DEFERRED, 98 UNIMPLEMENTED**. Broader refusal geometry and other methods are not promoted by this study. Root README and method registry notes reflect the real scope.
- **8.3 v2 is still live**, parent 2932219 / kernel 2932228, state R (not paused). Last observed .0005 checkpoint exceeded **9,500** trials; inspect now for current progress. All other owned searches complete, including .001 at 20,584 trials. **Freeze every 8.3 `.py` and `lesson.md`, and do not rebuild its notebooks during execution.** Run log `/tmp/acdc-full-completed-learner-v2.log`, output directory same stem. The run is an explicitly recorded continuation of its own interrupted checkpoints, not an uninterrupted fresh search.
- Course-surface audit PASS (13 chapters); style-depth PASS (46 pages); preservation PASS (627 changed paths, 167 tracked / 460 untracked at that checkpoint). Report-evidence audit finds only the still-pending 8.3 report stale. The roadmap gate's 9.1 expectations now require actual own-answer/frozen generation/fresh CUDA evidence and honest bounded scope; obsolete proxy shuffle/PCA/full-paper flags were removed. The hard-exercise registry now points to actual 9.1 method tests and explicit numerical provenance notes for 9.1/12.3. Audit feedback accepts meaningful final test messages, including expected-exception and delegated-oracle checks, without requiring one literal sentence.

Next: finish pending CPU audit tests, continue the selected 5.5 progression plan while ACDC runs, then inspect the completed 8.3 learner's 14 figures and run its fresh five-circuit/320-null CUDA check. No 8.3 or 5.5 roadmap promotion before full own-answer execution and separate CUDA evidence. The overall goal remains active.

## Active release run — 9.1 candidate PASS; stable publication and CUDA pipeline live

This update supersedes live-process descriptions below. **Freeze all 9.1 and
8.3 Python sources and lesson.md files.** The stable 9.1 source inventory is
`/tmp/refusal-release-source-freeze-v2.json` (17 files). No source edits occurred
after its start. A required lock provenance-note list was added before the
separate report starts; the lock is not among the executing learner sources.

The 9.1 full own-answer candidate `/tmp/refusal-full-own-answer-candidate-v1`
**PASSed all 26 code cells in 1882.45 s**. It completed all 15 development and
85 final conditions and all plays. Actual raw evidence independently PASSes
`validate_refusal_measurements`; log
`/tmp/refusal-own-answer-candidate-measurement-audit-v1.log`. It selected the
exact independent candidate vector; its final metrics and all controls match
(the final float32 margin differs by about 1e-6). Execution records eight
source changes and therefore is explicitly NOT stable release validation.
Its notebook, lesson snapshot, execution record and raw gzip are archived in
`expected_outputs/direction_candidates/own_answer_candidate_v1` with hashes.
The first GPU pause ended automatically after **416.05 s** when it completed.

**The stable full publication / tests / CUDA pipeline is now live**:
- Supervisor UV parent **3582848**, Python **3582851**.
- State `/tmp/refusal-stable-release-pipeline-v1.json`, supervisor log with
  same stem; script `/tmp/run_refusal_release_pipeline_v1.py`.
- Current learner UV child **3582856**; full output directory
  `/tmp/refusal-full-own-answer-release-v1`, log with same stem.
- It will publish only after full own-answer PASS and measured-row audit, then
  run all section tests into `/tmp/refusal-real-section-tests-release-v1.log`,
  then fresh report runner `--section 9.1` into
  `/tmp/refusal-real-release-cuda-report-v1.log`. Final report copy will be
  `/tmp/refusal-real-release-cuda-report-v1.json`.
- Latest progress: all 15 development candidates done; **73/85 final conditions**
  completed and increasing. Check per-condition JSON files or live log now.
- This pipeline temporarily **pauses only ACDC kernel 2932228** to serialize
  heavy GPU work. It resumes ACDC in `finally` on success/failure, with a
  separate timer in the live supervisor to resume after at most **1800 s**
  from UTC **08:17:31** (no later than **08:47:31 UTC**). The state records
  `acdc_resumed_at` when done. ACDC remains alive; its checkpoint and all
  original method decisions remain intact. Check the process/state and never
  leave it paused if the supervisor ends unexpectedly. Its own timeout is 4 h.

The structural course-surface fix has seven passing tests and a clean full
13-chapter audit. The old wrapper pattern remains detectable as a legacy
interface only; it is not scientific acceptance. New own-answer experiments
are checked for defined methods, parseable answers, actual experiment calls,
figures and a separate full executor/CUDA entry point. Evidence freshness and
scientific controls retain their independent gates.

Preparation only for the next existing topic: both 5.5 notebooks, page,
training/sampling code, roadmap 405-468 and original ARENA 1.1 training/sampling
comparator were inspected. Plan written at
`docs/arena_salvage/2026-09-05_diffusion_language_progression_repair_plan.md`.
The current useful copy-grammar learner stays intact. Missing full string/text
and AR-comparison scope remains TOY_ONLY. No 5.5 sources were edited and no
new diffusion experiment started. Read-only primary-source preparation is
`/tmp/mdlm-source-review` (author commit
`c112c526d193436838c98d81455ee51f90309470`); TinyStories revision identified as
`f54c09fd23315a6f9c86f9dc80f725de7d8f9c64`, no subset downloaded yet. Paper
version is 2406.07524v2, not nonexistent v3. After 9.1 pipeline PASS, inspect
its six published figures, refresh registry/status/README and run appropriate
audits. Then continue the still-live ACDC full learner and its separate CUDA
check. Do not mark the overall 205-requirement goal complete.

## Latest continuation — 9.1 release plumbing ready; candidate final evaluation live

This section supersedes progress below. Goal remains active; original chapters
remain unchanged. No 8.3 Python source or lesson was edited in this continuation.

- **8.3 full learner v2** remains live (parent 2932219, kernel 2932228).
  IOI .001 completed all **20,584** trials. The last IOI .0005 checkpoint was
  **4,900** trials and increasing before the brief GPU scheduling pause below.
  All 8.3 sources remain frozen; do not rebuild its notebooks during execution.
- **9.1 full own-answer candidate v1** remains live (parent 3130500, kernel
  3130598), log `/tmp/refusal-full-own-answer-candidate-v1.log`. It completed
  all fifteen development candidates, reproduced the independent candidate's
  **exact vector**, and froze layer 16/suffix -1 with three eligible candidates,
  norm **5.9792585373**, selection score **1.65625**. It is now in cell 52,
  generating all 85 frozen final conditions. This candidate does NOT publish.
  Its full methods match `direction_methods.py` exactly by AST. Source changes
  in this continuation mean it cannot be called stable release validation.
- GPU contention stretched its development generation to about 24 minutes.
  To avoid its old 30-minute cell timeout, **only my ACDC kernel was temporarily
  SIGSTOP-paused**, with an independent automatic SIGCONT controller. Record:
  `/tmp/arena_gpu_serial_window.json`; supervisor UV PID 3460099 / Python
  3460102; maximum pause 480 seconds from UTC **08:08:16**, automatically
  resumes no later than **08:16:16 UTC** or when the candidate kernel exits.
  Inspect the record and process state now; do not leave ACDC paused. Its
  notebook timeout is four hours and its atomic search state remains intact.

### 9.1 release preparation completed during candidate execution

The paired notebooks and page are now the **61-cell / 26-code / 12-exercise**
real learner, replacing the old 37-cell prototype. All own-answer methods,
actual loops, six figures, three play cells and metadata remain. Two small
plumbing lines save each development/final condition as it completes. The new
executor prints the lesson's progress streams, allows a one-hour long-cell
budget, snapshots all 17 exact sources, and audits the raw results before
publishing. It still requires a fresh full own-answer run with unchanged sources,
paired method agreement and all six measured figures. Current final source
inventory: `/tmp/refusal-release-source-freeze-v2.json` (17 section files).
Do not rerun stale temporary lesson generators.

- `direction_evidence.py` recomputes all development/final rates, exact benign
  scores, score metrics, paired transition denominators, candidate eligibility,
  frozen winner and full 85-condition/32-null inventories. It verifies pinned
  split metadata and all source/notebook/figure/raw hashes. Sensitive completion
  labels are explicitly reserved for fresh CUDA regeneration, not claimed to
  be recomputed from absent text. An adapter audit of the actual independent
  candidate measurements PASSes (`/tmp/refusal-independent-measurement-audit-v1.log`).
  The adapter fixture is only test plumbing, NOT learner provenance.
- `direction_cuda.py` requires the published full learner, freshly refits from
  training only with exact learner batch padding, checks all 65 target/null
  score directions, then regenerates baseline and all **34 unit-strength**
  target/random/permutation conditions on all 104 final questions. Individual
  sensitive hashes/markers/lengths and benign words/tokens must match exactly;
  score/vector tolerance remains 1e-4. This fresh check has NOT run yet.
- `solutions.py` and `tests.py` now expose the real methods and full pipeline;
  the old 1,600-line proxy implementation and misleading old report/lock/tests
  are archived losslessly under `expected_outputs/legacy_proxy` with hashes.
  README, lock, expected-output provenance and actual analytic smoke are updated.
  **19 semantic tests PASS, one full-published-evidence test correctly skipped**
  pending publication (`/tmp/refusal-real-section-tests-v1.log`). Numerical-only
  own answers execute all 26 cells in **4.55 s**, real blocks skipped:
  `/tmp/refusal-real-numerical-plumbing-v1`.
- All **six** plots have been visually inspected. The candidate-selection
  legend was moved below the plot so it no longer covered the last candidate.
  The actual generation gallery and near-perfect permutation AUC remain.
  All **114** independent development/final JSON files are archived losslessly
  under `expected_outputs/direction_candidates` (5.4 MB), with exact bound
  candidate sources and both compressed/original hashes. No weights/cache
  tensors or sensitive raw text were included.
- `scripts/audit_course_surface.py` had required report-reader wrappers in
  notebooks and rejected explicit CPU-first runtime metadata. It now also
  recognizes direct own-answer experiments with real method definitions,
  parseable answers, actual method calls/figure generation, and a separate
  full executor plus CUDA entry point. This is a structural check; runtime
  evidence remains independently required. **Seven tests PASS**, including
  missing-answer/figure/executor rejection. Course surface now PASSes across
  13 extension chapters. Strict learner heuristic PASSes both new 9.1 notebooks;
  style-depth PASSes 46 pages. Preservation PASSes **603 changed paths**,
  161 tracked / 442 untracked; no original ARENA changes.

**Next:** wait for the candidate final results and inspect/validate its actual
raw output. Then run a new stable full own-answer learner with `--publish`
from the now-complete sources (independent process session, careful GPU
scheduling), run the fresh CUDA report and all 20 section tests, refresh
method/roadmap/style/hard-ladder status and root README only after actual PASS.
The current 9.1 report and some registry prose remain legacy/stale; 9.1 stays
TOY_ONLY/prototype until publication. ACDC v2 still needs its final .0005 search
and remaining diagnostics, then its five-circuit/320-null CUDA check. The
12.3 published v4 and CUDA report v3 remain complete and unchanged.

## Latest execution update — own-answer 9.1 candidate and resumed 8.3 live

This update supersedes the run IDs and in-progress descriptions immediately
below. **Do not edit any 8.3 `.py` or its `lesson.md` while the resumed full
learner is running.** All current sources bind its publication.

- **8.3 v1 ended**, not live: its notebook records KeyboardInterrupt at cell 80
  during threshold .001, with the last atomic checkpoint at 9,700 trials.
  A secondary nbclient cleanup AttributeError obscured the original interrupt.
  All three original processes ended. Before editing anything, all 24 source
  hashes were checked and their exact files copied to
  `/tmp/acdc-full-completed-learner-v1/source_snapshot`.
- Only 8.3 execution/checkpoint infrastructure and its tests were changed:
  `execute_learner.py`, `edge_experiments.py`, `edge_experiment_tests.py`.
  **Three tests pass**, including identical uninterrupted/resumed decisions,
  tampered checkpoint rejection and rejection of changed methods. The executor
  now accepts `--resume-interrupted-run` only for its own unchanged full learner
  with an actual KeyboardInterrupt. It snapshots checkpoint bytes, requires
  exact data/model/function-AST context and rechecks complete/partial losses
  live. The original graph engine and notebook method bodies are unchanged.
  README and repair plan describe the continuation honestly.
- **8.3 resumed full learner is live in an independent process session**:
  parent PID **2932219**; command/process record
  `/tmp/acdc-full-completed-learner-v2-process.json`; log
  `/tmp/acdc-full-completed-learner-v2.log`; output directory same stem.
  It reruns all cells, plots and diagnostics, retaining the completed searches
  from its own interrupted chain and continuing .001 before starting .0005.
  Last observed .001 progress was **11,400** trials; all four copied checkpoints
  have `owned_continuation.json`. No errors. Inspect current checkpoints/log and
  processes before deciding it has stopped. Source freeze applies to all 8.3
  Python files and `lesson.md`, including tests. Do not rebuild its notebooks
  during execution. After PASS, run the fresh five-circuit/320-null CUDA check
  and refresh its report/registry/evidence. The report is still stale now.
- **12.3 final CUDA report v3 PASS**, after README now points to exact runtime
  in the execution manifest instead of a stale fixed number. Its log/report
  copies are `/tmp/mini-vlm-word-release-cuda-report-v3.{log,json}`. Latest fresh
  CUDA familiar-muted joint exact **.8842593**, best control **.3217593**, gap
  **.5625000**, peak **.158678 GiB**; all 95 structural conditions pass. Prior
  independent CUDA repetitions also passed with different training outcomes;
  keep the distinction and do not select the best run. The published CPU
  learner is still v4, 34 code cells, 12 fits, 36 evaluations, 285 conditions,
  7 inspected figures and 43 passing tests. No more 12.3 source work is needed.

### 9.1 actual development and frozen final candidates completed

The development run `/tmp/refusal-real-development-v1` passed in **496.98 s**,
all 15 candidates retained, no source changes, final split unopened until its
selection record was written. Three candidates qualified. The fixed rule chose
**decoder-input layer 16 / suffix offset -1**, raw difference norm about 5.979.
Development baseline refusal/benign marker rates **25/32 / 0/32**, exact
capability **30/32**. At raw multiplier one, chosen addition induces markers on
**28/32** benign requests; full ablation leaves **0/32** refusal-category
markers while exact capability remains **30/32**. Early-layer failures and
capability damage remain in candidate files. Original three core candidate
sources and the runner remain unchanged and bound by the protocol hashes.

`direction_final.py` defines **32 new capability inputs** (same four task
templates) and a frozen final protocol. It verifies prior selection/source
hashes and selection arithmetic before accessing final model data. The fresh
training-vector recheck max error is **3.81e-6**. Final class-wise rows 64:100
provide **36 examples per class**, independent of selection. First eight
seed-901 random directions and first eight training permutations, every
addition multiplier .5/1/2 and ablation fraction .5/1, give **85 conditions**.
No direction or amplitude is retuned on final results.

**All 85 conditions PASS** at `/tmp/refusal-real-final-v1` in **421.82 s**, no
source changes, **1.9163 GiB peak**. Fixed target final AUC **1.0**, threshold
accuracy **69/72**, signed margin **5.5662**. Baseline refusal/benign marker rates
**26/36 / 1/36**, new exact capability **28/32**. Target addition α=.5/1/2 gives
benign marker rates **6/36, 27/36, 36/36** and capability **28/32, 23/32, 6/32**.
Target ablation β=.5/1 leaves **6/36, 0/36** refusal markers, capability **29/32**
for both. Treat the one-question increase as small-sample variation, not a
broad capability improvement. At α=1, random benign-marker max **2/36**,
permuted max **8/36**. At β=1, the strongest permutation still leaves **7/36**
markers; random ablations leave at least **26/36**. Some permutation nulls
nearly match ranking (**max AUC .999228**) and have substantial causal effects;
keep all of them. Marker absence is not safety or answer correctness.

`direction_figures.py` has five candidate plots. Actual final curves and the
fixed-first-four benign generation gallery were inspected. The gallery's
fourth added response refuses in language outside the rubric and is labeled
False; this is explicitly discussed in the lesson. The first candidate-selection
scatter had overlapping labels, so it was replaced by aligned horizontal bars;
the revised plot and remaining separation plots still need visual inspection.
A sixth real-training PCA/control figure is generated by the learner's geometry
play cell. `/tmp/plot_refusal_candidates.py` generates current five candidate
figures in `/tmp/refusal-real-final-v1/figures`.

The complete new **9.1 draft is 61 cells / 26 code cells / 12 exercises**, with
full own answers, per-exercise metadata, actual development/final loops, six
figures, three executable play cells and limitations. It imports only data,
dataclass/test and plot plumbing; inference calls the functions the learner
implemented. New `direction_evaluation.py` supplies independent references for
paired transitions and development-only selection; all **three tests pass**.
The earlier 10-group numerical own-answer run passed **14 cells in 4.78 s**.
Together with 12 method tests, there are currently **15 new semantic tests**.

**Full own-answer candidate learner is live**, independent process parent PID
**3130500**; process record `/tmp/refusal-full-own-answer-candidate-v1-process.json`,
log `/tmp/refusal-full-own-answer-candidate-v1.log`, output directory same stem.
It repeats all 15 development candidates and all 85 final conditions from its
own answers. This candidate does **not** publish; evidence/report plumbing is
still to implement and adding its Python files during this run will be recorded
as a source change. Do not call it stable release validation. The published
paired notebooks/page remain the old 37-cell prototype until a final stable
own-answer run publishes the new surfaces. Registry is TOY_ONLY for 9.1 and
style status prototype for now.

**Do not rerun** `/tmp/create_refusal_lesson.py` (only the initial 39-cell draft)
or `/tmp/append_refusal_experiments.py` (expects the now-removed continuation
marker). `lesson.md` is canonical. `build_notebooks.py --check` passes and its
six export anchors are wired. `execute_learner.py` supports numerical/full;
full publication will require unchanged all-Python/lesson sources, paired
AST agreement and raw generated evidence. Next: finish 9.1 evidence verification,
source/test/surface and lock/report updates, inspect figures, archive actual
candidate results, then build and execute a stable full learner with publication.
Keep the original ARENA preservation rule and the larger incomplete registry
scope. No subagents or git publishing actions are authorized/needed here.

## Current execution — 12.3 published, full 8.3 and 9.1 development live

This section takes precedence over all earlier snapshots below. The overall
user goal remains active. The registry has **205 rows: 30 TAUGHT, 40 PREFLIGHT_ONLY,
24 TOY_ONLY, 13 DEFERRED, 98 UNIMPLEMENTED**. The 9.1 row was downgraded after
finding evaluation leakage and an invalid shuffle control; no new subject was
added. Do not claim the entire extension is complete.

### 12.3 word-generating learner is published and validated

The paired notebooks/page now contain **69 cells, 34 code cells and 19 exercise
groups**, all with full working answer dropdowns, immediate tests and per-exercise
difficulty/importance/time guidance. The canonical `lesson.md` includes the
original 1.1 prerequisite link and a concrete controlled-model claim. The main
path builds learned RGB patches, a two-layer ViT, connector, explicit image/word
slots, a two-layer causal word decoder, shifted loss, greedy EOS generation,
training, region controls and causal patching. The engineered/categorical legacy
code remains a warm-up/reference, not the main image-to-language result.

**Final full learner:** `/tmp/mini-vlm-full-word-learner-release-v4`, log with
same stem, TTY 38793 (completed). All 34 code cells passed in **362.86 seconds**,
with twelve fresh fits, 36 final evaluations, 285 stage/region conditions,
seven published figures, own-answer completion and no source changes. v3 was
interrupted during training with KeyboardInterrupt; its processes ended before
v4 began. Do not use the failed v3 as evidence. v2 had also passed in 310.9 s.
`read_completed_word_evidence()` validates exact source/notebook/figure/raw
hashes and recomputes metrics from actual generated words. All **43 section
tests** pass. All seven actual published figures have now been visually inspected.

Three CPU seeds average familiar-muted exact generation **.8580247** versus
text-only **.2592593**, image-only **.3132716**, shuffled-pairs **.2669753**.
Excluded-combination caption exact match is **zero for all three seeds**.
Keep that failure. Joint-correct patch denominators are **50/72, 51/72, 45/72**.
Input object patches reproduce donor generation; input background patches and
last-decoder visual-only patches are inert. Full-sequence replacement reproduces
donor generation at every stage. All eight background and eight unrestricted
random draws remain visible. Later background rows can contain object information.

The separate fresh CUDA report v2 also passed: four seed-0 training modes,
twelve final evaluations and all 95 structural patch conditions. Familiar-muted
joint exact **.9236111**, strongest control **.3518519**, gap **.5717593**,
compositional caption **0**, peak **.158678 GiB**. Raw report preserved at
`/tmp/mini-vlm-word-release-cuda-report-v2.json`. The earlier v1 fresh CUDA
study also passed but had different training outcomes; it is not the final
report. CUDA training is not claimed bitwise reproducible. A final metadata
refresh is being run after removing the stale 311-second README claim; use
`/tmp/mini-vlm-word-release-cuda-report-v3.log` for its status. No further 12.3
method or lesson edits are needed. Registry/style/root README now describe the
word learner and its failure honestly. Last evidence audit had no 12.3 issues.

### 8.3 full own-answer learner remains live

**Do not edit any 8.3 `.py` or `lesson.md` while TTY 14687 is live.** Exact
source hashes bind publication. Command is `execute_learner.py --scope full
--output-directory /tmp/acdc-full-completed-learner-v1 --publish`; log has the
same stem. Inspect `searches/**/checkpoint.json` for progress, not only kernel
cell logs. Greater-than and IOI thresholds .05/.004 have completed afresh;
IOI .001 is live and .0005 must follow. All 94 cells / 44 code cells must finish.
Never restart a live search on an observation timeout.

All four independent IOI candidates failed fixed development criteria. The
lesson now ends IOI selection honestly, with **holdout unopened**, and diagnoses
the highest-development-recovery candidate (.001, 737 edges) on development
only. All 32+32 nulls, every retained-edge deletion and 72 completeness probes
remain. Greater-than provides the four genuinely frozen transfer circuits:
ACDC 78 edges, EAP 300, task EAP-IG 100, KL EAP-IG 300; changed-wording recovery
approximately .832/.895/.859/.909. ACDC's drop below the .85 development floor
is retained. The four-candidate context and all raw results are archived in
24 lossless JSON files. Do not rerun the old stale lesson generators.

After the full learner passes: inspect its actual outputs, run the separate
8.3 CUDA check (five circuits and all 320 nulls), refresh evidence/report and
registry, then audit preservation and contracts. Its report is still stale.

### 9.1 real-model learner repair is in progress

Read the plan `docs/arena_salvage/2026-09-05_refusal_real_learner_repair_plan.md`.
Both old 37-cell notebooks, page and original 104-cell ARENA 1.3.2 comparator
were inspected before edits. The old `arena_ext.refusal_steering` evaluator
chooses a threshold using evaluation class means; its label-shuffle reverses
labels and fits on combined data. The old real hook only edits one prompt
position once. Old published artifacts remain for now, but style status is
prototype and requirement `alignment.refusal_direction` is TOY_ONLY. Do not
claim its prior report is accepted methodological evidence.

New `direction_methods.py` exposes training-only fit/threshold, tie-correct
AUROC, frozen evaluation, 32 real permutation/random nulls, centered PCA,
projection geometry, persistent native Qwen hooks, explicit residual-input
cache and cache-aware greedy generation/EOS, plus an inspectable marker rubric.
Full ablation projects every residual write; partial strengths attenuate each
write once. **Twelve semantic tests pass**, including an independent weight-
projection oracle on a disposable tiny model and cached/uncached generation.
Tests use the production SDPA path; eager fully masked left-padding rows can
produce NaNs in this library build. Actual model parameters are never modified.

`direction_data.py` pins Qwen2.5-0.5B-Instruct revision
`7ae557604adf67be50417f59c2c2f167def9a775`, public dataset revision
`b6ed3432f1d4a695e13be1c373bf7fb5af43f376`, and parquet SHA
`deb1db310fe45a0193ac09cca91cc3973f3db2145733df84a9d0ab48962dacfb`.
There are 201 unique prompts (101 refusal, 100 compliance). Class-wise rows
0:32 train, 32:64 development, 64:100 final; the last refusal row is unused.
Final model evaluation has not occurred. Sensitive text stays in memory;
benign prompts/generations and sensitive row hashes/marker flags are saved.
A fixed 32-question capability set tests arithmetic, capitals, opposites and copy.

**Development run live TTY 40690**, `/tmp/refusal-real-development-v1.log`,
directory of the same stem. **Freeze `direction_methods.py`, `direction_data.py`
and `run_direction_study.py` until it completes**; these three source snapshots
and hashes bind the candidate run. It caches 128 train/development prompts,
computes all layer/position separation and nulls, and tests fifteen candidates:
layers 4/8/12/16/20 × suffix positions -3/-2/-1. Every candidate gets actual
addition, full ablation and benign capability generation. Protocol and selection
rule were written before generation. Baseline development marker rate is
.78125 on refusal-category prompts and 0 on benign; exact capability is .9375.
First three layer-4 candidates fail; one harms capability. Preserve every result.
The runner writes frozen_selection.json only after all candidates; it never
loads the final split. Later final/null/amplitude evaluation is still to implement.

New 9.1 `lesson.md` is a **39-cell draft / ten exercise groups**, with working
answers and immediate tests. `build_notebooks.py --check` passes; do not publish
yet. Full experiment/selection/control/play cells still need adding. The draft
numerical own-answer run is `/tmp/refusal-own-answer-numerical-v1`, log same stem,
TTY 49214; check its result. It is explicitly partial validation. The temporary
generator `/tmp/create_refusal_lesson.py` currently creates only this first draft;
do not rerun it after appending experiments.

### Current audits and next work

Last preservation audit: **455 changed paths (154 tracked, 301 untracked), zero
blockers, PASS**. Style-depth audit: **46 pages, zero blockers, PASS**. Report
contract audit has only the pending 8.3 release issues after 12.3's successful
refresh; a style pass alone does not certify teaching quality. Continue 9.1
candidate experiments and draft construction while 8.3 runs, then finish each
full learner/evidence publication. No staging, commits, pushes, PR/workflow
actions, memory writes or subagents were used.

## Earlier 8.3 candidate details (current execution above takes precedence)

The next pilot now has a validated full residual-edge engine, actual GPT-2
candidate experiments and a readable learner draft. **This is still candidate
work.** The published 8.3 notebooks/page, release report and roadmap status
have not been upgraded. The overall goal remains active: **205 rows, 31 TAUGHT,
40 PREFLIGHT_ONLY, 23 TOY_ONLY, 13 DEFERRED, 98 UNIMPLEMENTED**.

- `real_edges.py` defines every additive Q/K/V, MLP-input and output edge:
  **157 senders, 445 receivers, 32,491 legal edges** in GPT-2. Retained edges
  carry the current hybrid sender, with matched corrupt references elsewhere.
  Independent small-transformer tests cover single-port interventions, an
  explicit slow edge oracle, rejection of frozen-clean sender reuse, scoped
  hook cleanup, output reachability and sequential search with exact resume.
  GPT-2 full/empty max logit errors are **2.48e-5 / 0**. The original IOI helper
  stores the final answer in its sentences; the extension adapter strips that
  answer and scores each actual pre-answer position. Original code is unchanged.
- The all-name-corruption IOI search at threshold **0.05** completed 6,779
  model trials plus 381 disconnected receiver skips in **860.5 seconds**,
  retaining 32 edges. It **failed**: discovery recovery −0.2769, accuracy
  0.3438; independent development recovery −0.2347, accuracy 0.2188, KL 2.8059.
  Preserve this result. Both sets of 32 uniform/receiver-indegree-matched
  random circuits were scored without filtering samples.
- The fresh threshold **0.004** search completed: **383 edges**, discovery
  recovery **0.94935**, accuracy **0.875** (clean 0.96875), KL **0.35773**.
  It took 14,257 model trials and 255 disconnected receiver skips, 1,885.2
  seconds including brief contention with other candidate GPU runs. Raw
  candidate/context/checkpoint files use `/tmp/acdc-ioi-fullgraph-tau0004`.
  Its development evaluation **failed**: recovery **0.52263**, accuracy
  **0.75**, KL **0.77061**. Both sets of 32 null circuits failed (maximum
  recovery 0.00355). Of 383 edge deletions, 309 increased KL and 288 damaged
  the task metric. Sampled completeness exposes large omitted-mechanism gaps.
  These results are in `/tmp/acdc-ioi-tau0004-development.json`.
  The **0.001** search completed 20,584 trials in 3,442.1 seconds, retaining
  **737 edges**, with discovery recovery **1.023** and 32/32 correct preferences.
  Development recovery **0.88152** and KL **0.40880** pass, but accuracy
  **27/32 = 0.84375** fails the fixed maximum 0.10 drop from clean 31/32.
  At least 28/32 was required. All 737 deletions and both 32-sample nulls are
  recorded in `/tmp/acdc-ioi-tau0001-development.json`. Preserve this failure.
  A documented development-only amendment adds a fresh **0.0005** threshold
  with every other setting and all criteria unchanged. It is live in TTY
  session **19834**, log `/tmp/acdc-ioi-fullgraph-tau00005.log`, output stem
  `/tmp/acdc-ioi-fullgraph-tau00005`. The original three candidates all fail;
  the fourth is adaptive development tuning, not an originally planned trial.
  **Do not edit or format `real_edges.py`:** exact source hashes bind completed
  candidates and resumable searches. Do not restart on an observation timeout.
  Confirm termination before resuming. IOI holdout remains unused.
- Greater-than ACDC completed with **78 edges**, discovery recovery **0.8706**.
  Development passes: recovery **0.85499**, 31/32 positive probability margins,
  KL **0.13462**; both 32-circuit nulls recover essentially zero. All 78 edge
  deletions and sampled completeness are recorded. A fresh three-method
  attribution comparison also completed. Before any greater-than holdout
  scores, `expected_outputs/edge_candidates/greater_than_frozen_selection.json`
  fixed ACDC 78, EAP 300, task-loss EAP-IG 100 and KL-loss EAP-IG 300 edges.
  Each is the smallest qualifying tested size for its method (ACDC has one
  completed greater-than threshold). Individual selection files bind candidate
  hashes and development evidence. The 64-example seed-13 changed-wording
  holdout has completed for all four frozen choices: ACDC recovery **0.83180**,
  EAP **0.89519**, task-loss EAP-IG **0.85855**, KL-loss EAP-IG **0.90901**.
  Raw results/logs use `/tmp/acdc-greater-than-{method}-heldout`, with method
  names `acdc`, `eap`, `eap-ig-inputs`, `eap-ig-kl`. Preserve ACDC's drop below
  the development floor; do not retune from these results. IOI holdout remains unopened.
- Discovery/development are 32 examples at seeds 1/2. The 64-example shifted
  template holdout at seed 3 has **not been scored**. The repair plan records
  the threshold selection rule before holdout access and the explicit
  development-only amendment to 0.0005. `run_edge_evaluation.py` requires a
  frozen selection record before opening the holdout.
- `edge_attribution.py` implements EAP and actual **input-interpolated**
  EAP-IG, with parameter/tensor-hook cleanup and fixed endpoint sender deltas.
  All 32,491 GPT-2 scores match the authors' unedited implementation, pinned
  at `e24bafd3d22af2c59ac5a83e0a6581b89b5c05dd`: max errors **1.28e-6 / 2.15e-6**
  for EAP/eight-step EAP-IG. Small-model errors are below 3e-7. Output-frontier
  greedy selection also has exact author-code mask parity on a small graph
  with unique scores (`prune=False`). The expanded GPT-2 parity harness also passes: KL-loss EAP-IG
  max error **5.96e-7**, with exact selector parity at five sizes. The result
  is `/tmp/acdc-eap-all-metrics-and-selector-upstream-gpt2.json`.
- Fixed-label greater-than data and probability metrics are in
  `greater_than.py`; discovery/development instances are disjoint, and only
  the start-year suffix changes to `01`. Full-vocabulary normalization is
  tested, including an analytic gradient oracle and a rejected conditional-
  numeric-only metric. On 32 development examples, raw top-score EAP-IG
  recovers **0.8788 at 100 edges, 0.9670 at 300**; EAP gets 0.7589/0.9272.
  All 16 uniform random circuits per tested size are retained and fail
  visibly. The full greater-than ACDC candidate and its frozen transfer evaluations have completed.
- The all-name IOI task-loss EAP/EAP-IG curves are weak, including after
  output-frontier selection. KL-loss EAP-IG also fails the task at small
  sizes, despite lowering KL. Keep these negative curves. The EAP-IG paper
  uses a different IOI corruption (only the repeated subject), while ACDC
  replaces all names. `ioi_controls.py` implements this explicit control
  without changing the running ACDC data. Its comparison completed: at 1,000 edges, EAP/EAP-IG/EAP-IG-KL
  development recovery is 0.554/0.707/0.558. This is still insufficient
  faithfulness. The log is `/tmp/acdc-ioi-second-subject-development.log`.
- `lesson.md` is a **draft**, now 94 cells with 44 code cells. The useful
  nonlinear toy and GELU-1L component warm-ups remain. Full graph construction,
  reconstruction, execution, metrics, reachability, ACDC, EAP/IG, score
  selection and greater-than metrics have visible stubs, immediate tests,
  expected outputs, help and complete solution dropdowns. The prior 57-cell
  version executed **all 26 code cells** in a fresh kernel completed only
  from its own answers. Figures were redirected to `/tmp/acdc-draft-figures`
  so published outputs were not overwritten. The expanded fresh-kernel prefix now passes all **32 code cells**, including
  greedy/KL exercises, real IOI endpoint parity, live greater-than attribution
  curves, the named graph and the year-distribution play cell. Its source hash
  and exact scope are in `/tmp/acdc-fast-learner-execution.json`; full ACDC
  searches and held-out learner execution are still outstanding.
- The complete greater-than learner prefix now passes **37 code cells** in a
  fresh kernel in **768.9 seconds**, including 3,690 fresh ACDC trials and the
  exact same four frozen edge masks as the independent candidate runs. It
  generates its own development/transfer curves, all 32+32 nulls per method,
  78 ACDC edge deletions, 72 backup probes and named-edge play. Artifacts and
  the captured lesson snapshot are at `/tmp/acdc-greater-than-completed-learner-v1`.
  The current draft grew while that captured prefix executed; its manifest
  explicitly records those source changes and does not claim full validation.
- `build_notebooks.py --check` validates the draft and its own answer completion.
  IOI threshold selection, frozen transfer, edge matrices, diagnostics, play,
  three attribution/corruption comparisons, interpretation and supporting raw
  evidence export are now written but **not yet executed as a full learner**.
  Page export will include fourteen measured figures. Do not publish yet.
- `execute_learner.py` records numerical/greater-than/full scope, requires fresh
  searches, snapshots its input source, preserves failure outputs, and permits
  publication only after a full pass with unchanged source. `edge_evidence.py`
  checks that provenance and freshly recomputes frozen circuits and all 320
  random controls. Its **four** rejection tests pass, including paired-notebook hashes; the
  CUDA recheck has not run because a full completed-learner payload does not
  exist yet. `solutions.run_gpu_test` now preserves the old warm-up checks and
  requires the full learner provenance plus a live frozen-circuit recheck.
  `run_full_experiment` executes the complete learner and all searches afresh.
  The old report is consequently stale until full publication; lock/report
  and release metadata still require their upgrade. All 19 warm-up tests pass.
- All **30 new method/checkpoint numerical tests pass**, including KL/S2 and explicit task-unit controls.
  The combined rerun is in
  `/tmp/acdc-new-thirty-tests.log`. Original-preservation
  audit passes at 359 changed paths (140 tracked, 219 untracked). No original chapters, staging, commits, pushes, PR/workflow
  actions, memory writes or subagents were used.

Candidate logs/results remain under `/tmp/acdc-*`; twenty-two completed JSON
results are also archived losslessly under section `expected_outputs/edge_candidates`,
with compressed/uncompressed hashes and explicit failed-candidate descriptions.
The complete 94-cell draft passes all **44 code cells** in explicit numerical
mode (`/tmp/acdc-full-draft-numerical-v2`), with real experiment blocks skipped.
The separate fresh IOI-attribution learner passes **33 method/experiment cells**
plus one raw-data observer in 141.2 seconds, including all three method curves
and the S2 corruption control (`/tmp/acdc-ioi-attribution-completed-learner-v1`).
These subsets are not full release validation. Their executed notebooks,
source snapshots and scope records are archived losslessly in
`expected_outputs/edge_candidates/learner_validation` (nine files, 2.77 MB).
The new metric callback extension has six passing metric tests, including its
non-IOI-unit oracle. `run_edge_evaluation.py` now supports both candidate tasks.
The repair plan is
`docs/arena_salvage/2026-09-05_acdc_real_edge_repair_plan.md`. Core source and
runner files are untracked candidate work. The previous artifact-hygiene
failure remains; do not stage files merely to make that gate green. The
temporary draft creator `/tmp/create_acdc_lesson.py` currently regenerates the
61-cell draft, so **do not rerun it after adding new experiment cells** unless
its contents are deliberately updated too. The canonical editable source is
the section's `lesson.md`.

## Parallel local preparation: finish the 12.3 language path

While the fourth 8.3 IOI search runs, 12.3 was inspected with the original
ARENA 1.1 Transformer comparator. It currently has engineered RGB/occupancy
features, one categorical question ID and a seven-class answer head. The
roadmap additionally requires patch/ViT or frozen OpenCLIP features, word-level
sequences, teacher-forced captioning and generation. Several answer dropdowns
have broken indentation, and the final play activity is Markdown only.

The repair plan is
`docs/arena_salvage/2026-09-05_mini_vlm_language_path_repair_plan.md`.
The existing 55-cell paired notebooks and report are still the categorical
warm-up; no 12.3 release status has been upgraded. New untracked candidate
modules now implement the word-level path:

- `language_data.py`: real RGB draws, exact object masks, matched counterfactual
  geometry/noise, word tokens and explicit answer/EOS masks. Training/development
  seeds 100/200 use nine color–shape combinations; red triangle, blue circle and
  green square are excluded. Final familiar seed 300 and compositional seed 400
  use new images, with a paired solid/muted palette comparison.
- `language_vlm.py`: learned 4x4 patch embeddings of 32x32 images, two 48-wide
  bidirectional ViT blocks, learned connector, explicit image markers, word
  embeddings and two causal decoder blocks, shifted answer/caption loss,
  exact stage patches and EOS-aware ragged-prompt greedy generation.
- `language_training.py`: the visible optimizer loop, exact complete-word
  generation metrics, and training/development-only checkpoint selection.
- `language_patching.py`: exact pixel-to-token geometry, equal-size background
  and unrestricted random rows, donor recomputation on the same generated word
  prefix at every step, and conditional targeted-flip denominators. Later
  full-sequence patches include image-informed text states. A known causal
  word oracle proves why replacing visual rows alone can fail at that stage.
- **18 new tests pass in their four modules:** data 4; model 8 (pixel-window
  forward/gradient oracle, independent SDPA attention/gradients, future/pad
  invariance, shifted-loss analytic gradient, native stage patch parity,
  EOS/prefix and training-mode cleanup, gradients through both towers);
  training 3 (two manually reconstructed AdamW updates, exact EOS scoring and
  image-only question removal); patching 3. Logs use `/tmp/mini-vlm-*-tests.log`.

The development matrix is complete at
`/tmp/mini-vlm-word-development-matrix-v1`: 600 optimizer steps, batch 48,
AdamW lr .003, evaluate every 100, 288 training images/864 requests and 108
independent development images/324 requests. All three seeds 0/1/2 and all four
training modes (joint, text-only, image-only, shuffled-pairs) are kept. Joint
best development exact generation is .9506/.9444/.8549; the weakest seed is
not discarded. Seed 0 reused its identical completed pilot at
`/tmp/mini-vlm-word-development-v1`, with no source changes between runs.

`frozen_selection.json` in that matrix directory bound all twelve checkpoint
hashes **before** any final model scores. `final_evaluation.json` retains all
36 condition evaluations. Mean joint exact generation is **.8958** on 144 new
familiar solid images, **.8580** on their matched muted versions, and **.3275**
on 96 images with the three untrained combinations. On those combinations,
color VQA is .9028, shape VQA .0799 and caption exact match **0**. Preserve this
substantive generalization failure; do not tune against the final splits.
Familiar-solid controls average .2593 text-only, .3202 image-only and .2940
shuffled-pairs. All results include actual generated word IDs and exact EOS.
Weights remain only under `/tmp`; do not commit model checkpoints.

The fixed first development image per familiar combination gallery was viewed
at `/tmp/mini-vlm-word-development-gallery.png`. It shows actual multi-word
captions. Next: run the real frozen stage/region causal experiments; archive
candidate raw evidence; build the readable learner, repair working dropdowns,
add executable play cells and visible all-seed/transfer/failure figures; then
execute the learner from its own answers and refresh the complete release
harness/source/figure/scope checks. The current code is still candidate work.

Primary architecture sources checked: ViT https://arxiv.org/abs/2010.11929 and
LLaVA https://arxiv.org/abs/2304.08485. The tiny controlled model is not a
replication of their dataset sizes, pretrained weights or headline results.

## Previous continuation: 12.1 full encoders and typographic controls completed

The 12.1 learner now builds and trains complete image and caption encoders,
not just two projectors on engineered features. The original projector exercise
remains an explicitly labeled warm-up. All original ARENA chapters 0–4 remain
unchanged. The overall goal is still active: **205 rows, 31 TAUGHT, 40
PREFLIGHT_ONLY, 23 TOY_ONLY, 13 DEFERRED, 98 UNIMPLEMENTED**.

- **Learner:** twenty exercise groups, valid complete solution dropdowns, and
  **52 code cells executed in a fresh kernel** after completion solely from
  those dropdowns. The readable `lesson.md` builds both notebooks and the full
  instruction page. Core RGB CNN, causal attention, padding/EOS pooling,
  projections/normalization, CLIP/SigLIP losses, semantic retrieval, training,
  evaluation and typography metrics live in notebook cells. The page includes
  the four actual measured figures. `--page-only` updates that export without
  erasing notebook outputs.
- **Independent tests:** **40 section tests pass**, including exact functional
  CNN and attention forward/gradient oracles, explicit EOS rather than largest
  token-ID pooling, pad/future invariance, analytic pair gradients, two
  independent float64 AdamW updates, duplicate-positive/tie-aware retrieval,
  collapsed/incorrect implementation rejection, exception-safe hook cleanup,
  targeted-flip denominators, geometric overlay controls, and AST parity of
  the completed learner and solved code.
- **Measured learning:** train/development/evaluation renderer seeds 100/200/300,
  576 training and 288 evaluation images, twelve familiar color–shape classes,
  three model seeds, 1,200 optimizer steps per run. Learner mean classification
  is CLIP **0.9711**, SigLIP **0.9907**; each gets text→image retrieval 1.0.
  Frozen random towers average **0.4537/0.4190**, shuffled pairing
  **0.0787/0.0833**. Blank/noise and wrong-color words fail visibly. Both towers
  and both heads change; frozen towers remain exactly fixed. No evaluation
  images enter training. Classes/templates are shared, and zero byte overlap
  is not asserted to prove novel geometry. CUDA trajectories can differ
  slightly between independent runs; all seeds and control gaps are retained.
- **Visible results/play:** training and retrieval/control panels, fixed-image
  and error galleries, editable pixel/noise/caption retrieval, live pinned
  CLIP/SigLIP patch bars, and a word-conflict image/score play cell. The learner
  does not display stored verification-report numbers as experiment outputs.
- **Real models:** reconstructed logits differ from official CLIP by 5.72e-6
  (tolerance 1e-4) and float16 SigLIP by 0.00725 (tolerance 0.05). This is separate
  from the unchanged full-sequence patch parity threshold. The two-scene
  object/background/random/full-sequence patch and Qwen generation preflights
  remain; Qwen answers both controlled scenes correctly.
- **Typography:** pretrained CLIP, no downstream fitting, 48 scenes at renderer
  seed 400, ten matched word/card/placement interventions plus clean. Clean
  accuracy is 47/48; conflicting background words reduce it to 11/48 without
  touching object pixels. Blank, correct and irrelevant background controls
  preserve or improve it. A blank object card scores 44/48; conflicting words
  score 10/48 with 34/44 targeted flips relative to that card. Scrambled object
  words also hurt (34/48 correct), and that imperfect control is shown.
  Font SHA256, model revision, per-condition denominators and matched margins
  are saved. This is behavioral evidence; sparse-feature mechanism discovery
  and mitigation remain unimplemented.
- **Evidence:** the independent reference harness was actually rerun for all
  old and new experiments. It accepts the expanded contract, at about one
  minute and **7.082 GiB** peak allocation. The first report process was
  terminated before writing; the successful foreground retry replaces it.
  No old manifest was merely rebound to cover these scientific changes.
  All **48 report-evidence contracts pass**. Style, course surface, hard
  ladders, readability and original-preservation audits pass.
- **Repository tests:** **415 passed, 1 failed**. The sole failure is artifact
  hygiene: 168 required payloads are untracked before any next repair plan is
  added. No non-tracking blocker was introduced, and nothing was staged merely
  to make that gate green. No commits, pushes, PR/workflow actions or subagents
  were used. The earlier optional delegation question remains unanswered.

Changed files: 12.1 `lesson.md`, `build_notebooks.py`, `execute_learner.py`,
`pixel_clip.py`, `pixel_tests.py`, `typography.py`, paired notebooks,
`solutions.py`, `tests.py`, README, artifact lock, reference report, expected
output documentation and four learner measurement files; the full instruction
page and four PNG figures; roadmap/style registries and the pixel repair plan.
The two encoder roadmap rows are now TAUGHT. Typography is PREFLIGHT_ONLY,
because its feature-mechanism and mitigation requirements remain open.

Reproduce with the section README. Useful logs: `/tmp/clip-complete-section-tests.log`,
`/tmp/clip-completed-learner-final.log`, `/tmp/clip-final-report-with-page-figures.log`,
`/tmp/arena-full-pytest-sep5-clip-encoders.log`, and `/tmp/clip_completed_learner.ipynb`.
Building notebooks resets outputs; run `execute_learner.py` afterwards. The
CPU-only flag explicitly skips real checkpoints; it cannot support those claims.

**Next priority pilot: 8.3 full edge-level ACDC.** The registry correctly leaves
it PREFLIGHT_ONLY: its real path deletes whole attention-head result components
in pinned GELU-1L, not individual sender-to-receiver edges in an IOI or greater-than
circuit. The exact nonlinear toy and iterative search are useful and should stay.
Initial inspection found a stale README still describing residual-position
pruning; current paired notebooks each have 32 cells and seven exercise groups.
The solved source is exported to `/tmp/acdc-current-lesson.md` for inspection.
Before changing 8.3, finish reading its complete notebooks/page and the original
ARENA 1.4.1 IOI comparator, then write a concrete repair plan. Do not claim the
full ACDC replication from a component-level search or weaken its scope gate.

## Previous continuation: readability repaired without changing experiments

The remaining **108 readability flags are now zero**. This was a formatting
pass over 40 extension source files: long prose paragraphs, four notebook
builders, three long assertions in the mini-NLA tests, I-JEPA notebook source
serialization, and the V-JEPA instruction-page dependency mapping. A fifth
builder change keeps V-JEPA's regenerated mapping readable. No original ARENA
lesson, experiment, control, threshold, result, or release decision changed.

- The exact before-files are saved in `/tmp/arena-readability-before`. All
  **28 affected report manifests matched their inputs before editing**.
- Long Python literals were split without changing values; ordinary Python
  was formatted with Black 26.5.1. Prose wrapping preserves CommonMark output.
  Fenced Python code is compared by AST. The I-JEPA learner's joined source,
  metadata, and outputs are unchanged; its builder now writes physical source
  lines separately. The three formerly giant serialized source lines are gone.
- Before/after captures of **17 generated artifacts from five builders** have
  identical executable code, rendered Markdown, metadata, and outputs. MoE's
  page builder wraps long prose outside fences; V-JEPA pretty-prints only the
  exported literal mapping. Regenerated pages pass the same readability limits.
  Capturing builder writes avoided erasing the executed solution notebooks.
- After those checks, only `report_inputs` was updated in the 28 reports.
  Every measurement date, numerical result, threshold, claim, control, and
  accepted/rejected value remains identical. GPU experiments were not rerun
  for whitespace changes. `docs/arena_salvage/2026-09-05_readability_equivalence.json`
  records the old/new source, semantic, generated-artifact, and manifest hashes.
- **147 affected section tests pass** across 12.5, I-JEPA, MoE, mini-NLA, and
  V-JEPA. Full repository pytest is now **415 passed, 1 failed**. The sole
  failure is artifact hygiene: currently 154 untracked required-payload blockers
  after adding the next repair plan, and no non-tracking blockers. No rejected
  candidate was staged to make it green.
- Preservation PASS covers 290 changed paths (135 tracked, 155 untracked); course
  surface PASS covers 13 chapters, style PASS 46 pages, hard ladders PASS
  45 sections, and report-evidence PASS 48 reports. All actual learner figures,
  exercise stubs, answers, tests, and play behavior are preserved.

The full goal remains active: **205 roadmap rows, 99 UNIMPLEMENTED**. Cosmetic
cleanup does not upgrade teaching or experimental status. No staging, commits,
pushes, PR transitions, workflow enablement, or subagents were used.

**Next substantive repair: complete the 12.1 CLIP/SigLIP pixel-and-token encoder
path.** The current learner trains only two linear projectors over engineered
`image_features` and `text_features`, despite showing rendered images. The
roadmap explicitly requires complete image/text encoders and classification,
retrieval, and typographic controls. Existing real CLIP/SigLIP extraction and
patching should remain. The verified gap and required next work are recorded in
`docs/arena_salvage/2026-09-05_clip_pixel_encoder_repair_plan.md`. Inspect the
complete notebooks and original CNN/transformer comparators before changing
scientific code. Use actual pixels/token IDs, independent train/eval instances,
both tower gradients, meaningful controls and a fresh completed-learner run.
Do not count typographic attacks as complete merely by adding encoder training.

Useful logs and helpers: `/tmp/arena-readability-section-tests.log`,
`/tmp/arena-full-pytest-sep5-readability.log`, `/tmp/arena-readability-formatted.log`,
`/tmp/arena_capture_builder.py`, `/tmp/arena_verify_readability.py`, and
`/tmp/arena_rebind_formatting_manifests.py`. The last script must not be rerun
blindly: it asserts all report data still matches the saved pre-edit snapshot.
The prior QLoRA candidate remains unreleased for its unchanged BF16 parity
failure, and the earlier optional delegation question remains unanswered.

## Previous continuation: QLoRA learner repair and measured CUDA result

This update supersedes the QLoRA-pending description below. The optional 15.3
candidate has been repaired and executed as a completed learner, but remains
unreleased because the original BF16 parity gate fails. The 205-row roadmap is
still active: 29 TAUGHT, 39 PREFLIGHT_ONLY, 25 TOY_ONLY, 13 DEFERRED, and
99 UNIMPLEMENTED. Original ARENA chapters 0–4 remain unchanged. There has been
no staging, commit, push, PR transition, workflow enablement, or subagent spawn.

- **Learner progression:** all seven exercise groups complete using their own
  valid Solution dropdowns; all 21 code cells run in a fresh kernel. The paired
  solution stores those actual outputs. AST completion preserves provided
  helpers and checks, and matches the solution code. The instruction page now
  exports the full progression with measured images, expected outputs, help,
  answers, interpretation, limitations, and three executable play cells.
- **Core repairs:** the old CPU-specific dynamic-codebook endpoint override
  broke six baseline tests under bitsandbytes 0.50.2. CPU and CUDA now use the
  exact current signed dynamic map; corruption rejection remains strict.
  Adapter extraction, freezing, randomization, and quantization-error helpers
  recognize notebook-defined adapters through their visible parameter/method
  protocol. Zero updates have rank zero. Non-CPU smoke requests dispatch to CUDA.
- **Numerical tests:** the forward grader now checks the nonzero quantized base,
  nonunit adapter scale, and analytic A/B/input gradients. The real wrapper is
  checked against its actual base and frozen packed weights. A tiny independent
  closed-form oracle verifies two Adam updates, exact losses, batch labels,
  protected replay, frozen parameters, and optimizer-state accounting. Broken
  adapter-only and replay-free implementations are rejected. Forty-one section
  tests pass, including fresh evidence hashes.
- **Provenance limits:** fingerprints cover all locally defined class methods;
  simple direct, closure, and module reference delegation is diagnosed. Hashes
  do not certify arbitrary Python or substitute for semantic tests and an
  executed learner. The notebook states this limit explicitly.
- **Actual CUDA result:** seeds 0/1/2, 32 steps per trained method, batch 12,
  pinned TinyStories-1M revision 77f1b168e219585646439073245fe87e56b3023e.
  QLoRA r=8 and BF16 LoRA r=8 both reach 1.000 template-transfer and narrow OOD
  accuracy; QLoRA r=2 reaches 1.000/0.983. Random labels average 0.517 and
  same-norm random adapters 0.575 template-transfer accuracy (range 0.500–0.725).
  Name-only and marker-removal controls are 0.500. QLoRA r=8 paired-swap flip
  and both-sides-correct rates are 1.000. Resident state is 38.67 MiB for QLoRA,
  39.18 MiB for BF16 LoRA, and 60.58 MiB for full BF16. The saving against BF16
  LoRA is about 1.3%; eight boolean attention masks alone occupy 32 MiB.
  Peak CUDA allocation is 0.1723 GiB; the comparison takes about 32 seconds.
- **Unchanged failed gate:** maximum BF16 quantized-versus-dequantized matmul
  difference is 0.03125 against the original 0.01 limit. A separate fixed-input
  FP32 control gives 9.54e-7. This supports a precision-dependent discrepancy,
  not a blanket claim that BF16 differences are harmless. No threshold was
  weakened, and no accepted verification report was registered.
- **Visible controls and play:** real behavior/memory panels, per-layer spectra
  including a random low-rank adapter, clean/outlier reconstruction curves,
  editable block size/outlier amplitude, paired prompt inspection, and a CUDA
  precision/parameter/buffer diagnostic. All four displayed figures were viewed.
  The uniform-int8 nested-scale exercise is explicitly a toy arithmetic
  derivation; the actual model uses bitsandbytes' dynamic nested map. Four
  protected prompts are reused for replay, so they are not a held-out capability
  benchmark. QLoRA remains optional and does not replace core LoRA/DoRA/subspace
  or intruder-dimension requirements.

Reproduction is now durable: section-owned `execute_learner.py` fills the actual
learner solely from its dropdowns, checks AST parity, runs a fresh kernel, and
saves executed solution outputs. The historical `generate_cpu_fixtures.py` now
runs that learner (CUDA when available), actual pytest, and writes CPU/CUDA
metrics plus source/notebook/image hashes. `--cpu-only` explicitly records CUDA
as absent. Expected outputs contain the unreleased result, not fabricated success.

Changed files are the QLoRA section sources/tests/builder, new learner executor,
paired notebooks, generator, lock, README and expected outputs; its full
instruction page and two signature PNGs; the dated QLoRA repair plan, roadmap
candidate evidence/reason, and this handoff. Final preservation PASS covers
248 changed paths (95 tracked, 153 untracked); course surface PASS covers
13 extension chapters, style PASS 46 pages, hard ladders PASS 45 sections, and
report evidence PASS 48 registered reports. Full repository pytest is still
**414 passed, 2 failed**: 152 artifact-hygiene blockers and 108 readability flags.
No QLoRA source produces a readability flag. Rejected candidates were not staged.

**Next:** finish the remaining source-readability cleanup with semantic and
manifest equivalence evidence, then continue required real-model/roadmap work.
The 108 flags affect 39 files; 36 occur in existing report input manifests.
Most are long prose, four builders and three long test assertions; I-JEPA also
serializes three large source strings on one JSON line. Preserve joined notebook
source, code ASTs, saved outputs, claims, thresholds, and measured results.
Do not merely rehash stale evidence: establish each old manifest matches the
pre-edit file, verify formatting equivalence, and record any cosmetic manifest
refresh explicitly. Builders must preserve readable regenerated pages. The
existing source-readability plan applies. The broad roadmap still needs 99 rows;
this candidate repair is not course completion. The earlier optional delegation
question remains unanswered.

Useful logs: `/tmp/arena-qlora-reference-final.log`,
`/tmp/arena-qlora-final-tests.log`, `/tmp/arena-full-pytest-sep5-qlora.log`,
`/tmp/arena-qlora-readability.log`, and the matching preservation/style/surface/
hard/report/roadmap logs. `/tmp/qlora_completed_learner.ipynb` and
`/tmp/arena-qlora-learner-metrics.json` retain the latest actual execution.

## Previous continuation: V-JEPA and maze learner repairs

This update supersedes the older 14.3 rejection and 14.4 candidate descriptions
below. Both sections have been repaired and executed as completed learners, but
remain unreleased. The full 205-row roadmap is still the goal; 99 rows remain
UNIMPLEMENTED. No original ARENA lesson, asset, or instruction page was edited.
There has been no staging, commit, push, PR transition, or workflow enablement.

- **14.3 V-JEPA:** all 15 exercise groups complete from their own now-valid
  dropdown answers; all 20 learner code cells run in a fresh CPU kernel. The
  solved notebook preserves those actual outputs. Added a student-built
  blank-future control, exact erasure/nonmutation and analytic context-carryover
  tests, indivisible tubelet rejection, and a zero-rank constant-feature control.
  The three-seed future-retrieval result is negative: learned 0.531 versus
  copy-last-frame 0.703 and blank-future 0.721, with exact dynamics 1.000.
  Teacher final-token features can retain past context despite erased future
  pixels. Five-method figures, explicit expected outputs/help, and editable mask
  and future-frame play cells expose the limitation. Thirty-nine tests pass.
  Protocol v4 references and image fingerprints are fresh. Temporal-shuffle,
  broader state probes, and future-specific matched-context interventions remain
  incomplete; no new real-video claim or course registration was added.
- **14.4 Maze:** all 12 exercise groups complete from their own answers and all
  29 learner code cells execute. A new readable `lesson.md` and AST builder keep
  notebooks, solutions, and instruction export synchronized. Missing template
  dependencies and reference-only immediate tests were repaired. Rollout scores
  now replay actions and check exact BFS optimality instead of trusting flags;
  raw optimality is no longer plotted by copying goal-reach rates. Detour labels
  exclude merely different tie breaks between equally short moves. The former
  "frontier" field is correctly named local legal degree.
- **Maze scientific scope:** CPU action accuracy is 0.781, constrained goal reach
  41/60, raw goal reach 16/60, and template goal reach 12/60. The original numeric
  CPU thresholds pass. The new controls weaken the internal-search interpretation:
  Manhattan distance-bin accuracy is 0.853 versus the learned probe at 0.647;
  same-action other-maze donors yield effect 0.253 versus paired targeted 0.189
  on 23 eligible pairs. An independent action-only oracle reproduces full donor
  recovery without representing maze topology. The notebook explicitly teaches
  policy/state patching, not learned latent rollout or a discovered search circuit.
- **Maze CUDA:** uncontrolled same-seed CUDA runs varied. Training now requires
  fresh-process `CUBLAS_WORKSPACE_CONFIG=:4096:8`, deterministic algorithms, and
  highest float32 matrix precision. Two direct repeated runs, and the separate
  reference generator's repeated runs, produced identical weights and metrics
  (state-dict SHA-256 `6a6ec56005aea7711a31faa4e534d8da4646755973cf4b6299021eef93a4a0e1`).
  The stable larger configuration has action accuracy 0.911, constrained goal
  reach 0.717, targeted patch effect 0.117, positive fraction 0.792, and random
  patch effect 0.0374. It fails three original patch gates; thresholds were not
  weakened. Peak allocation is 0.240 GiB, runtime about 18 seconds. CPU and CUDA
  use different model sizes and prefix-cohort detour mixtures, so this is not a
  controlled scaling comparison. Actual CPU/CUDA metrics, repeatability, test
  output, executed-learner counts, and input hashes are in
  `part4_maze_transformer_world_model/expected_outputs/reference_metrics.json`.
  Course acceptance remains false; no verification report was registered.

Final targeted verification: **59 passing tests** (39 V-JEPA, 20 maze), including
fresh reference-input hashes. Both completed learners have no error outputs.
Figures were visually inspected. Preservation PASS checks 245 changed paths;
course surface PASS covers 13 extension chapters, style PASS 46 pages, hard
ladders PASS 45 sections, and report-evidence PASS 48 registered reports. The
repository suite remains **414 passed, 2 failed**: artifact hygiene (149 blockers,
largely untracked required payloads) and source readability (108 remaining real
long-line flags after this continuation's wrapping). Rejected candidates were
not staged merely to make hygiene green.

Changed surfaces: the two chapter-14 section directories, their instruction
pages and generated figures, two dated repair plans, roadmap evidence/reasons,
and this handoff. Original ARENA is preserved against the pinned base.

Next repair **15.3 QLoRA** before adding any topic directory. The first inspection
confirms `extract_selected_updates` still recognizes only the reference wrapper
classes, `_solution_dropdown` still indents the first inserted code line, and
the identity/fingerprint provenance checker is not proof that a callback avoids
reference delegation. The zero-update spectrum also gives effective rank one
unless its zero case is handled. Inspect its notebook/page and strengthen actual
forward/training oracles; do not substitute this optional lab for the roadmap's
LoRA/full-finetuning/DoRA/subspace requirement. Then continue release/readability
repairs and all remaining required real-model and roadmap work. No subagents
have been spawned in this continuation; the pending delegation question remains
unanswered.

Useful logs: `/tmp/arena-vjepa-execution.log`, `/tmp/arena-vjepa-reference.log`,
`/tmp/arena-maze-execution-final.log`, `/tmp/arena-maze-reference-final.log`,
`/tmp/arena-maze-cuda-repeat.log`, `/tmp/arena-vjepa-maze-final-tests.log`, and
`/tmp/arena-full-pytest-sep5-continuation.log`. Completion helpers are
`/tmp/arena_execute_vjepa.py` and `/tmp/arena_execute_maze.py`; they fill only
dropdown stubs and compare the completed cells with the paired solution.

## Previous continuation: learner repairs and audit reconciliation

This update supersedes the older failure descriptions below for 5.7, 7.2,
7.4, 14.2, 5.8, 9.5, 12.5, and 8.6. The full goal remains unfinished. No original ARENA chapter was
edited. No commit, push, PR transition, or workflow enablement has occurred in
this continuation, and pre-existing dirty candidate work has been retained.

- **5.7:** all eleven answer dropdowns parse and complete the learner. All 21
  learner code cells execute, including released Mamba-2 CUDA parity. The
  mismatch was Triton's default TF32 dot precision; fresh-process IEEE float32
  resolves it without increasing tolerances. Mapping covers 219 tensors and 25
  hidden states; maximum hidden/logit error is approximately 0.000946/0.000126.
  Equal-budget recall is 1.000 versus approximately 0.508 for both state ablation
  and the local-convolution control; doubled-length accuracy is 0.753. Twenty-two
  section tests pass. The source lesson and builder now synchronize all surfaces.
- **7.2:** fixed the learner layer-sweep dependency, completed all 14 code cells
  from six dropdowns, and passed sixteen tests. The exhaustive decoding null
  remains a negative result (p approximately 0.134). Real bidirectional effects
  8.48/9.62 exceed the stronger 256-pair-swap null p95 values 8.10/9.02, with
  p approximately 0.0156/0.0078. The explanations are human-authored predicates;
  this does not finish automatic feature verbalization.
- **7.4:** all 14 learner code cells complete from nine dropdowns; 23 tests pass.
  The live contextual reconstruction gives FVE 0.816 and behavior parity 1.0
  versus bag-of-tokens 0.642 and 0.0. The strong 0.841 within-factor bypass FVE
  remains visible. The real row-local edit changes a candidate logit by 5.61.
  This is a supervised templated warm-start; its roadmap status is PREFLIGHT_ONLY.
- **14.2:** reconciled an interrupted implementation/interface repair, added
  exact image-space key-erasure tests, and completed all 28 code cells from twelve
  dropdowns. All 28 tests pass. All three fixed CUDA seeds recover correct and
  alternate classes perfectly; original-after-swap is zero and erased-key is
  one-third, with exact non-key pixel locality. Evaluation uses different pixels
  but shares all twelve semantic templates. Seed 1 effective rank is 1.429 and
  disclosed separately from scale and causal recovery. The target ablation changes
  both stop-gradient and EMA. The section remains TOY_ONLY pending real CIFAR/STL
  learning, improvement over random features, and a released-checkpoint comparison.

These four sections remain `prototype` pending independent review. The active
session forbids spawning agents without explicit authorization. An asynchronous
question requesting permission for gpt-5.6-sol/xhigh reviewers and disjoint repairs
has been sent; no answer has arrived. Do not silently assume authorization.

Supporting maintenance:

- Added the exact root `HANDOFF.md` preservation allowance; the pinned original
  tree audit passes. Original-preservation roadmap status is now TAUGHT.
- Reconciled the method registry with existing 13.2 and 14.2 coverage without
  upgrading their scoped scientific claims.
- Refreshed the hard-exercise registry: it had omitted four existing hard
  sections and now checks all 45. Added immediate success/failure feedback,
  precise fixture provenance, and an AST-based unfinished-function checker.
  The hard-exercise and style audits pass after these repairs.
- Fixed stale repository tests that insisted existing toy/preflight sections were
  UNIMPLEMENTED or imposed one generic floating-point tolerance on every fixture.
  Actual report acceptance and numerical scientific thresholds remain required.
- Twelve affected section GPU reports were regenerated serially and accepted.
  The final refresh for 5.7, 13.2, 14.2, and 15.2 also finished and all 48 registered
  report-evidence checks passed. Mamba's first retry correctly rejected a missing
  IEEE environment setting; its documented fresh-process retry passed.
- The full repository suite passed 412 tests and failed artifact hygiene and
  source readability. No rejected/unreviewed payloads were staged to satisfy
  hygiene. The readability audit incorrectly counted embedded PNG/JPEG output;
  it now exempts only actual binary MIME outputs/attachments. Six focused tests
  pass. Long source lines remain real blockers (see the readability repair plan).
- Normalized multiline notebook source arrays in the MoE/V-JEPA builders and
  existing candidate notebooks; code and retained outputs are unchanged.

Detailed repair plans are in `docs/arena_salvage/2026-09-05_*_repair_plan.md`.
The current roadmap has 205 rows: 29 TAUGHT, 39 PREFLIGHT_ONLY, 25 TOY_ONLY,
13 DEFERRED, and 99 UNIMPLEMENTED. The full-completion audit correctly remains
red. Existing candidate repairs continue before adding topic directories.

- **5.8 MoE:** the prior source had corrected Switch top-1 probability gates and
  per-sequence left-to-right capacity, but its notebook still taught the obsolete
  straight-through/global-affinity algorithm. The builder now regenerates all
  twelve answers and a staged visible experiment. All 22 learner code cells run;
  32 tests pass, including prefix/batch invariance. The three-seed CPU result has
  accuracy 0.994, longer-context accuracy 0.657, balanced overflow 0.181, and zero
  preferred-expert ablation loss. The original specialization and overflow release
  thresholds remain unchanged and rejected. The figure presents falsification
  explicitly. Sparse padding uses 1620 FFN slots versus 1440 dense slots, so it
  makes no compute-saving claim. No CUDA or release registration was performed.
- **9.5 ROME:** repaired missing provided row helpers, learner-bypassing immediate
  tests, and optimizer history that described the step before the returned vector.
  All 32 learner code cells execute from thirteen answers; 33 tests pass. Independent
  checks cover final multi-token loss/KL, complete biased MLP captures, and exact
  weight restoration on exceptions. Pythia gives 20/20 pairwise preferences but
  17/20 top-1, retention 11/14, leakage-only Rome probability increase 0.448,
  actual affine write error 2.97e-6, and final value KL 0.729. Five layers plus the
  wrong-position edit pass the pairwise threshold. It remains an unreleased
  negative localization case, with no official ROME protocol parity or CUDA report.

Both roadmap rows now acknowledge their existing candidates instead of falsely
saying no notebook exists, but remain UNIMPLEMENTED on the release surface.
**12.5:** all 28 CPU learner code cells now complete from eight answer dropdowns;
25 section tests pass. Missing helper definitions are supplied visibly. Real
preflight acceptance now rejects wrong checkpoint identity, NaN/infinite or
impossible metrics, mismatched counts, incomplete controls, and row/aggregate
inconsistency. Its neutral-prior intervention cohort is explicitly insufficient
for hallucination repair or four-stage diagnosis. No real Qwen run was performed;
the report is still unaccepted and its CPU test/time/provenance were refreshed.

Latest global checks: preservation, course surface, style, hard exercises, and all
48 registered report-evidence checks pass. The full repository suite is 414 passed,
2 failed. After the latest AtP* artifacts, the focused audits show 145 artifact
hygiene blockers and 116 source-readability flags. These failures remain open;
do not stage rejected candidates just to clear them. The preservation audit checks
241 changed paths and has zero blockers.

**8.6 AtP* repaired:** independent scalar-chain tests first reproduced the gradient
bug (expected 48 for vanilla and 8 for GradDrop; both returned 2). Hooks now retain
intermediate gradients without detaching the graph, except the selected GradDrop
residual outputs. Four new numerical tests verify cross-layer paths, two-token
Q/K correction, and absolute-value aggregation. All 25 section checks pass, and
all 20 learner code cells execute from eleven dropdowns. `lesson.md` and a new
builder synchronize all surfaces. Real cache/patching/gradient/GradDrop and control
orchestration are visible in the notebook; the former Markdown-only playground
is now executable. Corrected Pythia Spearman is approximately 0.943 vanilla and
0.993 AtP*, with top-eight effect 0.489 versus random mean 0.189, best 0.417,
pair-shuffled 0.266, and label-shuffled 0.395. Same-suite screening/verification is
explicit. The EAP-style comparison is toy-only. Original numerical thresholds
are unchanged. The formerly always-accepted CPU report is now schema-enforced
unaccepted, with actual CPU checks and a fresh input manifest; independent review
and CUDA evidence remain pending. Subset-sampling diagnostics remain missing.

Next classify/repair 14.3 V-JEPA, 14.4 Maze Transformer, and 15.3 QLoRA before
adding any topic directories. V-JEPA received source-array formatting only during
this continuation; its failed persistence claim has not been repaired. Complete these classifications before adding topic directories,
then finish real/model paths and missing scope.

This file is the durable handoff for the active objective:

```text
Salvage the ARENA_3.0_Extended extension into actual ARENA-style
interactive pedagogy using arena_salvage_guidance_pack.zip, starting
with a pilot rewrite of 7.1 and preserving original ARENA append-only.
```

The objective is not complete. Do not infer completion from a green unit test,
an accepted `verification_report.json`, or a `course_ready` label. The current
repository contains substantial good work, but it also contains stale release
claims, uncommitted candidates, rejected science, and incomplete roadmap scope.

## Read This First

Use these files in this order:

1. `AGENTS.md` - repository-level non-negotiable salvage rules.
2. `.agents/skills/arena-3-salvage/SKILL.md` - operational ARENA rewrite skill.
3. `docs/arena_salvage/ARENA_SALVAGE_GUIDANCE.md` - diagnosis and editorial bar.
4. `docs/arena_salvage/ARENA_NOTEBOOK_CONTRACT.md` - required notebook shape.
5. `docs/arena_salvage/SECTION_REWRITE_BLUEPRINTS.md` - section-specific designs.
6. `docs/arena_salvage/CODEX_GOALS.md` - staged goals and stopping conditions.
7. `Extension-Roadmap.md` - full requested extension scope.
8. `docs/roadmap_requirement_registry.yml` - requirement-by-requirement status.
9. `docs/arena_style_rewrite_status.yml` - current editorial status declarations.
10. This file - current execution state, failures, and route to completion.

The original guidance bundle remains at `arena_salvage_guidance_pack.zip`.
The earlier style-writer bundle is `arena-3-style-course-writer-skill.zip`.

## Non-Negotiable Standard

Original ARENA is the canonical base and must remain append-only. Do not edit
original notebooks, pages, or assets unless an explicit upstream compatibility
patch is requested.

Every extension section must let the learner:

- understand one concrete question;
- implement the method being taught in the notebook;
- receive immediate semantic sub-function feedback;
- see one convincing, interpretable signature result;
- change an input, layer, feature, intervention, or hypothesis;
- compare against meaningful baselines and negative controls;
- connect toy ground truth to a paper or real model;
- understand exactly what the result does and does not establish.

Every notebook needs expected outputs, help/interpretation dropdowns, valid
solution dropdowns, a `Try It Yourself` cell, anomaly hunting, and honest
limitations. Every plot needs metrics and controls. Hard exercises need toy or
reference oracles and step-by-step tests. A report is supporting evidence, not
the lesson.

Do not ship mocks, fakes, placeholders, skipped-success paths, CPU fallbacks for
required CUDA evidence, white-noise visuals, or report-shaped dictionaries as
the primary result. A negative result is acceptable when it is real, visible,
and honestly labeled.

## Repository And PR State

- Repository: `/home/bitwise/Documents/ARENA_3.0_Extended`
- Branch: `codex/arena-frontier-lab-extension`
- Current committed HEAD: `8eab192b` (`Teach denoising-time causal patching`)
- Remote branch: currently also at `8eab192b`
- Pull request: `https://github.com/shinobiultra/ARENA_3.0_Extended/pull/1`
- PR state: open, draft, mergeable
- GitHub workflow `Extension Quality`: manually disabled
- In-progress GitHub Actions at snapshot time: none
- Live subagents at snapshot time: none
- Live pytest/notebook/CUDA jobs at snapshot time: none

The working tree is intentionally dirty and large. Current repairs after
`8eab192b` are not committed or pushed. Do not use `git reset --hard`,
`git checkout --`, `git clean`, `git add -A`, or any broad staging command.
Inspect and stage exact paths or exact hunks only. Several shared files contain
changes for multiple sections:

- `infrastructure/core/config.yaml`
- `infrastructure/core/config_extension.yaml`
- `docs/arena_style_rewrite_status.yml`
- `docs/roadmap_requirement_registry.yml`
- `pyproject.toml`
- `uv.lock`

## Environment State

The repository uses the managed `.venv` through `uv`.

```text
Python:             3.14.2
PyTorch:            2.12.1+cu132
torchvision:        0.27.1+cu132
CUDA runtime:       13.2
GPU:                NVIDIA GeForce RTX 5090 Laptop GPU
GPU memory:         24463 MiB
Driver:             610.57.04
transformers:       5.12.1
mamba-ssm:          2.3.2.post1
causal-conv1d:      1.6.2.post1
bitsandbytes:       0.50.2
```

`bitsandbytes==0.50.2` and the matching `uv.lock` update are currently
uncommitted. This wheel contains `libbitsandbytes_cuda132.so`; however, the
15.3 QLoRA notebook has not been revalidated after this upgrade. The previous
QLoRA review found several independent correctness failures that the new binary
does not fix.

Use only `gpt-5.6-sol` with `xhigh` reasoning for every subagent and reviewer.
Never use `gpt-5.5`. Parent execution must serialize GPU jobs so measurements
are attributable and VRAM peaks are meaningful.

## What Has Been Done

### Salvage infrastructure

- Installed the `arena-3-salvage` skill under `.agents/skills/`.
- Added the root `AGENTS.md` course-quality contract.
- Added the salvage guidance, notebook contract, rewrite blueprints, and staged
  goals under `docs/arena_salvage/`.
- Added strict learner-surface, hard-exercise, report-evidence, GPU-report,
  artifact-hygiene, original-preservation, and roadmap-completeness audits.
- Added a requirement registry covering 205 roadmap requirements.
- Added CUDA-backed verification reports for the committed extension surface.
- Created PR #1 and pushed the committed salvage history through `8eab192b`.
- Disabled the repeatedly failing GitHub workflow to stop notification spam
  while local repair work is incomplete.

### Original ARENA preservation

The original ARENA baseline is pinned in
`docs/original_preservation_contract.md` at:

```text
f9f034bdb5b8748f44e8b4533b5c5bea68dc8bc0
```

Fresh snapshot result:

```text
changed_paths_checked=166
preservation_blockers=0
ORIGINAL_ARENA_PRESERVATION=PASS
```

This is the strongest clean invariant in the current repository. Preserve it.

### Pilot 7.1

The requested pilot rewrite is implemented and currently marked
`course_ready`:

`chapter7_activation_to_language/exercises/part1_lenses_patchscopes/`

It now teaches logit lens, a ridge/tuned lens, activation replacement, and
Patchscope evaluation through learner-visible functions, actual prompts and
tokens, immediate tests, a layer-decoding result, controls, play cells, and
limitations. The current recorded result uses 24 disjoint Pythia-70M prompts:

- median target rank improves from 18,163 at the embedding to 1 at the final
  block;
- block-5 Patchscope insertion recovers 87.5% of source targets;
- text-only, cyclic wrong-source, and matched-scale random controls score 0%;
- mean target log-probability gain is 7.73;
- the CUDA TransformerLens preflight reports tuned-lens held-out accuracy 0.450
  versus logit-lens 0.075 and Patchscope 1.0 versus text-only 0.0.

The learner surface has 13 exercises, 17 focused tests, a visible three-panel
result, a layer-selection play cell, and an anomaly hunt. Its claim is
decodability and activation transfer, not belief or full circuit causality.

### Other sections currently marked course-ready

The style registry currently contains 42 `course_ready` entries:

```text
0.6
1.6
5.1-5.6
6.1-6.4
7.1, 7.3, 7.5
8.1-8.5
9.1-9.4
10.1
11.1
12.1, 12.3
13.1, 13.2
14.1
15.1, 15.2
16.1-16.8
17.1
```

This label is not final proof. The hard-exercise audit still finds 23 blockers,
including missing fixture provenance/tolerances, forbidden placeholder terms in
visible tests, and missing ARENA-style success messages. Before final release,
every one of these 42 sections needs either a fresh independent editorial pass
or explicit demotion to `prototype`/roadmap status.

## Current Uncommitted Work

The current working tree contains major edits to 7.2 and 7.4 plus untracked
candidate sections. Treat each candidate as untrusted until its own row below is
closed.

| Section | Current evidence | Current blocker / required next action |
| --- | --- | --- |
| 5.7 Mamba-2 / SSD | 17 CPU tests pass; exact CPU operator, cache, gradient, and 219-tensor checkpoint mapping checks pass | Eight of eleven solution dropdowns are syntactically invalid. CUDA result is rejected; repair the implementation/tolerances, regenerate notebooks/page from one source, then independently review and rerun the report. |
| 5.8 Mixture of Experts | 31 test functions and a substantial toy/trained MoE candidate exist | Independent review was interrupted and no report exists. Finish harsh review before any GPU run. |
| 7.2 Feature Verbalizers | 24 test functions; current report says accepted but its input hashes are stale | Finish independent review of the revised hypothesis-discovery loop and matched causal nulls; rerun notebook, CUDA evidence, and generic verifier; replace `review_pending` with a valid status. |
| 7.4 Mini NLA | 22 tests and fresh accepted CUDA report exist; contextual order-sensitive path has behavior parity 1.0 versus bag-of-tokens 0.0 | Independent review was interrupted. Fix hard-exercise audit failures, finish review, and promote only after PASS. It remains a supervised templated warm-start, not full paper-scale NLA. |
| 8.6 AtP* | 19 test functions; report file exists | Report has `accepted=true` but no CUDA evidence and three known failures. This is rejected evidence. Repair/review or remove from the release surface. |
| 9.5 ROME | 29 test functions and a 69-cell candidate notebook exist | Repair was interrupted; no report exists. Resume from prior review findings, finish CPU and scientific review, then run strict CUDA. |
| 12.5 Object Hallucination / Arbitration | 22 CPU tests pass; toy ground truth exists | Independent review failed. Real interventions avoid hallucination cases, acceptance is forgeable, completed learner stubs leave undefined functions, section is not correctly released, and the real diagnostic decomposition is too weak. Repair before GPU. |
| 14.2 I-JEPA | Latest repair has 25 CPU tests and corrected 12 dropdowns; prior CUDA report exists | Report hashes are stale after repair and editorial re-review was interrupted. Re-review, execute the whole solution notebook including strict CUDA, regenerate report, and replace `review_pending`. |
| 14.3 V-JEPA | 36 test functions and a toy candidate exist | Scientific re-review failed: the claimed persistence signal was context carryover, and zero-future/copy-last controls beat the learned V-JEPA result. Keep as a negative lab or redesign from the ground up. |
| 14.4 Maze Transformer | 13 test functions and a candidate notebook exist | No independent review and no report. Audit science, learner progression, controls, and exact planning claim before registration. |
| 15.3 QLoRA | CPU implementation and 30 test functions exist; CUDA 13.2 bitsandbytes binary is now installed | Independent review failed on broken learner class handling, invalid dropdowns, forgeable provenance, bypassable hard tests, missing release wiring, and roadmap mismatch. The environment upgrade fixes only the old missing-binary issue. |

Do not commit all untracked candidates merely to make artifact hygiene green.
Rejected candidates must be repaired, honestly demoted, or excluded from the
course configuration before staging.

## Important Scientific Findings

### 5.7 CUDA result: real failure

The direct CUDA 13.2 run completed in 69.39 seconds at 1.543 GiB peak VRAM.
Delayed recall behaved convincingly:

```text
Mamba-2 accuracy:          1.0000
state-ablated accuracy:    0.5078
local-convolution accuracy:0.5078
shuffled-label accuracy:   0.4961
2x-length OOD accuracy:    0.7529
```

But release parity failed:

```text
fused operator max error:          0.003452  (gate: 0.0002)
from-scratch hidden max error:     0.433167
from-scratch hidden mean error:    0.009980
from-scratch logits max error:     0.037079
from-scratch logits mean error:    0.012801
top-1 token agreement:             1.0
accepted:                          false
```

Do not relax tolerances until the dtype/discretization/kernel semantics are
understood. Also reconcile the official vocabulary/logit shape, which was
`50288` in the live result while the lock expected `50280`.

### 7.2 claim boundary

The original revision's held-out decoder was non-significant under an exact
pair-preserving null (`p` about 0.134). The current rewrite correctly treats
that as a negative decoding result and focuses the positive claim on causal
residual replacement against matched direction controls. The final reviewer
must verify that the revised controls cannot be bypassed and that the learner
actually performs hypothesis generation, validation, counterexample search,
and revision rather than selecting a prewritten label.

### 7.4 shortcut repair

The initial mini-NLA result was invalid because a bag-of-tokens ridge bypass
beat the contextual autoregressive path. The repair changed the explanations so
all factor states within a lexical context use the same token multiset but
different order. Current CUDA metrics are:

```text
contextual behavior parity:        1.000
bag-of-tokens behavior parity:     0.000
contextual normalized FVE:         0.816
bag-of-tokens normalized FVE:      0.642
bag-of-tokens within-factor FVE:   0.841
same-context token multiset:       1.000
text-edit selected-logit change:   5.61
peak VRAM:                         1.009 GiB
```

The strong bag-of-tokens within-factor FVE is intentionally visible: lexical
fit can look good while failing the ordered causal factor test.

### 12.5 rejection

The real Qwen path did not yet establish hallucination arbitration. Its
counterfactual pairs were ordinary object-presence examples rather than
model-defined hallucinations. Its acceptance gate accepted wrong model IDs,
invalid layers, zero-incidence results, and NaN values. Its validation/test
splits repeated prompts and images, and its geometry controls were weak. Repair
must begin from held-out model-defined conflict/hallucination cases and paired
causal criteria, not from prettier figures.

### 14.2 repair

The latest I-JEPA repair fixed malformed dropdowns, replaced weak zero-module
tests with exact four-patch encoder/predictor oracles, added an exact `0/2/1`
loss oracle, tested `validate_run` against corrupted fixtures, rejected unequal
mask cardinalities, and deepened the learner background. Last recorded CPU
result was 25 passing tests and 26 executed non-CUDA solution cells. The real
roadmap requirement still needs CIFAR-10/STL-10-scale learning, improvement over
a random ViT, and released I-JEPA comparison; current scope is toy-only.

### 14.3 rejection

The learned V-JEPA candidate did not beat controls on the intended persistence
claim. A zero-future retrieval baseline and copy-last baseline outperformed the
learned model. Keep this as a visible negative result only if the notebook is
rewritten around that falsification; otherwise redesign the task and loss with
foreground metrics, temporal shuffles, and genuine future-information controls.

### 15.3 rejection

The QLoRA learner notebook previously failed before the real comparison because
the evaluator recognized only the reference wrapper class. All seven solution
dropdowns were malformed. Provenance could be forged with thin wrappers, and
the forward/training tests accepted implementations that omitted the taught
algorithm. The section also does not satisfy the roadmap's core 15.3 LoRA vs
full-finetuning/DoRA/subspace/intruder-dimension requirement. Treat QLoRA as a
separate optional lab, not as a replacement.

## Fresh Audit Snapshot

These commands were run against the current worktree on 2026-09-05.

```text
Original preservation:       PASS (0 blockers)
Course surface:              FAIL (2 blockers: 5.7, 7.2)
ARENA style depth:           FAIL (3 blockers: 5.7, 7.2, 14.2)
Hard exercise ladders:       FAIL (23 blockers across 41 hard exercises)
Report evidence contracts:   FAIL (61 blockers across 48 reports)
GPU verification reports:    FAIL (3 missing: 5.7, 8.6, 12.5)
Roadmap final completeness:  FAIL (69 blockers)
```

The current roadmap registry contains:

```text
205 total requirements
29 TAUGHT
38 PREFLIGHT_ONLY
25 TOY_ONLY
13 DEFERRED
100 UNIMPLEMENTED
```

Therefore the full `Extension-Roadmap.md` is not close to complete. The 42
`course_ready` labels describe a curated implemented surface, not completion of
the roadmap.

The hard-exercise audit currently calls out, among others, 6.3, 7.2, 7.3, 7.4,
7.5, 8.2, 8.3, 9.3, 10.1, 12.1, 12.3, 16.7, 16.8, and 17.1. Run the audit and
fix each exact diagnostic rather than editing the audit to make it pass.

## FOR_REVIEW State

Current artifacts:

```text
FOR_REVIEW/FOR_REVIEW.pdf
FOR_REVIEW/FOR_REVIEW.tex
FOR_REVIEW/ARENA_core_chapters_exercises_solutions.tar.gz
FOR_REVIEW/README.md
```

The archive is correctly narrow in intent: chapter instruction pages plus
paired exercise/solution notebooks, with no reports, tests, caches, model
artifacts, environment files, or Git metadata.

The current PDF is stale and must not be used as a release verdict. It is dated
2026-07-02, says there are 41 course-ready sections and that strict completion
passes, while the current worktree has 42 marked course-ready sections and the
fresh strict audits fail. Regenerate both PDF and archive only after final
section review and global gates. The final PDF must explicitly list every
`DEFERRED` requirement and its concrete 24 GB/model-access reason.

## How To Finish The Goal Completely

### Phase 1: stabilize and triage the current worktree

1. Do not add new topic directories until every current candidate is classified.
2. Finish or reject the near-ready repairs in this order: 7.2, 7.4, 14.2, 5.7.
3. Then review/repair 5.8, 9.5, 12.5, 8.6, 14.3, 14.4, and 15.3.
4. Remove a candidate from course configuration if its science fails. Keeping a
   negative-result notebook is fine only when falsification is its explicit
   learner-facing lesson.
5. Commit coherent sections separately. Never mix unrelated shared-file hunks.

Immediate next action: repair 5.7's invalid dropdowns from the exact tested
`solutions.py` implementations, add AST parsing tests for every dropdown,
re-execute the solution notebook, diagnose the CUDA parity discrepancy without
tolerance inflation, add a valid `prototype` status and roadmap evidence, then
obtain an independent harsh review.

### Phase 2: use one acceptance pipeline for every section

For each section:

1. Read its exact `Extension-Roadmap.md` requirements.
2. Read the closest original ARENA page and notebook as an editorial comparator.
3. Write one claim naming phenomenon, model/task, evidence, and control.
4. Start with exact toy ground truth or a hand-computable oracle.
5. Expose the core operation, metric, intervention, control, and aggregation as
   learner implementations.
6. Put semantic tests directly below each hard function. Test malformed shapes,
   edge cases, bypasses, and at least one exact expected value.
7. Generate one visible signature result in the notebook. Show concrete tokens,
   prompts, images, trajectories, graphs, or examples, not only summary metrics.
8. Add baseline and negative-control results to the same figure/table.
9. Add expected output, help, solution, interpretation, play, anomaly, paper
   connection, and limitations surfaces.
10. Parse every solution dropdown as Python and execute the completed learner
    notebook, not only the reference `solutions.py`.
11. Run CPU tests first. Independently review scientific design before GPU.
12. Run strict CUDA on the real model/data path with pinned revisions and a
    24 GB assertion. No fallback and no skipped-success path.
13. Visually inspect every generated figure and qualitative example. Reject
    white noise, collapse, trivial leakage, and prettier-than-informative plots.
14. Regenerate the generic report so hashes bind to the final notebook, page,
    tests, code, expected outputs, and schema.
15. Run all section and global audits.
16. Obtain an independent `gpt-5.6-sol`/`xhigh` review. Promote to
    `course_ready` only after a real PASS.

### Phase 3: re-audit the 42 existing course-ready sections

Use six independent reviewers in disjoint chapter batches. A practical split is:

```text
Reviewer 1: 0.6, 1.6, 5.1-5.6
Reviewer 2: 6.1-6.4, 7.1, 7.3, 7.5
Reviewer 3: 8.1-8.5, 9.1-9.4
Reviewer 4: 10.1, 11.1, 12.1, 12.3
Reviewer 5: 13.1, 13.2, 14.1, 15.1, 15.2
Reviewer 6: 16.1-16.8, 17.1
```

Reviewers must contrast each section with original ARENA, inspect actual
notebook progression and outputs, try to bypass tests/acceptance gates, and
recompute the scientific claim. They must not merely count metadata keywords.
Demote any section that fails. Repair in small, disjoint batches.

### Phase 4: close the full roadmap honestly

`docs/roadmap_requirement_registry.yml` is the checklist. For every one of its
205 requirements:

- `TAUGHT` needs learner-facing implementation and accepted evidence;
- `PREFLIGHT_ONLY` needs the missing full exercise/model path completed;
- `TOY_ONLY` needs the requested real-model/dataset escalation completed;
- `UNIMPLEMENTED` needs a new ARENA-quality section or a justified scope
  decision grounded in `Extension-Roadmap.md`;
- `DEFERRED` is allowed only for a genuine 24 GB, unavailable-weight,
  unavailable-kernel, gated-access, simulator, or data blocker.

Do not convert feasible work to `DEFERRED` to make the counts green. The user
can provide gated access. When access is the only blocker, name the exact model,
dataset, license, repository, or token required.

The current 100 `UNIMPLEMENTED` requirements include major feasible topics such
as a Llama-like decoder, Gemma quantization, MoE, RWKV/RetNet/Griffin/xLSTM/
Hyena/linear attention, BatchTopK SAEs, skip transcoders, feature dashboards,
MAIA/OpenMAIA, representation alignment, causal probes/DAS, CCS, concept
erasure, and causal abstraction. Do not claim the extension is finished while
these remain unless the user explicitly narrows the roadmap.

### Phase 5: final verification

At minimum, run:

```bash
uv sync --frozen
uv run python scripts/audit_original_arena_preservation.py
uv run python scripts/audit_course_surface.py
uv run python scripts/audit_arena_style_depth.py
uv run python scripts/audit_learner_surface.py <each extension notebook/page>
uv run python scripts/audit_hard_exercise_ladders.py
uv run python scripts/audit_report_evidence_contracts.py
uv run python scripts/audit_gpu_verification_reports.py
uv run python scripts/audit_extension_artifact_hygiene.py
uv run python scripts/audit_roadmap_final_completeness.py
uv run python scripts/audit_extension_completion_strict.py
uv run pytest -q
```

Also execute every solution notebook from a clean kernel. CUDA-required sections
must retain visible real outputs and report the actual GPU, CUDA runtime, model
revision, example count, controls, wall time, and peak VRAM.

All commands must pass for the right reason. Read every failure and fix the
course or evidence; do not weaken gates to match the implementation.

### Phase 6: rebuild review artifacts

After the tree is frozen and all reports are fresh:

1. Regenerate `FOR_REVIEW/FOR_REVIEW.tex` and `FOR_REVIEW/FOR_REVIEW.pdf`.
2. Describe what was built, notebook progression, individual exercises,
   signature results, controls, grading/tests, and how each section blends into
   original ARENA.
3. Include limitations, negative results, all unfinished roadmap requirements,
   and every justified deferral.
4. Rebuild `FOR_REVIEW/ARENA_core_chapters_exercises_solutions.tar.gz` with only
   chapter instruction pages and paired exercise/solution notebooks.
5. Verify the archive contains nothing else and that all expected notebook/page
   counts match the final config.
6. Render the PDF to images and visually inspect every page before release.

### Phase 7: commit, push, and finish PR #1

1. Review the complete diff and remove stale generated artifacts.
2. Stage exact section paths and exact shared-file hunks.
3. Commit in reviewable batches with the scientific result in each message.
4. Push `codex/arena-frontier-lab-extension`.
5. Re-enable `Extension Quality` only after all local gates pass.
6. Run it once, fix any real CI-only issue, and avoid repeated failing pushes.
7. Update the PR body with the final scope, evidence, deferred items, and review
   artifact links.
8. Mark the PR ready for review only when the completion audit proves the full
   goal, not when the diff merely looks large.

## Studying While Salvage Continues

The original ARENA course is preserved and can be studied now. For the extension,
start with the strongest finished pilot rather than the dirty candidates:

```bash
cd /home/bitwise/Documents/ARENA_3.0_Extended
uv run jupyter lab
```

Open:

```text
chapter7_activation_to_language/exercises/part1_lenses_patchscopes/
  7.1_Logit_Lens_Tuned_Lens_and_Patchscopes_exercises.ipynb
```

Use the corresponding solution notebook only after attempting each exercise.
For the canonical original ARENA style comparator, study:

```text
chapter1_transformer_interp/exercises/part32_function_vectors_and_model_steering/
chapter1_transformer_interp/instructions/pages/12_[1.3.2]_Function_Vectors_&_Model_Steering.md
```

Avoid beginning with 5.7, 5.8, 7.2, 7.4, 8.6, 9.5, 12.5, 14.2-14.4, or 15.3
until their pending reviews and evidence are resolved.

## Resume Checklist

At the start of the next work session:

```bash
cd /home/bitwise/Documents/ARENA_3.0_Extended
git status --short --branch
git log -1 --oneline --decorate
nvidia-smi
gh pr view 1
gh run list --status in_progress
uv run python scripts/audit_original_arena_preservation.py
```

Then inspect current file timestamps and diffs before trusting this snapshot.
Resume the 5.7 repair locally and delegate only disjoint CPU review/repair tasks.
Use at most six subagents, all `gpt-5.6-sol` with `xhigh` reasoning. Keep GPU
execution in the parent task and run it only after the relevant scientific and
learner-surface review passes.


## Continuation execution notes (2026-09-05)

Completed-learner scripts in `/tmp/arena_execute_{mamba2,verbalizers,mini_nla,ijepa,moe,rome,arbitration,atp}.py`
replace only notebook stubs from adjacent answer dropdowns, require AST equivalence
with the solution cells, then execute the whole learner in a fresh kernel and save
those outputs to the matching solved notebook. Use the section builders first when
changing method code or lesson text; rerun the corresponding script afterward.

- Mamba report/run environment: `TRITON_F32_DEFAULT=ieee OMP_NUM_THREADS=8 MKL_NUM_THREADS=8`.
- AtP* and 12.5 builders support `--finalize` after learner execution. They actually
  run section tests before claiming CPU tests passed and preserve unaccepted CUDA
  release status. The one manifest-freshness check runs after finalization.
- `/tmp/arena-full-pytest-final.log` records 414 passed and 2 failed. The two failures
  are expected open release-work items, not ignored or converted into passes.
- `/tmp/arena-roadmap-current.txt`, `/tmp/arena-readability-current.log`, and
  `/tmp/arena-artifact-hygiene-current.log` contain the current outstanding rows.
- No original chapter edits, commits, staging, pushes, or PR/workflow transitions
  were made in this continuation. No subagents were started.

Current execution notes: checkpointed learner-search plumbing has a passing
reuse/fresh-execution/tamper test (`/tmp/acdc-checkpoint-wrapper-tests.log`).
A CUDA replay prototype matched 12 tested GPT-2 masks exactly but showed only
a modest timing difference under shared GPU load (0.264 vs 0.225 seconds). It
was not adopted or left in the course; its source/result remain in
`/tmp/acdc_cuda_edge_replay_prototype.py` and `/tmp/acdc-cuda-replay-candidate.json`.
The eager engine and active search source remain unchanged.

A fresh kernel is executing the 69-cell prefix through the real greater-than
curves and play cell, completed from its own answers, in TTY session **47434**. Log: `/tmp/acdc-fast-learner-execution.log`.
The source is unchanged while this prefix runs; do not regenerate the older
temporary draft creator over the added real experiment cells.

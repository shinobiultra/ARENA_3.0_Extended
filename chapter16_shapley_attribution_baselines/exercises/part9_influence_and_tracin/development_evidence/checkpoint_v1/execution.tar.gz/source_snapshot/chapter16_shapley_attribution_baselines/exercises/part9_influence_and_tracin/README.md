# 16.9 Influence Functions and TracIn — development

The mathematical foundation is implemented in `lesson.md`: ten exercise groups,
twelve visible student functions, thirteen immediate check calls, six controlled
figures and one editable learning-rate/query experiment. This is not a published
complete section. Influence, TracIn and GhostSuite requirements remain open until
the native learner and its independent validation are complete.

The implementation covers per-example logistic losses/gradients, weighted
objectives, dense curvature and Hessian-vector products, checked conjugate
gradients, independent Newton refits, signed upweight influence, recorded SGD,
exact and Taylor path accounting, checkpoint scores and affine gradient products.
The extra class-matched deletion helper is tested but not yet a learner exercise.

`native_protocol.md` fixes the next real-data experiment before any digit-model
fit. `attribution_data.py` checks pinned UCI source bytes and constructs the exact
selection in `data_manifest.json`: 128 training, 48 ranking and 64 final images,
with the original source train/test writer split. Clean and 12/128 deliberately
flipped training-label conditions are retained. Final model evaluation has not
occurred. Dataset credit, license, preprocessing and row provenance are explicit.

Run the mathematical/data checks from the repository root:

```bash
OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 uv run python -m pytest \
  chapter16_shapley_attribution_baselines/exercises/part9_influence_and_tracin/attribution_methods_tests.py \
  chapter16_shapley_attribution_baselines/exercises/part9_influence_and_tracin/attribution_data_tests.py -q
```

Execute the draft from its own answers into a new directory:

```bash
uv run python chapter16_shapley_attribution_baselines/exercises/part9_influence_and_tracin/execute_learner.py \
  --output-directory /tmp/arena16_9_own_answers
```

The executor currently records `scope=foundation_only` and
`native_model_executed=false`. Do not interpret the real-image cold open as
native-model attribution evidence. It records all eight source inputs and
checks that they remain unchanged during execution.

Continue with `docs/arena_salvage/2026-09-06_data_attribution_next_plan.md` at the
repository root. Keep the original chapters and the released 16.7 lesson intact.

# Independent GradientSHAP implementation and execution-evidence review

Date: 2026-09-07 JST  
Reviewer task: `/root/gradient_review`  
Disposition: **APPROVE the first full standalone CPU native execution at the exact source hashes below.**

No unresolved scientific, API, preparation-boundary, persistence, or fresh-reproduction blocker remains in the reviewed candidate. This is source-level approval to run. It is not evidence that the seven fits reproduce the 21 frozen state hashes or that the numerical study passes; those claims require the first native run and its independently fresh reproduction.

## Exact reviewed source identity

Frozen inputs:

- `protocol.md`: `4ed1d1d45a0b5db304cb45e7c5abe1c85c97434e53b4c9c156ce05b2b489a83b`
- `data_manifest.json`: `bcf41f96c9f6839ee4cbf24df82ca8467b35a6ed9090a9c4c56fce0b1a23120c`
- `gradientshap_data.py`: `9c9c1016ffd6fe839a004c06e801cdcd24d4d71a85ccd3f0707168dec390c7ce`
- `protocol_freeze.json`: `79fc20a6b600cc17b9e942927d44ac135e192538e124fcf7b7889407940afcf5`

Scientific implementation and tests:

- `gradientshap_methods.py`: `2c56ae4e108d13b8e2994f12944af49af3915fcf95d684da96ddec7ed46c5be5`
- `gradientshap_methods_tests.py`: `563ecc09204108aaf6d1e5dfc0e3609a297dbc76a2e7e1352e83944b98d66c7f`
- `gradientshap_study.py`: `f49e4f5872beca780c95a3689b919690e5be8c344df3f0625178476ff163ad02`
- `gradientshap_study_tests.py`: `ef938b660a7b6388023654bd977cfd94e999540ee6d827ead6f5382f757eb3a5`
- `gradientshap_reference.py`: `c063d120d7449a9b20b4ac370247b2b5971e809575d44ab9d7c8719cc551292f`
- `gradientshap_reference_tests.py`: `95bfe943a98b7353e29328992ee4cbf0a0558cdf3c8d64a692129e47bf1dbc4e`
- `gradientshap_diagnostics.py`: `d3b60c3d5e9565a3c693fa4d8146a8115eae1ac1708986692197dadfdbee5e7f`
- `gradientshap_diagnostics_tests.py`: `420c535748a2dedb4a1e6a3d3e4c99e4cb0ace78d51af01e1141d136b153b029`
- `gradientshap_plots.py`: `f6c85a3a9fc915d85f8658945c29e5afe6f9bf5838b15e57cd6f44ad4fd551df`
- `gradientshap_plots_tests.py`: `8fd3ebb8535d0b0104ceef388a3ccdb39a2180fdbd4fc1bdd5260ce8c30b3287`

Execution and publication boundary:

- `run_native.py`: `f4c359e12c25d77b14100da9e66145480fe0dfa591f9387cf1fe1d8c938f205c`
- `execute_learner.py`: `0dfd6ee46e87b0091466c47d6a61e6b451ccdf34758e6a68399ac9f7b42cbc38`
- `reproduce_native.py`: `382d67ea67ecd6c02d0c1148dbb812c567e6635f706c351f02f85f9cb7d367db`
- `publish_study.py`: `c8039ec512cd5ac77c042c89e11cce39c67ae5223743e04945be7d7be2d5b22a`
- `gradientshap_contracts.py`: `9af2bb9be8a226e2c35dd895f9d3187bbea7a722c185d968e4fdcde0da253058`
- `build_notebooks.py`: `c1a7a347d3302dcdd556dc381db91f1a61e33b407df5882b17b595dd8d6f42c0`
- `lesson.md`: `ad00edf9ca76f6896ec589c6e069023437d3b0014b7fc1cc703a6180798e68c0`

Any change to a reviewed hash invalidates this launch approval until rechecked. The runner's own source snapshot and end-of-run changed-source gate must remain active for the entire native execution.

## Scientific and API findings

- **Exact 16.14 reproduction gate:** the study reconstructs seven ordered predictors and checks the named `initial_state`, `standardized_state`, and `raw_folded_state` hashes for each model, giving 21 exact state identities. It also checks train IDs, train-only normalization, recipe constants, shuffled-target permutations, retained raw targets, loss-trace lengths, raw-model training predictions, and folding parity. The runner attaches the returned expected-versus-observed comparison and known-16.14 provenance to `fitted.pt` before persistence. Attribution cannot start past the gate if any mismatch is present.
- **Raw-unit folding:** the first-layer transform divides weights by train-only input standard deviations and shifts the bias by the standardized mean; the final layer applies target standard deviation and mean. The ridge fold uses the corresponding affine transform. The fixed-state semantic tests confirm raw prediction parity without mutating the standardized state.
- **Audit boundary:** `fit_models(train)`, the 21-state verification, `prepare_study(fitted, train, explain, ...)`, `fitted.pt`/`prepared.pt` persistence, recursive manifests, and `before_audit.json` all precede the literal `load_split("audit")`. Rankings, backgrounds, primary schedules, random orders, and explanation identities are sealed before audit values enter evaluation. Boundary hashes are checked again before completed artifacts are saved.
- **Source-ID and RNG schedules:** primary donor/alpha streams use the frozen per-source SHA256 first-16-byte little-endian rule and literal `baseline`/`alpha` tags. Noise uses `standard_normal` and seed 161512. All 64 replicate seeds match the manifest's first-eight-byte little-endian derivation and enter the unchanged student schedule API. Replicate schedules have shape `[64,64,2048]`, are shared across the three declared models, and retain exact 32-explanation/32-audit source order plus an explicit int64 split vector and labels.
- **Monte Carlo and quadrature scope:** every nested estimate uses literal prefixes `[8,32,128,512,2048]`. Ordinary coordinate SE is `std(correction=1)/sqrt(K)`. Q256 and Q512 retain donor-wise arrays, means, and doubling drift and remain labeled approximate numerical controls for ReLU paths. Q512 is not used as an exact or acceptance oracle.
- **Exact finite replacement game:** each comparison block retains `hybrid_prediction[N,256,B]`; donor averaging reconstructs the declared finite coalition table exactly before exhaustive feature Shapley. The primary seven-model blocks and all five clean-0 background blocks retain the full hybrids, coalition values, exact finite-game Shapley, DeepSHAP donor contributions, and endpoint-gradient controls.
- **Noise target:** sigma zero aliases the clean primary contribution tensor. Positive sigmas reuse one frozen standard-normal schedule and the clean donor/alpha schedule, perturb both path endpoint and query-minus-donor delta, retain every contribution and noisy prediction, and report residuals against both the clean prediction target and finite smoothed-prediction target. The latter retains the ordinary SE of its Monte Carlo prediction mean.
- **Sampling replicates:** the in-memory contribution tensor has exact float64 shape `[64,3,64,2048,8]`, or 201,326,592 coordinates and 1,610,612,736 raw bytes (1.5 GiB). Donor indices and alphas are retained separately with combined 128 MiB raw size. Prefix means, ordinary SE, Q512 errors, descriptive 95% coverage indicators, and coverage rates are all retained.
- **Rankings and controls:** the five global orders are stable mean-absolute rankings computed only on explanation rows. Evaluation applies them to all audit rows. The full 100 seeded random orders, masks, and raw insertion/deletion curves are retained for every model and audit row. Distance evidence retains all declared source/donor/mask/alpha identities.
- **Package references:** the pinned SHAP 0.49.1 and Captum 0.9.0 source bytes were checked locally. SHAP's row-major donor/alpha and Torch-smoothing order and Captum's all-donor, Torch-noise, all-alpha order are reconstructed separately. Each model gets one complete 272-row K128 call per package with the frozen resets. Full package draws, author vectors, student replay contributions, ordinary SE, SHAP variance proxy, and Captum repeated convergence deltas are retained under distinct labels. Success and exception tests cover restoration of RNG, default dtype, model modes, parameters, buffers, and existing gradient identity.

## Persistence and reproduction findings

- `replicate_samples.pt` is written directly from the complete tensor. `evaluated.pt` replaces only `sampling_replicates.samples` with an external descriptor containing logical shape, dtype, element count, value SHA256, artifact SHA256, serialized size, manifest name, and logical payload path.
- Recursive manifests bind ordered structure, scalar values, and every array's type, shape, dtype, element count, and full value SHA256. File hashes stream in 64 MiB chunks. Fresh validation reads the external tensor back, recomputes its logical value identity, compares it with the external manifest, and requires the descriptor inside `evaluated.pt` to match exactly.
- Fresh reproduction starts `run_native.py` in a distinct CPU child process with CUDA hidden and four CPU-thread environment limits. It consumes no learner model payload, refits all seven predictors, validates both artifact directories, and compares every deterministic manifest identity exactly. Timing values remain a separate descriptive branch.
- Publication archives inline payloads at or below the bounded threshold and may leave larger payload bytes at hash-bound absolute persistent paths. All payload manifests remain archived; archive members are read back and byte-verified.

## Verification performed without native fitting

- `uv run python -m py_compile` passed for study, reference, native runner, learner executor, fresh reproducer, and publisher.
- The combined methods, diagnostics, study, reference, plots, and contract suite passed: **45 passed, 1 skipped**. The skipped test is the explicit post-freeze Concrete native-fit test guarded by `ARENA_GRADIENTSHAP_RUN_NATIVE_FIT=1`. Three warnings were unrelated SHAP/Matplotlib pending deprecations.
- `uv run python build_notebooks.py --check` passed: **126 cells, 9 exercises**.
- `git diff --check` passed for the reviewed GradientSHAP paths.
- Immediately before approval, no `run_native.py`, `execute_learner.py`, or `reproduce_native.py` process was present. This review inspected no native 16.15 numerical outcome.

## Remaining execution obligations

The approved first run must preserve the source hashes above, use `CUDA_VISIBLE_DEVICES=''` and the declared CPU environment, save the preparation boundary before the literal audit load, and retain any failure evidence rather than rerunning silently. A successful first run still requires independent fresh reproduction, artifact/read-back validation, visible learner execution, and browser review before publication or completion claims.

Original ARENA chapters 0-4 and completed section 16.14 were not edited by this reviewer. This review wrote only this cache file and supersedes no prior protocol review.

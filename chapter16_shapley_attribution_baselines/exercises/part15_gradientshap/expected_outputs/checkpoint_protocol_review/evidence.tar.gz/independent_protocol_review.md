# Independent pre-fit review: Expected Gradients / GradientSHAP 16.15

Review date: 2026-09-07 (Asia/Tokyo)

Reviewer scope: scientific and API review only. No Concrete fit, native
attribution, registry promotion, or canonical-file edit was performed by this
reviewer.

## Decision

**Final decision: APPROVED for the matching zero-native-run protocol freeze.**
The original pre-freeze draft was not safe to freeze unchanged. The September 7
revision resolves every freeze blocker identified below without changing the
scientific question. No native fit or attribution may start until the freeze
record binds these exact current files:

- `protocol.md`: `4ed1d1d45a0b5db304cb45e7c5abe1c85c97434e53b4c9c156ce05b2b489a83b`
- `data_manifest.json`: `bcf41f96c9f6839ee4cbf24df82ca8467b35a6ed9090a9c4c56fce0b1a23120c`
- `gradientshap_data.py`: `9c9c1016ffd6fe839a004c06e801cdcd24d4d71a85ccd3f0707168dec390c7ce`

The manifest correctly says the reviewed choices remain pending until that
matching freeze exists. A filesystem search found no 16.15
`protocol_freeze.json`, fitted/prepared/evaluated/reference payload,
`replicate_samples.pt`, `before_audit.json`, or `artifact_manifest.json` at final
review time.

The scientific question, estimator, controls, data boundary, ranking boundary,
sample budgets, quadrature framing, package-parity tolerance, and revised
storage contract are acceptable.

The reviewed original identities were:

- `protocol.md`: `dcc780deb98e5631f7268432fa5d162357883f73a70bc8b877b961d4be20d494`
- `data_manifest.json`: `0102efd409e98a68197aa8ec5b478251816c00c07841bea71ea448569985464b`
- `gradientshap_data.py`: `9c9c1016ffd6fe839a004c06e801cdcd24d4d71a85ccd3f0707168dec390c7ce`
- `gradientshap_methods.py`: `2c56ae4e108d13b8e2994f12944af49af3915fcf95d684da96ddec7ed46c5be5`
- `gradientshap_methods_tests.py`: `bd63764bac931b1076a6d4d03efcd029e26ecb9065af0a7ad320e09255ce4674`
- cache `study_api_draft.py`: `2774480663c83b83770c5a87c524ea9c87ecd843c257bf9ffea2080e3f35075c`

The original cache API is preserved byte-for-byte as
`study_api_draft_prefreeze_20260906.py` at that last hash. The current cache
`study_api_draft.py` is SHA256
`6ae292ec462805e45640721246e31f1946d8cc25760c97093eeac9a2d03f00a2`
and is explicitly marked superseded; it names the revised hybrid-prediction,
shared-schedule, external-sample contract and directs implementation to the
canonical protocol, manifest and live study module. Its old function docstrings
are historical sketch text and are not freeze authority.

## Final resolution audit

The revised files now specify all previously missing deterministic choices:

- NumPy `1.26.4`, first 16 SHA256 digest bytes interpreted little-endian, and
  literal `baseline`, `alpha`, and `standard_normal` tags;
- 64 manifest-recorded uint64 replicate seeds derived from the first eight
  digest bytes of the exact `.../161511/replicate/{r}` strings;
- SHAP NumPy seed 161513, Captum NumPy seed 161514, and separately reset SHAP
  and Captum Torch smoothing streams at 161515;
- one full 272-row author call per model and package, SHAP batch size 128, and
  one package-specific draw table reused across all seven models;
- exact same-draw tolerance `atol=rtol=1e-10` after identity hashes;
- mechanical manifest load before 21-state verification and attribution;
- `hybrid_prediction[N,256,B]` in every exact-game comparison block;
- shared replicate schedules `[64,64,2048]`, external samples
  `[64,3,64,2048,8]`, and a shallow persisted external reference;
- seven deterministic payloads, recursive value manifests, file hashes and
  actual serialized sizes, with timing kept outside reproduction evidence.

All 64 recorded replicate seeds recomputed exactly from the declared rule, were
distinct, and lay in the public student sampler's uint64 domain. The current
method test uses exact equality for the alpha schedule fixture and describes
the SE as the square root of the unbiased variance estimate divided by
`sqrt(K)`. Row independence and supported state-preservation promises are now
stated as narrow study contracts rather than generic claims the output shape
could prove.

There are no remaining scientific or protocol blockers to the zero-run freeze.
The live study/evaluation/reference modules, strict learner build, native
execution, independent reproduction, browser review, publication, and registry
promotion remain later gates. Approval here does not approve or assert any of
those outcomes.

## Freeze blockers in the reviewed draft

1. **The RNG byte rule is ambiguous.** The protocol says “low 128 bits” of a
   SHA256 digest interpreted little-endian, while the implementation uses
   `digest()[:16]`. Freeze the literal rule as the first 16 digest bytes,
   interpreted unsigned little-endian. Freeze the exact stream-tag strings and
   NumPy version. `Generator` distribution transforms are part of the byte
   schedule, not only PCG64 state.

2. **Replicate and noise schedules are not expressible uniquely through the
   draft API.** `sample_path_schedule` hard-codes `baseline` and `alpha` tags and
   has no replicate-tag argument, while the protocol says the replicate number
   appears in a tag. The standard-normal tag is unnamed. A safe resolution is:
   derive and record 64 uint64 replicate seeds using an exact digest rule, then
   call the existing student sampler; define the exact noise tag as
   `standard_normal`. Add explicit study helpers/contracts for both.

3. **SHAP's positive-noise Torch stream is not assigned.** SHAP 0.49.1 consumes
   Torch RNG for local smoothing independently of its NumPy `rseed`. The table
   assigns a SHAP author seed and a Captum Torch seed, but no SHAP Torch seed.
   Also freeze call granularity: SHAP `batch_size=128`, one complete 272-query
   call per model with the NumPy stream reset per model; Captum one complete
   272-query call per model with both NumPy and Torch streams reset per model.
   This gives one package-specific draw table reused across seven models.

4. **The manifest cannot reach the preparation calls in the API.**
   `prepare_study` promises output from `verify_16_14_reproduction`, and
   `_background_indices` requires the manifest, but `prepare_study` has no
   manifest parameter. Freeze an explicit mechanical manifest load inside
   preparation/background construction, or pass the manifest explicitly. The
   runner must execute all 21 hash checks before any attribution.

5. **Required exact-game evidence is absent from the API payload.** The protocol
   retains every donor-level coalition hybrid prediction, but
   `_comparison_baselines` only returns donor-averaged `coalition_values`.
   Include `hybrid_prediction[N,256,B]` in the primary seven-model blocks and
   every clean_0 background-comparison block.

6. **Replicate schedule shape and storage ownership are contradictory.** Draw
   schedules are shared across the three models. They must be shaped
   `[64,64,2048]`, not carry a model dimension. Contributions are
   `[64,3,64,2048,8]`. The draft statement “sharded by
   replicate/model/split” conflicts with a proposed single retained tensor and
   risks silent duplication through `evaluated.pt`.

## Exact replicate storage resolution

The contribution count is correct:

```text
64 replicates * 3 models * 64 rows * 2048 draws * 8 features
= 201,326,592 float64 coordinates
```

The raw contribution tensor is therefore exactly:

```text
201,326,592 * 8 bytes
= 1,610,612,736 bytes
= 1,536 MiB
= 1.5 GiB
```

Schedules are model-independent. One shared donor-index tensor and one shared
alpha tensor, each `[64,64,2048]`, are exactly 64 MiB apiece. The contribution
tensor plus these two schedule tensors is exactly 1.625 GiB before summaries and
serialization overhead.

Approved storage contract in principle:

- one external contiguous float64 `replicate_samples.pt` tensor with shape
  `[64,3,64,2048,8]`;
- shared int64 donors and float64 alphas with shape `[64,64,2048]`, stored once;
- `evaluated.pt` contains only a shallow external descriptor, never the sample
  tensor itself;
- the descriptor records relative path, shape, dtype, logical value SHA256,
  serialized file SHA256, and actual serialized byte count;
- exact fresh reproduction compares schedule/value hashes and tensor leaves
  without creating another copy inside a summary payload.

The serialized `.pt` file is expected to be slightly larger than 1.5 GiB. Only
the raw tensor payload is exactly 1.5 GiB; record the actual file size after
serialization rather than predeclaring it.

## Scientific review

### Expected-Gradients target and finite Monte Carlo error

The estimator matches Erion et al. Methods 2: draw a baseline from the declared
data distribution, draw alpha uniformly on `[0,1]`, evaluate gradient times the
query-minus-baseline displacement, and average. Under the stated path
regularity, the population sum is `f(x) - mean_b f(b)`. A finite sample vector
need not be complete. Gaussian query noise correctly changes the population
target to `E_noise[f(x+noise)] - mean_b f(b)` when the perturbed query is used
in both interpolation and displacement.

The implemented coordinatewise formula
`samples.std(correction=1) / sqrt(K)` is the ordinary Bessel-corrected plug-in
Monte Carlo SE for IID donor/alpha draws. It is suitable here. Do not call the
sample standard deviation or the resulting SE unbiased: `s^2` is unbiased for
the variance, whereas `s` and `s/sqrt(K)` are generally not unbiased. The lesson
main text already uses the defensible wording, but the method-test message and
the saved next plan need correction.

Intervals `estimate +/- 1.96*SE` are acceptable only as the declared descriptive
coverage diagnostic. The protocol correctly discloses shared-row/coordinate
dependence and that q512 is an approximate target. No inferential independence
or exact 95% coverage claim should be added later.

### Quadrature

All-background 256- and 512-node Gauss-Legendre integration is an appropriate
deterministic control. ReLU path gradients are step-discontinuous, so finite
Gauss-Legendre rules are not exact merely because the network is piecewise
linear. Keeping both pair arrays and their pointwise drift, without an
acceptance gate, is scientifically sound. The affine and quadratic tests verify
polynomial cases; the threshold test demonstrates finite-rule error at a kink.

### Same-draw package references

The cached SHAP 0.49.1 and Captum 0.9.0 sources confirm different random-call
orders. Equal seeds across packages do not imply equal donors, alphas, or noise.
The design should compare each author result against a replay of that exact
package draw table, with schedule hashes checked before numeric comparison.

The proposed same-draw learner/reference tolerance `atol=rtol=1e-10` is
approved. Full untrained coverage measured a maximum vectorized SHAP difference
of `8.326672684688674e-17`, with literal SHAP and Captum replays bitwise exact.
Keep bitwise literal replay as a diagnostic and the `1e-10` gate for portable
real-model vectorization. SHAP's `variance/sqrt(K)` field and Captum's per-draw
convergence deltas must remain separately named and outside this parity gate.

### Data and ranking boundary

The pinned 41,472-byte CSV hash, finite `(1030,9)` shape, and first-seven-input
recipe grouping were independently checked from the existing cached source.
There are 427 recipe groups. The manifest gives 298/64/65 disjoint groups and
758/153/119 train/explanation/audit rows, with all 1,030 source IDs covered once.

The complete query order equals explanation IDs followed by audit IDs. The
replicate subsets are exactly the first 32 IDs from each held-out split. The OOD
query order equals the complete held-out order, and its eight donors are the
first eight primary donors. All five background source-ID orders reproduce the
declared SHA256 order, and nested16/primary64 are literal prefixes of nested128.

Learning each model/method global order from mean absolute attribution on all
153 explanation rows, persisting it before literal audit load, and applying it
unchanged to 119 audit rows is an acceptable boundary. The default audit source
ID 1 and random-order seed 161480 are predeclared. Audit results must not later
change model, row, budget, sigma, tolerance, axes, or example selection.

## Method/API follow-ups identified in the original draft (resolved)

- Row independence is now a declared caller/runner precondition for the
  supported Sequential and ridge graphs. The protocol no longer says output
  shape proves this property.
- The lesson now limits state preservation to the state actually preserved and
  states that the supported forward graphs do not mutate parameter values.
- The alpha schedule fixture now uses byte-exact equality, and its expected
  values match under NumPy 1.26.4.

## Checks executed

- `CUDA_VISIBLE_DEVICES='' uv run python -m pytest -q .../gradientshap_methods_tests.py`
  -> 9 passed.
- `CUDA_VISIBLE_DEVICES='' uv run python -m pytest -q .../reference_recon/test_gradientshap_probe.py`
  -> 9 passed; three plotting-package deprecation warnings only.
- `build_notebooks.py --checkpoint-check` -> 9 AST-matched answers across 88
  cells; strict generation remains intentionally blocked by unresolved study,
  reference, execution, figure, and play groups.
- Manifest structural, source-byte, grouping, background-order, subset, and OOD
  count checks -> passed.

These checks do not constitute a native run or course publication.

## Freeze criterion result

The revised protocol and manifest passed the exact replicate-seed derivation,
schedule fixture, manifest structural, shape/byte, method, reference-probe, and
cross-document checks. The zero-run freeze may now bind the three exact current
hashes at the top of this report plus the declared
Python/NumPy/Torch/SHAP/Captum environment. After that record exists, the
canonical CPU implementation and known-model reproduction may proceed. Native
attribution must still wait for exact 21-state hash parity.

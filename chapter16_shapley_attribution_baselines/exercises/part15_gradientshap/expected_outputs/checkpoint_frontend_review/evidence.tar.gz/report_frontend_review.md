# Independent GradientSHAP report-frontend and evidence-audit review

Date: 2026-09-07 JST
Disposition: **BLOCK publication pending three report-contract fixes.** The first successful own-answer execution is scientifically usable and source-stable; these findings concern how the later verification report represents and audits that evidence. No native fit or attribution was launched by this reviewer, and no canonical file was edited.

## Reviewed bytes

- `part15_gradientshap/solutions.py`: `45aa250c0b545118697c9708eca23c26fbb274e1fafe2215492bdfe32862ee47`
- `part15_gradientshap/tests.py`: `a6525e5184bfb8a9cb6117b8d447c1feaab2343af9a73c00f41052dd19e4fe84`
- `part15_gradientshap/artifacts.lock.yml`: `756bff3ab023308a1ca2bf21f52862794a93e0ed5928f1a0b61463e2cb823239`
- `part15_gradientshap/verification_report.schema.json`: `e699cdabe26add35001a00f2ca5be45bd9e0e1bee86e3c6b5df2f35bf5b62d49`
- `part15_gradientshap/author_reference.json`: `25166e7c9c1800fcd1da6d0ff11759b847aed53fdee40f0a7847c0cf821f4fad`
- `scripts/audit_report_evidence_contracts.py`: `3fb6ae4f928495317ee529cd807c789b12e4739ffb5bb74583ca8b8ced931214`
- `tests/test_report_evidence_contract_audit.py`: `1f5bfc20cd6e59a65a99e4f9baf77e82161bfa4f8ff04016e3623450f0fc2b70`

## Publication blockers

### 1. Original and fresh fit counts are both read from the fresh fitted payload

`solutions.py:114-116` returns both `model_fits` and `fresh_model_fits` as `len(models)`, where `models` was loaded only from `output/fresh_run/fitted.pt`. This reports one count twice. The original own-answer learner count is independently available as `execution["native_summary"]["model_fits"]`; the fresh count can remain derived from the newly loaded fitted payload. `solutions.py:225` similarly hard-codes `native_model_retrained_in_this_report=True` instead of computing it from the just-produced PASS reproduction record and its fresh native execution.

This does not invalidate the v2 payload, because `publish_study.validate_fresh` separately validates the original learner summary and the fresh run. It does make the report fields weaker than their names and the audit contract imply.

Required resolution: source `model_fits` from the original execution/native summary, source `fresh_model_fits` from the fresh fitted payload (or fresh run summary), and derive the report-time retraining boolean from the reproduction result. Add a test in which original and fresh counts differ so the two routes cannot collapse silently.

### 2. Author-package coverage is copied from declared counters rather than retained arrays

`solutions.py:153-168` copies `author_samples_per_package`, model-row/vector/coordinate totals, and pass booleans from `reference["counts"]` / `reference["passes"]`. It does not recompute coverage from `packages.{shap,captum}.models.*.author_phi`, `student_phi`, `student_contributions`, and the retained package draw tables. A direct adversarial check changed `reference["counts"]["model_rows"]` to 1 and `package_coordinates` to 8 while leaving a retained `author_phi` with shape `(272, 8)`; `_reference_metrics` reported 1 and 8.

The successful v2 payload itself is complete: each package has seven models, every `author_phi` is `(272,8)`, every `student_contributions` array is `(272,128,8)`, and the live derived totals are 1,904 vectors / 15,232 coordinates per package, K=128, 3,808 vectors / 30,464 coordinates total. SHAP's maximum same-draw error is `5.684341886080802e-14`; Captum's is `0.0`.

Required resolution: derive the report coverage counts and K from the retained package arrays/draw tables; require every model key and array shape; compare the derived values to any payload counters rather than treating counters as evidence. Derive the combined pass from the per-model parity data and the positive-noise retained result, keeping the frozen `1e-10`/`1e-10` tolerances unchanged.

### 3. JSON schema and scope audit disagree, and the audit accepts bogus evidence links and impossible same-draw errors

The GradientSHAP `gpu_test.required` list in `verification_report.schema.json` omits fields that `_has_gradientshap_evidence` / `has_native_cpu_model_evidence` rely on: at least `device`, `own_answer_code_cells`, `learner_evidence_sha256`, `fresh_evidence_sha256`, `replicate_sample_sha256`, `replicate_file_sha256`, `author_shap_max_error`, and `author_captum_max_error`. Thus schema validation alone accepts a report that cannot satisfy the evidence audit.

More seriously, the audit only applies `bool(...)` to the learner/fresh evidence strings and accepts each author max error anywhere in `[0,+inf)`. The following mutation of the audit's own nominal GradientSHAP fixture still returned `True` from `has_native_cpu_model_evidence`: learner hash `"x"`, fresh hash `"y"`, SHAP max error `1000.0`, Captum max error `1000.0`. This contradicts the claimed bound publication evidence and same-draw PASS semantics. The existing tests mutate empty hashes and several scope counts but do not cover non-hex/mismatched evidence digests or unacceptable package errors.

Required resolution: align the schema-required properties with every field used by the GradientSHAP audit; require canonical 64-hex hashes; cross-check learner/fresh evidence digests against their exact `report_inputs.files` entries; and make package parity status/error internally consistent with the frozen tolerance (or report and audit explicit per-package/per-model pass evidence derived from arrays). Add adversarial tests for nonempty non-hash strings, hashes that do not match report inputs, and large same-draw errors with a forged PASS flag.

## Checks that passed review

- The lock's scientific scope is accurate: finite Monte Carlo SE and approximate quadrature outcomes remain descriptive rather than acceptance gates; Expected Gradients is not labeled exact finite feature Shapley; positive noise changes the prediction target; and the study does not claim whole-paper replication or physical causality.
- The known-16.14 wording is appropriately narrow: it says the seven seeded predictors are reproduced by exact 21-state checks, not independently replicated models. The successful v2 `fitted.pt` was created only after that gate passed.
- The `1e-10` same-draw SHAP/Captum tolerances are unchanged in the lock, schema, source, and successful payload.
- `gradientshap_*` is enforced as the published figure namespace, and `run_gpu_test` verifies the published exercise notebook, solution notebook, page, and all 20 figure hashes.
- The general report input manifest includes the frontend, lock/schema, author-reference record, frozen protocol/manifest, scientific and test sources, published notebooks/page/figures, and expected learner/fresh evidence. `validate_fresh` independently verifies the learner and reproduction source snapshots.
- Fresh reproduction is in a distinct CPU subprocess in the exact bound `reproduce_native.py` source, consumes no learner model payload, reloads source data, refits seven models, and exactly compares every deterministic artifact manifest. The external replicate descriptor is live-validated against `replicate_samples.pt`, including shape, dtype, elements, value SHA, file SHA, and file size.
- `author_reference.json` matches the package versions and pinned installed/cached source hashes embedded in the reference implementation.

## Execution evidence checked

The preserved v1 attempt failed before fitting because a negative dtype fixture inherited the notebook's float64 default; it recorded `native_model_executed=false` and no source changes. That is failure evidence, not a scientific run.

The v2 own-answer execution at `/home/bitwise/.cache/arena_extended/gradientshap/native-dev-v2` passed in 64.3529 seconds with 126 cells, 79 code cells, 20 figures, `native_model_executed=true`, and no changed sources. Its external replicate artifact is 1,610,614,447 bytes with file SHA `46238cad0348f56be4807507256233884af3588037a434197f0cbe0f0aa1a0fa` and value SHA `521ce9f2e1f23c239e6863166333fb0a3f5f52dbec980a4a527118cee7391c6f`.

## Verification run

`CUDA_VISIBLE_DEVICES='' uv run pytest -q tests/test_report_evidence_contract_audit.py`

Result: `17 passed in 4.01s`. The green suite does not cover the three adversarial cases above.

# Independent GradientSHAP publication-frontend recheck

Date: 2026-09-07 JST
Disposition: **PASS — no remaining blocker in the three previously reported frontend findings.** This approval is bound to the hashes below. It authorizes the parent to proceed with publication/report integration; it does not claim that the normal registered verification report has already executed.

No canonical file was edited and no fit, attribution, or reproduction was launched by this reviewer.

## Reviewed bytes

- `part15_gradientshap/solutions.py`: `29471f5b57fa41cff1e4db5fe08b5c5f0f22ae20cf71f06a0e2c2323e4a2edc1`
- `part15_gradientshap/verification_report.schema.json`: `13a8cafd5eac78abef5f3848b0d6cfb89173d0accde67388cc171e66c3d231bd`
- `part15_gradientshap/artifacts.lock.yml`: `30ee42fddca2053003270cdb7fd25d0a331b3d8f38f372c25c52b7c7656ac877`
- `scripts/audit_report_evidence_contracts.py`: `904cca4954d32c7ea1fc5d553d3501834023f1aa050ea64c035ead923f519c13`
- `tests/test_report_evidence_contract_audit.py`: `3bf0e5b77d41acbda76e8d0916f1511d685351cba270c28f9a484382ffc1529b`

## Resolution of the three prior findings

1. **Original/fresh fit separation: resolved.** `run_gpu_test` loads the original learner `fitted.pt` from the already validated learner native directory and loads the fresh `fitted.pt` from the newly created report reproduction. It cross-checks the original retained model count against the learner's native summary. `_study_metrics` still derives `fresh_model_fits` from the fresh payload; the final returned `model_fits` is overwritten with the independently loaded original count. `native_model_retrained_in_this_report` is now derived from the fresh reproduction's retraining flag, explicit no-cache flag, and fresh child summary rather than a literal `True`.

2. **Actual retained-array reference coverage: resolved.** `_reference_metrics` requires both exact package namespaces and all seven frozen model keys. For every model it checks retained `author_phi` shape `(272,8)`, contribution shape `(272,128,8)`, recomputes the student vector as the contribution mean, and applies the frozen same-draw `atol=rtol=1e-10` coordinatewise. Row, coordinate, vector, and K counts are derived from these arrays. Declared `reference["counts"]` no longer supplies report coverage. Positive-noise references are rechecked and must contain actual nonzero noise.

   A direct adversarial check changed the payload's declared counts to `1/2/8/K=1`; the helper still returned the array-derived `1904/3808/30464/K=128`. Changing one retained contribution tensor from K=128 to K=127 raised `ValueError`.

3. **Normalized tolerance and evidence-hash binding: resolved.** The report schema now requires and constrains CPU device, own-answer count, learner/fresh evidence hashes, external value/file hashes, raw package errors, normalized errors, and tolerance bounds. The audit requires canonical lowercase 64-hex external hashes, scaled same-draw errors in `[0,1]`, and raw maximum errors no larger than their retained-vector tolerance bounds. Learner and fresh evidence digests must match exactly one corresponding `report_inputs.files` entry. The focused adversarial checks rejected a mismatched 64-hex learner digest, a non-hex fresh digest, a Captum max error of 1000, and a scaled SHAP error above 1.

## Live v3 payload check

The current helpers read the retained v3 payloads under `/home/bitwise/.cache/arena_extended/gradientshap/native-dev-v3/figures/native` successfully. Observed report inputs include:

- seven fresh model fits and 21 matching known model-state hashes;
- 31,195,136 primary sample coordinates and 31,195,136 retained primary hybrid predictions;
- 201,326,592 external replicate coordinates, file size 1,610,614,447 bytes;
- external value SHA `521ce9f2e1f23c239e6863166333fb0a3f5f52dbec980a4a527118cee7391c6f` and file SHA `46238cad0348f56be4807507256233884af3588037a434197f0cbe0f0aa1a0fa`;
- K=128, 1,904 vectors per author package, 3,808 vectors / 30,464 coordinates total;
- SHAP raw maximum error `5.684341886080802e-14`, scaled error `2.4656243484239792e-05`, tolerance bound `1.0348778525810984e-08`;
- Captum raw/scaled maximum error zero, tolerance bound `9.125330882294669e-09`;
- frozen report tolerances remain `atol=rtol=1e-10`.

The prior scientific-scope decisions remain intact: Monte Carlo and quadrature discrepancies are descriptive, Expected Gradients is not relabeled exact finite feature Shapley, positive noise changes the target, and the 16.14 relationship remains reproduction of known seeded predictors rather than independent replication.

## Verification

- `CUDA_VISIBLE_DEVICES='' OMP_NUM_THREADS=4 MKL_NUM_THREADS=4 OPENBLAS_NUM_THREADS=4 uv run pytest -q tests/test_report_evidence_contract_audit.py` — `17 passed in 4.32s`.
- `uv run python -m py_compile` on `solutions.py`, the audit, and its tests — passed.
- Focused adversarial hash/tolerance checks — all four invalid cases rejected.
- Direct v3 `_study_metrics` and `_reference_metrics` evaluation — passed.
- `git diff --check` for the five reviewed files — passed.

Original ARENA chapters 0–4 and completed 16.14 were not touched by this review.

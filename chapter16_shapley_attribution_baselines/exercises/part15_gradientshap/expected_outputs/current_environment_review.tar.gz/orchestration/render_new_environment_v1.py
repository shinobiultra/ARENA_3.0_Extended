from pathlib import Path
import copy
import hashlib
import json
import sys
import nbformat
from nbconvert import HTMLExporter

ROOT = Path('/home/bitwise/Documents/ARENA_3.0_Extended')
sys.path.insert(0, str(ROOT))
from chapter16_shapley_attribution_baselines.exercises.part15_gradientshap.build_notebooks import build_notebooks, STEM
from chapter16_shapley_attribution_baselines.exercises.part15_gradientshap.execute_learner import digest

learner = Path('/home/bitwise/.cache/arena_extended/gradientshap/new-environment-learner-v1')
old = learner.parent / 'native-dev-v3'
execution = json.loads((learner / 'execution.json').read_text())
assert execution['status'] == 'PASS'
for name, checksum in execution['source_inputs'].items():
    assert digest(ROOT / name) == checksum == digest(learner / 'source_snapshot' / name)
student, solved = build_notebooks()
actual = nbformat.read(learner / 'completed_learner.ipynb', as_version=4)
assert [(c.cell_type, c.source) for c in actual.cells] == [(c['cell_type'], ''.join(c['source'])) for c in solved['cells']]
for cell, executed in zip(student['cells'], actual.cells, strict=True):
    if cell['cell_type'] == 'code' and 'raise NotImplementedError' not in ''.join(cell['source']):
        assert ''.join(cell['source']) == executed.source
        cell['outputs'] = copy.deepcopy(executed.outputs)
        cell['execution_count'] = executed.execution_count
directory = learner / 'html_review'
directory.mkdir(exist_ok=False)
html_hashes = {}
for name, notebook in [('exercises', nbformat.reads(json.dumps(student), as_version=4)), ('solutions', actual)]:
    nbformat.write(notebook, directory / f'DRAFT_{STEM}_{name}.ipynb')
    body, _ = HTMLExporter().from_notebook_node(notebook)
    target = directory / f'{name}.html'
    target.write_text(body)
    html_hashes[target.name] = digest(target)
figures = {name: {'current_sha256': digest(learner / 'figures' / name), 'historical_sha256': digest(old / 'figures' / name)} for name in execution['figures']}
assert all(record['current_sha256'] == execution['figures'][name] for name, record in figures.items())
record = {
    'status': 'RENDERED_REQUIRES_VISUAL_REVIEW',
    'learner_execution_sha256': digest(learner / 'execution.json'),
    'completed_learner_sha256': digest(learner / 'completed_learner.ipynb'),
    'renderer_sha256': digest(Path(__file__)),
    'html': html_hashes,
    'demonstrations_from_recorded_execution': True,
    'student_exercise_stubs_preserved': True,
    'independent_review': False,
    'historical_figure_comparison': figures,
    'changed_figures': [name for name, value in figures.items() if value['current_sha256'] != value['historical_sha256']],
}
(directory / 'render.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))

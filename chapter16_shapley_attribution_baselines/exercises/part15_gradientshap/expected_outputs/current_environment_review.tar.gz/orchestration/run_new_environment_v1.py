from pathlib import Path
from importlib import metadata
from datetime import datetime, timezone
import hashlib
import json
import os
import psutil
import shutil
import subprocess
import sys
import time

ROOT = Path('/home/bitwise/Documents/ARENA_3.0_Extended')
CACHE = Path('/home/bitwise/.cache/arena_extended/gradientshap')
PART = ROOT / 'chapter16_shapley_attribution_baselines/exercises/part15_gradientshap'
mode = sys.argv[1]
assert mode in {'learner', 'reproduction'}
out = CACHE / f'new-environment-{mode}-v1'
assert not out.exists(), out
learner = CACHE / 'new-environment-learner-v1'
cmd = [sys.executable, str(PART / ('execute_learner.py' if mode == 'learner' else 'reproduce_native.py'))]
if mode == 'reproduction':
    cmd += ['--learner-directory', str(learner)]
cmd += ['--output-directory', str(out)]
lock = (ROOT / 'uv.lock').read_bytes()
lock_sha = hashlib.sha256(lock).hexdigest()
assert lock_sha == 'e96e946bb00f50592d32c1b3bf453fca4482a0097731120defbebcd978f019eb'
record = {
    'schema': 'arena16.15.current_environment_execution.v1',
    'mode': mode,
    'status': 'RUNNING',
    'started_at_utc': datetime.now(timezone.utc).isoformat(),
    'command': cmd,
    'cwd': str(ROOT),
    'interpreter': sys.executable,
    'python': sys.version,
    'uv_lock_sha256_before': lock_sha,
    'packages': {name: metadata.version(name) for name in ('torch', 'numpy', 'scipy', 'shap', 'captum', 'nbclient', 'nbconvert', 'matplotlib')},
    'environment': {name: os.environ.get(name, '') for name in ('CUDA_VISIBLE_DEVICES', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'OPENBLAS_NUM_THREADS', 'BNB_CUDA_VERSION')},
    'environment_scope': 'Separate execution-time environment receipt; scientific execution.json and reproduction.json are not modified.',
}
receipt = CACHE / f'new-environment-{mode}-v1-environment.json'
receipt.write_text(json.dumps(record, indent=2) + '\n')
start = time.monotonic()
peak = samples = 0
with (CACHE / f'new-environment-{mode}-v1.log').open('w') as log:
    process = subprocess.Popen(cmd, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    while process.poll() is None:
        try:
            parent = psutil.Process(process.pid)
            rss = 0
            for child in [parent, *parent.children(recursive=True)]:
                try:
                    rss += child.memory_info().rss
                except psutil.NoSuchProcess:
                    pass
            peak = max(peak, rss)
            samples += 1
        except psutil.NoSuchProcess:
            pass
        time.sleep(0.25)
    code = process.wait()
record.update(
    returncode=code,
    finished_at_utc=datetime.now(timezone.utc).isoformat(),
    wall_seconds=time.monotonic() - start,
    sampled_process_tree_peak_rss_bytes=peak,
    rss_sample_interval_seconds=0.25,
    rss_samples=samples,
    uv_lock_sha256_after=hashlib.sha256((ROOT / 'uv.lock').read_bytes()).hexdigest(),
    output_directory_bytes=sum(path.stat().st_size for path in out.rglob('*') if path.is_file()),
)
record['status'] = 'PASS' if code == 0 and record['uv_lock_sha256_after'] == lock_sha else 'FAIL'
receipt.write_text(json.dumps(record, indent=2) + '\n')
if out.exists():
    environment = out / 'environment'
    environment.mkdir(exist_ok=False)
    (environment / 'uv.lock').write_bytes(lock)
    shutil.copy2(receipt, environment / 'execution_environment.json')
print(json.dumps(record, indent=2))
sys.exit(0 if record['status'] == 'PASS' else 1)

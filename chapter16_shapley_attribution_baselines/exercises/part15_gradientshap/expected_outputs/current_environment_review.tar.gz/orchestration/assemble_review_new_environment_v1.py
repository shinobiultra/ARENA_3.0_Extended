from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import sys
import tarfile

ROOT = Path('/home/bitwise/Documents/ARENA_3.0_Extended')
sys.path.insert(0, str(ROOT))
from scripts.evidence_bundles import seal_review_bundle

CACHE = Path('/home/bitwise/.cache/arena_extended/gradientshap')
learner = CACHE / 'new-environment-learner-v1'
fresh = CACHE / 'new-environment-reproduction-v1'
part = ROOT / 'chapter16_shapley_attribution_baselines/exercises/part15_gradientshap'
expected = part / 'expected_outputs'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def record(path):
    return {'absolute_path': str(path), 'sha256': digest(path), 'size_bytes': path.stat().st_size}

execution = json.loads((learner / 'execution.json').read_text())
reproduction = json.loads((fresh / 'reproduction.json').read_text())
browser = json.loads((learner / 'html_review/root_browser_review.json').read_text())
assert execution['status'] == reproduction['status'] == 'PASS'
assert browser['status'] == 'PASS_ROOT_BROWSER_REVIEW'
assert browser['learner_execution']['sha256'] == digest(learner / 'execution.json')
for item in [browser['render'], browser['html'], *browser['screenshots']]:
    assert digest(Path(item['path'])) == item['sha256']
for name, checksum in execution['source_inputs'].items():
    assert digest(ROOT / name) == checksum == digest(learner / 'source_snapshot' / name)
notes = [
    'Explicit donor indices and independent alpha streams are legible; K8 prefix is highlighted.',
    'Donor-to-query segments, sampled alpha positions and signed displacement bars agree.',
    'Student affine and quadratic gradients overlay their analytic controls.',
    'ReLU contributions retain literal zero-or-two values; quadratic samples retain alpha dependence.',
    'Nested running estimates and ordinary SE are shown against population mean and inverse-square-root sampling rate.',
    'Full-background bases, dummy-coordinate and constant controls are visible; finite ReLU completeness residual is retained.',
    'Quadrature drift is nonmonotonic and explicitly approximate; analytic path control remains separate.',
    'Averaging donor path attributions differs visibly from explaining the mean donor.',
    'Noisy ReLU attribution tracks the smoothed target; the clean-target residual grows.',
    'Path shares approximately two-thirds/one-third differ from exact one-half/one-half coalition shares.',
    'Equivalent binary-output representations retain distinct exact-kink gradients and equal discrete Shapley shares.',
    'Insertion/deletion preserve all endpoints and the dummy plateau against every feature ordering.',
    'Canonical threshold play displays the gate, three attribution targets and coincident replacement curves.',
    'Seven-model predictive controls, shrinking sampling error and quadrature drift are readable; shuffled models fail predictively.',
    'All seven signed method panels, held-out split boundary and separate per-model residual scales are visible.',
    'Fixed recipe source 1 retains signed credit, full-background base, prediction and finite-sampling reconstruction residual.',
    'Five backgrounds and three noise scales separate base changes, target movement, sampling error and quadrature drift.',
    'Replicate coverage is labeled descriptive; nearest-training distances remain geometry rather than OOD probability.',
    'All 119 audit rows and 100 random orders remain in oriented replacement curves; coincident means are explicitly identified.',
    'Canonical real-recipe play keeps signed feature credit and local insertion/deletion curves, labeled exploratory audit reuse.',
]
assert len(notes) == len(execution['figures']) == 20
source_review = {
    'status': 'PASS_AUTHOR_REVIEW',
    'reviewed_at_utc': datetime.now(timezone.utc).isoformat(),
    'reviewer': 'Astra section author',
    'independent_review': False,
    'scope': 'Current source inspection and all twenty actual PNGs opened in this revalidation. No new independent scientific approval.',
    'source_inputs': execution['source_inputs'],
    'source_findings': [
        'Read the target notebook pair, page, visible method definitions, learner completion and source-snapshot logic, protocol, native play, plot semantics, package guards and publication/reproduction checks.',
        'Only publish_study.py differs from the historical learner source inventory; its frozen packaging change excludes raw .pt payloads and seals a bounded manifest. Scientific methods and protocol remain byte-identical.',
        'Expected Gradients uses explicit donor/alpha paths and gradient-times-displacement draws; SE uses unbiased sample variance divided by K. Query noise changes both path point and displacement.',
        'Finite Gauss-Legendre integration is approximate at ReLU jumps; exhaustive intact-donor coalition Shapley is a distinct allocation target.',
        'All seven predictors are freshly refit and twenty-one known state identities checked before the audit boundary. The full source-only reproduction compares every deterministic value exactly.',
        'SHAP 0.49.1 and Captum 0.9.0 same-draw references remain source-pinned with unchanged atol=1e-10 and rtol=1e-10.',
    ],
    'figure_observations': {name: {'sha256': checksum, 'opened_and_inspected': True, 'observation': note} for (name, checksum), note in zip(execution['figures'].items(), notes, strict=True)},
    'historical_pixel_comparison': record(learner / 'html_review/figure_pixel_comparison.json'),
    'play_review': record(learner / 'play_review_v2/play_review.json'),
    'play_observations': [
        'Opened the five additional threshold/native variation PNGs; changed weights, query, donor, threshold, model, row, background, budget and noise affect the intended outputs.',
        'The default play matches the retained native payload exactly; current source-only reproduction also includes both canonical play payloads.',
        'Additional threshold choices can place the legend over part of a bar; canonical published figures remain readable. No frozen plotting source was changed.',
        'The failed extra exact-contribution-prefix assertion is preserved. Exact donor/alpha prefixes pass; separate gradient batch sizes differ by at most 1.7763568394002505e-14. No original gate or tolerance was changed.',
    ],
    'limitations': ['Known seeded models and data are reproduced; this is not an independent model or dataset replication.', 'Finite Monte Carlo, approximate quadrature, background/noise sensitivity and computational replacement limitations are retained.'],
}
(learner / 'source_review.json').write_text(json.dumps(source_review, indent=2) + '\n')
review = {
    'status': 'PASS',
    'reviewer': 'Astra section author with root author browser inspection',
    'independent_review': False,
    'browser_math_and_dropdowns_checked': True,
    'lesson_sha256': digest(part / 'lesson.md'),
    'completed_learner_sha256': digest(learner / 'completed_learner.ipynb'),
    'learner_execution_sha256': digest(learner / 'execution.json'),
    'figures': execution['figures'],
    'screenshots': browser['screenshots'],
    'root_browser_review': record(learner / 'html_review/root_browser_review.json'),
    'author_source_and_figure_review': record(learner / 'source_review.json'),
    'browser_observations': browser['dom'],
    'learner_environment': record(learner / 'environment/execution_environment.json'),
    'fresh_environment': record(fresh / 'environment/execution_environment.json'),
    'play_review': record(learner / 'play_review_v2/play_review.json'),
    'claim_boundary': 'Current-environment author revalidation only. Historical independent approvals are not transferred to new execution or image hashes. No full-course completion claim.',
}
(learner / 'visual_review.json').write_text(json.dumps(review, indent=2) + '\n')
backup = CACHE / 'before-current-environment-publication-v1'
backup.mkdir(exist_ok=False)
for path in expected.iterdir():
    if path.is_file():
        shutil.copy2(path, backup / path.name)
archive = expected / 'current_environment_review.tar.gz'
members = [(learner / name, f'learner/{name}') for name in ('execution.json', 'source_review.json', 'visual_review.json')]
for prefix in ('environment', 'html_review', 'play_review', 'play_review_v2'):
    members += [(path, 'learner/' + str(path.relative_to(learner))) for path in sorted((learner / prefix).rglob('*')) if path.is_file()]
members += [(path, 'fresh/' + str(path.relative_to(fresh))) for path in sorted((fresh / 'environment').rglob('*')) if path.is_file()]
members.append((fresh / 'reproduction.json', 'fresh/reproduction.json'))
for name in ('run_new_environment_v1.py', 'render_new_environment_v1.py', 'play_new_environment_v1.py', 'assemble_review_new_environment_v1.py', 'new-environment-scientific-tests-v1.log', 'new-environment-learner-v1.log', 'new-environment-reproduction-v1.log', 'new-environment-play-v1.log', 'new-environment-play-v2.log'):
    members.append((CACHE / name, 'orchestration/' + name))
with tarfile.open(archive, 'w:gz') as handle:
    for path, name in members:
        handle.add(path, arcname=name, recursive=False)
contract = seal_review_bundle(archive, provenance={
    'kind': 'native_execution_packaging',
    'source_execution': record(learner / 'execution.json'),
    'measurement_claim': 'Packaging of new author environment, source, figure, browser and play review. Existing scientific execution and reproduction receipts are preserved unchanged.',
})
print(json.dumps({'status': 'PASS', 'review': str(learner / 'visual_review.json'), 'archive': contract['archive'], 'member_count': contract['member_count']}, indent=2))

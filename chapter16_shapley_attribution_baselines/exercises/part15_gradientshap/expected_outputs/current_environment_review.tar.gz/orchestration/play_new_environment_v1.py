from pathlib import Path
from types import SimpleNamespace
import ast
import hashlib
import json
import sys
import torch as t
import matplotlib.pyplot as plt

ROOT = Path('/home/bitwise/Documents/ARENA_3.0_Extended')
sys.path.insert(0, str(ROOT))
from chapter16_shapley_attribution_baselines.exercises.part15_gradientshap import gradientshap_methods as helpers
from chapter16_shapley_attribution_baselines.exercises.part15_gradientshap import gradientshap_diagnostics as diagnostics
from chapter16_shapley_attribution_baselines.exercises.part15_gradientshap import gradientshap_study as study
from chapter16_shapley_attribution_baselines.exercises.part15_gradientshap import gradientshap_plots as plots
from chapter16_shapley_attribution_baselines.exercises.part15_gradientshap.gradientshap_data import load_split
from chapter16_shapley_attribution_baselines.exercises.part15_gradientshap.run_native import load_payload
from chapter16_shapley_attribution_baselines.exercises.part14_deepshap import deepshap_methods

t.set_num_threads(4)
t.set_default_dtype(t.float64)
learner = Path('/home/bitwise/.cache/arena_extended/gradientshap/new-environment-learner-v1')
out = learner / 'play_review_v2'
out.mkdir(exist_ok=False)
native = learner / 'figures/native'
notebook = json.loads((learner / 'completed_learner.ipynb').read_text())
namespace = dict(vars(helpers))
sources = {}
for cell in notebook['cells']:
    if cell['cell_type'] != 'code':
        continue
    source = ''.join(cell['source'])
    for node in ast.parse(source).body:
        if isinstance(node, ast.FunctionDef) and node.name in study.METHOD_NAMES:
            assert node.name not in sources
            sources[node.name] = ast.get_source_segment(source, node)
            exec(compile(ast.Module(body=[node], type_ignores=[]), str(learner / 'completed_learner.ipynb'), 'exec'), namespace)
assert set(sources) == set(study.METHOD_NAMES)
methods = SimpleNamespace(**{name: namespace[name] for name in study.METHOD_NAMES})

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def plain(value):
    if isinstance(value, t.Tensor):
        return value.tolist()
    if isinstance(value, dict):
        return {key: plain(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [plain(item) for item in value]
    return value

records = []
for index, kwargs in enumerate(({}, {'bias': -1.0, 'samples': 128}, {'weights': (1.0, 3.0), 'query': (1.5, 0.5), 'reference': (0.2, 0.1), 'samples': 2048})):
    result = diagnostics.threshold_play(methods, **kwargs)
    assert t.isfinite(result['mean']).all()
    t.testing.assert_close(result['exact_shapley'].sum(), result['prediction'] - result['base'], atol=1e-12, rtol=1e-12)
    figure = plots.plot_threshold_play(result)
    target = out / f'threshold_variation_{index}.png'
    figure.savefig(target, dpi=180, bbox_inches='tight')
    plt.close(figure)
    records.append({'kind': 'threshold', 'selection': kwargs, 'mean': plain(result['mean']), 'exact_shapley': plain(result['exact_shapley']), 'figure': target.name, 'figure_sha256': digest(target)})

fitted, prepared, evaluated = [load_payload(native / name) for name in ('fitted.pt', 'prepared.pt', 'evaluated.pt')]
train, explain, audit = [load_split(name) for name in ('train', 'explain', 'audit')]
baseline = None
selections = ({}, {'samples': 32}, {'model_key': 'clean_1', 'split': 'explain', 'row_index': 7, 'background_key': 'nested16', 'samples': 128, 'sigma': 0.1}, {'model_key': 'ridge', 'split': 'audit', 'row_index': 1, 'background_key': 'independent64_a', 'samples': 512, 'sigma': 0.02})
for index, kwargs in enumerate(selections):
    result = study.native_play(fitted, prepared, evaluated, train, explain, audit, methods=methods, deep_methods=deepshap_methods, **kwargs)
    assert t.isfinite(result['phi_eg']).all()
    assert result['mc_samples'].shape == (kwargs.get('samples', 2048), 8)
    if index == 0:
        baseline = result
        saved = load_payload(native / 'play.pt')
        for name in ('phi_eg', 'se_eg', 'phi_q512', 'phi_exact', 'phi_deep', 'phi_gradient', 'mc_samples'):
            assert t.equal(result[name], saved[name]), name
    if index == 1:
        ids = t.tensor([result['selection']['source_id']], dtype=t.int64)
        short_indices, short_alpha = methods.sample_path_schedule(ids, 64, 32, study.PRIMARY_SCHEDULE_SEED)
        long_indices, long_alpha = methods.sample_path_schedule(ids, 64, 2048, study.PRIMARY_SCHEDULE_SEED)
        assert t.equal(short_indices, long_indices[:, :32])
        assert t.equal(short_alpha, long_alpha[:, :32])
        prefix_difference = float((result['mc_samples'] - baseline['mc_samples'][:32]).abs().max())
    figure = plots.plot_real_recipe_play(result)
    target = out / f'native_variation_{index}.png'
    figure.savefig(target, dpi=180, bbox_inches='tight')
    plt.close(figure)
    records.append({'kind': 'native', 'selection': plain(result['selection']), 'prediction': plain(result['prediction']), 'base': plain(result['base']), 'phi_eg': plain(result['phi_eg']), 'se_eg': plain(result['se_eg']), 'phi_exact': plain(result['phi_exact']), 'figure': target.name, 'figure_sha256': digest(target)})
receipt = {
    'status': 'PASS',
    'scope': 'Author execution of editable play variations using the nine own-answer functions extracted from the actual completed learner. Native plays intentionally reuse the newly fitted learner model state; this is distinct from the source-only full reproduction.',
    'completed_learner_sha256': digest(learner / 'completed_learner.ipynb'),
    'execution_sha256': digest(learner / 'execution.json'),
    'runner_sha256': digest(Path(__file__)),
    'own_answer_function_sha256': {name: hashlib.sha256(source.encode()).hexdigest() for name, source in sources.items()},
    'default_native_matches_saved_exactly': True,
    'smaller_budget_preserves_literal_donor_and_alpha_prefix': True,
    'recomputed_contribution_prefix_max_absolute_difference': prefix_difference,
    'recomputed_contribution_prefix_note': 'Separately recomputed gradient batches can differ at float64 rounding scale despite identical donor and alpha prefixes. No new numerical acceptance tolerance is introduced; full source-only reproduction remains byte-exact for the declared computation shapes.',
    'variations': records,
    'independent_review': False,
}
(out / 'play_review.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'status': receipt['status'], 'threshold_runs': 3, 'native_runs': 4, 'receipt': str(out / 'play_review.json')}, indent=2))

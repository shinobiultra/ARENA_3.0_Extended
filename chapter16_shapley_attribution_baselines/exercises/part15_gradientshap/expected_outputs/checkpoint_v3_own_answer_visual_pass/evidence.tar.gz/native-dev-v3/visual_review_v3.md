# GradientSHAP native visual review v3

## Verdict

**PASS — all 20 actual v3 PNGs are readable and scientifically labeled at original resolution and at a 1200-pixel notebook display width. No remaining visual defect was found.**

This is a visual-evidence gate, not a release declaration. The harness separately reported the fresh v3 reproduction as passing; publication and browser review remain outside this file.

## Evidence boundary

- Own-answer execution: `PASS`; `126` cells, `79` code cells, `20` embedded figures, `60.05` seconds, completed from own answers `True`, native model executed `True`, changed sources `[]`.
- `execution.json` SHA-256: `d9b0506e72ff849d17eb76ddba23f424ea33824dd9086fcbba954888b1af6973`.
- `completed_learner.ipynb` SHA-256: `6c2c458fa715f52a62f123ce19c8e0d88c9776f4255fe32b2d1d68a1a8546055`.
- `gradientshap_plots.py` SHA-256: `f7369b14f53d0ac3cac2c54efa12ed2b9b799bb2e94336cb0b030b5d585380d0`.
- Section no-fit gate before v3: 47 passed, 1 explicit native-fit skip; the only warnings were three unrelated SHAP pending deprecations.
- Original-resolution inspection used `view_image`. A second set under `notebook-width-1200/` was generated only by Lanczos downscaling the saved v3 PNGs, then inspected for the embedded learner experience.
- Figures 01–15, 17 and 20 are byte-identical to the v2 PNGs already inspected at original and 1200-pixel width. Figures 16, 18 and 19 were inspected directly from their changed v3 bytes at both sizes.
- Figure 15 received explicit inspection at its 1200×1390 notebook representation; native-resolution crops were also used earlier to verify small labels and all seven rows.
- No figure was recomputed from fabricated data for this review, no outcome was removed, and no source was edited after the v3 run.

## Exact reviewed v3 PNG inventory

| Figure | Pixels | SHA-256 |
|---|---:|---|
| `01_schedule_prefix.png` | 2036×758 | `13d08cad9644b039ce64c5529bffb595249b915621a90e2682b78e1cc9adfd7c` |
| `02_path_interpolation.png` | 1964×776 | `8c985c0c67adf9cd657b8cb044a3644327cc1bb0995fba9b2f93bd442ed539a8` |
| `03_gradient_controls.png` | 1964×758 | `1623f75668187445e9964ab3b68c23b088acdb9f4d6f9c920b842bddf0eac3c3` |
| `04_relu_samples.png` | 1964×740 | `8cba96523adb409b73b389de006948f6cb12751dc8d0d5f26b3a238e6e1b3cd4` |
| `05_mc_convergence.png` | 1964×758 | `517cdf5b04a4f13bfe6ca58339a129b1057b77e7f6e0557fc6bdb32b36454afd` |
| `06_estimator_controls.png` | 1964×758 | `7e01b288602f7d85aef87ab997439193e3e375c1276cf8269641eec09ddec40a` |
| `07_quadrature_doubling.png` | 1964×758 | `396f9d35355f39b0180fffa78e27f818b6ac40646576ac6f473ff8ef2381d247` |
| `08_background_average.png` | 1964×758 | `afc5ae3cbf3eeb8bc8d037433f6cc042c9c91207e9fd7df05d141f55902a8c69` |
| `09_gaussian_target_shift.png` | 1964×758 | `cb51d5ff11ebb2f75d3baaa5e003d96e86faa2c7d2cef4015240fc7876b74014` |
| `10_path_vs_coalition.png` | 1964×740 | `e1a3541f575611c5d6b044308949aefecb910dee219887bd7cd16059d0dc5bd3` |
| `11_kink_representation.png` | 1964×740 | `8828bb1c26cc3cef705be9a9acbfd28905594f9aa1c03b2ccb3804a91ddaae26` |
| `12_replacement_fixture.png` | 1964×740 | `ac34938cabb50f62565cef6f0deeea84dcf92eebbde9f15413fbed8b06d549ec` |
| `13_threshold_play.png` | 2360×758 | `e1054231e09209f1e0c5ad8cf09a18e58438b36e8d9955874f989d388ca35130` |
| `14_native_overview.png` | 2756×875 | `440cf2f3a42d84f56094ac431276fe0e2224a1ee8bef5ed1e8378716690431e7` |
| `15_allrow_method_map.png` | 2792×3233 | `71945a5053a6f66334c6d9ef07e3fc99c744b0bfa3f60fe134fe679fb941ecb4` |
| `16_fixed_waterfall.png` | 2396×1028 | `b7d556ff0891d9f549fedc1fb62fc8e863f800ad4cb9648f11d5b213bdceff98` |
| `17_background_and_noise.png` | 2396×1514 | `789cd34f5befb9213c11ca5e0c0da294a828aea90043b7e2ace72ded44a30bfe` |
| `18_replicates_and_distance.png` | 2432×884 | `8b30d376203760f12f367cac4818c4bee0db2cf0ca49edea372695e14c00048f` |
| `19_replacement_curves.png` | 2270×883 | `95984d5bcece3ae65587f522ff8c688e8a5a58a5d9c580399ea736ca3abf63b8` |
| `20_real_recipe_play.png` | 2468×1063 | `14b57325c7f3edb2196a44fc478b95da9797813f46a92a074788494e6f06719a` |

## Original and notebook-width findings

| Figure | Finding |
|---|---|
| `01_schedule_prefix` | PASS — donor-index heatmap, source IDs, literal K=8 prefix and per-source alpha streams remain readable at original and notebook width. |
| `02_path_interpolation` | PASS — donors, query, alpha-colored path points and donor-preserving displacement bars are unclipped and distinct. |
| `03_gradient_controls` | PASS — analytic/student affine bars and quadratic 2z line/samples remain distinguishable; subscripts render. |
| `04_relu_samples` | PASS — the ReLU 0/2 step and quadratic 2-alpha control remain visually explicit. |
| `05_mc_convergence` | PASS — nested estimate, ordinary MC SE, population target and 1/sqrt(K) reference remain distinguishable on log axes. |
| `06_estimator_controls` | PASS — full-background completeness and exact-zero versus finite-ReLU controls remain visible and labeled. |
| `07_quadrature_doubling` | PASS — absolute analytic error and successive doubling drift are separate; the title truthfully rejects an exact-oracle reading. |
| `08_background_average` | PASS — both donor paths, q512 controls and the mean-donor counterexample remain readable. |
| `09_gaussian_target_shift` | PASS — clean/smoothed targets, ordinary SE and both residual definitions remain clear; sigma math renders. |
| `10_path_vs_coalition` | PASS — analytic path, q512 and exact coalition credit remain distinct beside the removal control. |
| `11_kink_representation` | PASS — binary-input agreement, graph-route colors and exact discrete Shapley comparison remain legible. |
| `12_replacement_fixture` | PASS — all six orders, the selected signed order, endpoints and possible dummy plateau remain visible. |
| `13_threshold_play` | PASS — editable path, three credit methods, insertion/deletion and the coincident-ranking note remain readable. |
| `14_native_overview` | PASS — all 7 models, 272 rows, 8 features and 15,232 coordinates are explicit. MPa² MSE, MPa EG-minus-q512 error, ordinary SE and q512-minus-q256 drift are separate; clean, shuffled and ridge controls are visible; q512 is labeled approximate. |
| `15_allrow_method_map` | PASS — all seven model rows and all 15,232 coordinates remain present. At 1200×1390, model names, mean/max gaps, dedicated MPa colorbars, feature labels and the explanation/audit boundary are readable without zoom; the long vertical layout requires normal page scrolling. |
| `16_fixed_waterfall` | PASS — fixed source/model/base/prediction, finite EG reconstruction, ordinary SE and five aligned methods remain explicit. The population limitation is in reserved title space and no longer overlaps the x-axis. |
| `17_background_and_noise` | PASS — all five backgrounds, all 272 rows, four movement measures, both target residuals, ordinary SE and MPa/unit labels remain readable at notebook width. |
| `18_replicates_and_distance` | PASS — three models, 64 rows, 64 schedules, nominal reference and all four geometry series remain visible. The descriptive/approximate and non-OOD qualification is unobstructed above the panels. |
| `19_replacement_curves` | PASS — all 119 audit rows, five methods, 100 random orders, negative-prefix language, coincident curves and no-superiority limitation remain readable. The corrected 2270-pixel width is suitable at 1200-pixel notebook display. |
| `20_real_recipe_play` | PASS — source/model/background/K/sigma/audit status, five local explanations, ordinary SE and insertion/deletion curves remain legible; coincident curves are retained rather than culled. |

## Controls, units and limitations retained

- Analytic figures retain schedule, affine/quadratic, finite-sample, exact-identity, quadrature, background, noise, path/coalition, kink and random-order controls.
- Native figures retain every predeclared model and row: clean MLP seeds, shuffled-label MLP seeds, ridge control, 272 held-out rows and the fixed 119-row audit.
- Attribution and predictions use MPa; audit mean squared error uses MPa²; noise uses train-standardized input units; distance uses train-standardized Euclidean geometry.
- Ordinary sampling SE, observed EG-minus-q512 error and q512-minus-q256 quadrature drift remain separate quantities.
- Learner-visible limitations remain explicit: q512 is approximate; replicate coverage is descriptive; distance is not density or an OOD probability; one recipe is not a population claim; replacement interventions are not an attribution-superiority gate; editable real play is exploratory.

No further plotting change is justified by the actual v3 originals or their 1200-pixel notebook representations.

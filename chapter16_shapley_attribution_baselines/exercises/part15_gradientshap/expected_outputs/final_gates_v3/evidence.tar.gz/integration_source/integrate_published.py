"""Stage 16.15 navigation/registries only after its real publication is validated.

Default is read-only. --apply writes the complete reviewed update set. Existing
16.15 entries cause an explicit failure; do not apply this script twice.
"""
from __future__ import annotations

import argparse
import csv
import io
import json
from pathlib import Path
import sys
import yaml

ROOT=Path('/home/bitwise/Documents/ARENA_3.0_Extended')
sys.path.insert(0,str(ROOT))
PART='chapter16_shapley_attribution_baselines/exercises/part15_gradientshap'
HERE=ROOT/PART
STEM='16.15_Expected_Gradients_Which_Expectation_Does_GradientSHAP_Estimate'
PAGE='chapter16_shapley_attribution_baselines/instructions/pages/15_[16.15]_Expected_Gradients_Which_Expectation_Does_GradientSHAP_Estimate.md'
TITLE='Expected Gradients: Which Expectation Does GradientSHAP Estimate?'


def append_table(updates, prefix, section_key, key, row, collection):
    csv_path=ROOT/f'docs/{prefix}.csv'
    rows=list(csv.DictReader(io.StringIO(csv_path.read_text())))
    columns=list(rows[0])
    if set(row)!=set(columns):
        raise ValueError(f'Wrong {prefix} fields: {set(row)^set(columns)}')
    if any(str(item[section_key])==key for item in rows):
        raise ValueError(f'{key} already exists in {prefix}; inspect rather than duplicate.')
    output=io.StringIO(newline='');writer=csv.DictWriter(output,fieldnames=columns,lineterminator='\n')
    writer.writeheader();writer.writerows(rows+[row]);updates[csv_path]=output.getvalue()
    lock_path=ROOT/f'docs/{prefix}.lock.yml';data=yaml.safe_load(lock_path.read_text())
    if any(str(item[section_key])==key for item in data[collection]):raise ValueError('Conflicting YAML entry.')
    typed=dict(row)
    if prefix=='hard_exercise_ladder_registry':
        typed.update(difficulty=5,importance=5,requires_gpu=False)
    data[collection].append(typed);updates[lock_path]=yaml.safe_dump(data,sort_keys=False,width=100)
    md_path=ROOT/f'docs/{prefix}.md'
    line='| '+' | '.join(str(row[c]).replace('|','/') for c in columns)+' |'
    updates[md_path]=md_path.read_text().rstrip()+'\n'+line+'\n'


def main(apply=False):
    from scripts.audit_course_surface import _has_direct_experiment_contract
    from scripts.audit_report_evidence_contracts import report_contract_blockers
    from chapter16_shapley_attribution_baselines.exercises.part15_gradientshap.publish_study import validate_fresh
    from chapter16_shapley_attribution_baselines.exercises.part15_gradientshap.run_native import digest
    needed=['artifacts.lock.yml','verification_report.json','expected_outputs/learner_execution.json',
            'expected_outputs/fresh_reproduction.json',f'{STEM}_exercises.ipynb',f'{STEM}_solutions.ipynb']
    missing=[str(HERE/n) for n in needed if not (HERE/n).is_file()]
    if missing:raise FileNotFoundError('Publication incomplete:\n'+'\n'.join(missing))
    lock=yaml.safe_load((HERE/'artifacts.lock.yml').read_text())
    report=json.loads((HERE/'verification_report.json').read_text())
    published=json.loads((HERE/'expected_outputs/learner_execution.json').read_text())
    fresh=json.loads((HERE/'expected_outputs/fresh_reproduction.json').read_text())
    problems=report_contract_blockers(lock,report)
    if problems:raise ValueError('Report contract is incomplete:\n'+'\n'.join(problems))
    if not report.get('accepted') or not report.get('tests_passed'):raise ValueError('Report is not accepted.')
    measured=report['metrics']['gpu_test']
    validate_fresh(Path(published['learner_directory']),Path(measured['fresh_output_directory']))
    for path,field in [(HERE/f'{STEM}_exercises.ipynb','published_exercises_sha256'),
                       (HERE/f'{STEM}_solutions.ipynb','published_solutions_sha256'),
                       (ROOT/PAGE,'published_page_sha256')]:
        if not path.is_file() or digest(path)!=published[field]:raise ValueError(f'Published file changed: {path}')
    if not _has_direct_experiment_contract(HERE/f'{STEM}_exercises.ipynb'):
        raise ValueError('The real learner/refit surface contract is incomplete.')
    review=published.get('visual_review',{})
    if review.get('status')!='PASS' or not review.get('browser_math_and_dropdowns_checked') or not review.get('screenshots'):
        raise ValueError('Actual browser review is incomplete.')
    if published.get('embedded_figures')!=20 or measured['replicate_sample_coordinates']!=201326592:
        raise ValueError('The reviewed visible/native scope changed.')
    if fresh.get('status')!='PASS' or fresh['comparisons']['max_absolute_error']!=0:
        raise ValueError('Full exact fresh reproduction is required.')
    updates={}
    config_path=ROOT/'infrastructure/core/config_extension.yaml';config=yaml.safe_load(config_path.read_text())
    sections=config['chapters']['chapter16_shapley_attribution_baselines']['sections']
    if '16.15' in config['conversion_map'] or any(row.get('number')=='16.15' for row in sections):
        raise ValueError('16.15 already registered; do not repeat this mutation.')
    page_stem=Path(PAGE).stem
    config['conversion_map']['16.15']={'streamlit_page':page_stem,'exercise_dir':'part15_gradientshap'}
    sections.append({'id':'15_expected_gradients_which_expectation_does_gradientshap_estimate',
                     'number':'16.15','title':TITLE,'exercise_dir':'part15_gradientshap',
                     'page_file':Path(PAGE).name,
                     'header_image':'https://raw.githubusercontent.com/info-arena/ARENA_img/main/misc/headers/header-13-2.png',
                     'status':'ARENA-style Expected Gradients with complete sampling and controls',
                     'streamlit_description':'Build Expected Gradients from explicit samples, compare Monte Carlo error with changing targets, and test all-row attribution, backgrounds, noise and replacements.',
                     'streamlit_description_short':'Which expectation does GradientSHAP estimate?'})
    updates[config_path]=yaml.safe_dump(config,sort_keys=False,width=100)
    style_path=ROOT/'docs/arena_style_rewrite_status.yml';style=style_path.read_text()
    if "  '16.15':" in style:raise ValueError('16.15 style entry already exists.')
    notes=(f"{published['cells']} cells, {published['code_cells']} own-answer code cells, nine student methods, "
           f"20 inspected figures and two editable plays. All seven known predictors are refitted and all 21 "
           f"state hashes match. Every one of 1,904 held-out model-rows retains K2048 samples, q256/q512 pairs "
           f"and exact 256-coalition games. Full 64-replicate samples, five backgrounds, three noise scales, "
           f"SHAP/Captum same-draw references, distance diagnostics and 100 random-order controls are retained. "
           f"Fresh reproduction compares {measured['fresh_compared_arrays']} arrays and "
           f"{measured['fresh_compared_elements']} elements exactly. Ordinary SE and quadrature are qualified; "
           f"continuous-path attribution differs from discrete feature Shapley and is not physical causality.")
    block=yaml.safe_dump({'16.15':{'status':'course_ready','page':PAGE,'notes':notes}},sort_keys=False,width=100)
    updates[style_path]=style.rstrip()+'\n'+''.join('  '+line+'\n' for line in block.splitlines())
    method={'method_name':'GradientSHAP','paper':'Improving performance of deep learning models with axiomatic attribution priors and expected gradients',
            'year':'2021','category':'local_feature_attribution','model_family':'pytorch_affine_relu_neural_network',
            'has_code':'true','has_weights':'not_applicable','local_24gb_status':'LOCAL_GREEN',
            'implementation_status':'REQUIRED_IMPLEMENT','verification_status':'IMPLEMENTED_CPU_NATIVE_EXPECTED_GRADIENTS',
            'baseline_status':'HAS_FULL_SAMPLING_QUADRATURE_EXACT_GAMES_AUTHOR_PARITY_NOISE_AND_REPLACEMENT_CONTROLS',
            'notes':('Section 16.15; nine visible methods on the exact seven known Concrete predictors; complete per-draw and pair evidence, all-row SHAP/Captum same-draw checks, background/noise controls and independent fresh reproduction. Expected Gradients targets continuous paths, not exact discrete feature Shapley or physical ingredient effects.')}
    append_table(updates,'method_registry','method_name','GradientSHAP',method,'methods')
    ladder={'section':'16.15','notebook_id':lock['notebook_id'],'title':TITLE,'gt_tier':'GT-0','difficulty':'5','importance':'5','requires_gpu':'false',
            'metadata_source':f'{PART}/artifacts.lock.yml:exercise_metadata',
            'fixture_provenance_source':f'{PART}/expected_outputs/README.md','visible_tests_source':f'{PART}/gradientshap_methods_tests.py',
            'report_source':f'{PART}/verification_report.json',
            'gpu_evidence_requirement':'CPU seven-model refit; all 21 known state hashes; complete fresh-process reproduction',
            'toy_oracle_requirement':'affine; quadratic; ReLU; constant; dummy; threshold and noisy-target counterexamples',
            'slow_fast_oracle_requirement':'full MC schedules; all-background q256/q512; exact feature games; same-draw SHAP and Captum',
            'property_test_requirement':'prefix/source-ID invariance; ordinary SE; sigma-zero identity; state restoration; audit boundary',
            'debug_mode_requirement':'all 1,904 model-rows and 201,326,592 replicate coordinates retained; five backgrounds; noise; OOD geometry; random replacement orders',
            'release_status':'released_with_cpu_model_metric','remaining_release_evidence':''}
    append_table(updates,'hard_exercise_ladder_registry','section','16.15',ladder,'hard_exercises')
    roadmap_path=ROOT/'docs/roadmap_requirement_registry.yml';roadmap=roadmap_path.read_text()
    start=roadmap.index('  - id: shapley.gradientshap\n');end=roadmap.index('\n  - id:',start+5)
    row=yaml.safe_load('requirements:\n'+roadmap[start:end])['requirements'][0]
    if row['status']!='UNIMPLEMENTED':raise ValueError('GradientSHAP roadmap row already changed.')
    row.update(section='16.15',course_sections=['16.15'],status='TAUGHT',method_registry_names=['GradientSHAP'],
               evidence=[PAGE,f'{PART}/{STEM}_exercises.ipynb',f'{PART}/expected_outputs/learner_execution.json',
                         f'{PART}/expected_outputs/fresh_reproduction.json',f'{PART}/verification_report.json'],
               reason='Nine student methods connect exact analytic paths to complete Expected Gradients samples on seven reproduced predictors. Approximate quadrature, exact games, package replay, backgrounds, noise and held-out replacement controls remain visible and every deterministic result is independently reproduced.',blocker='')
    row_text=yaml.safe_dump([row],sort_keys=False,width=100)
    updates[roadmap_path]=roadmap[:start]+''.join('  '+line+'\n' for line in row_text.splitlines())+roadmap[end:]
    readme_path=ROOT/'README.md'
    if f'{PART}/README.md' in readme_path.read_text():raise ValueError('README already links 16.15.')
    updates[readme_path]=readme_path.read_text().rstrip()+f'\n\nThe new [16.15 {TITLE}]({PART}/README.md)\nbuilds Expected Gradients from donor and path samples. Convergence, approximate quadrature, exact\nfeature games, background and noise changes, package replay and replacement controls show which\nexpectation each attribution estimates, with two editable plays and complete fresh reproduction.\n'
    preview={str(path.relative_to(ROOT)):{'characters':len(text)} for path,text in updates.items()}
    print(json.dumps({'mode':'apply' if apply else 'read_only','updates':preview},indent=2))
    if apply:
        for path,text in updates.items():path.write_text(text)
        print('Appended only published 16.15; run merged-config build and global audits now.')


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--apply',action='store_true')
    main(parser.parse_args().apply)

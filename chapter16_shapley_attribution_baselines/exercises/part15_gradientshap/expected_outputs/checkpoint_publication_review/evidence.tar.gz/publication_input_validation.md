# GradientSHAP v3 publication-input validation

Status: **PASS / READY_FOR_SINGLE_PUBLICATION**

- Record: `/home/bitwise/.cache/arena_extended/gradientshap/review-publication-v3/publication_input_validation.json`
- Record SHA-256: `93e82ddd1639ab3a50ab91357da06db8f1d0aa9f849c24f3142280cfeac9faf2`
- Learner execution: `d9b0506e72ff849d17eb76ddba23f424ea33824dd9086fcbba954888b1af6973`
- Fresh reproduction: `0a7eb03c59a6266d5904abd4f73e63e1f927ace2e8f32323b4aaaf3437e97b9d`
- Visual review: `88cf020dd7c39cccd2097f36496c8d54df468a3d4077de9c33c819be2085f5f9`
- Figure review: `1264775bd00b9309be63da772be5db0541b8f4efb18279c59d8747642877d02d`
- Archive dry run: `3a82568980f83ff3921440cfa81a5a3227184290c5daff830ba6a3221ee6167c`
- Frontend review: `23b666cb58a9f33ca93e2d5b8942816f8d180574cbaf8e23ff649c0e164d1832`
- Current source mismatches: zero across 20 bound inputs
- Deterministic comparison: 1442 arrays / 464237288 elements / maximum error 0.0

All 20 figure files, 42 browser screenshots, eight contact sheets, source snapshots, tar members, and external archive bindings were rehashed. No native fit or fresh reproduction was run. The publisher screenshot-map limitation is recorded in the JSON record for a future source-bound cycle. A first receipt-generation attempt stopped before writing because a manually expanded reviewer hash was wrong; no publication or canonical write occurred.

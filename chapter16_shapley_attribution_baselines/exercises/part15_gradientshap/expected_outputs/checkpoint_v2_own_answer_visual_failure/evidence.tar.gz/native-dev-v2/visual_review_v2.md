# GradientSHAP native visual review v2

## Scope and evidence boundary

- Reviewed the 20 PNGs saved by the passing own-answer learner v2 run at `native-dev-v2/figures` with `view_image` at original resolution.
- The learner completed 126 cells, including 79 code cells, in 64.35 seconds. Native tensors are retained under `figures/native`.
- No scientific payload was recomputed and no source file was edited during this review. The PNG hashes below bind the exact reviewed bytes.
- Figure 15 was additionally inspected in three native-resolution vertical crops. Figures 16, 18 and 19 were inspected in native-resolution detail crops to verify the reported layout defects.

## Exact reviewed PNG inventory

| Figure | Pixels | SHA-256 |
|---|---:|---|
| `01_schedule_prefix.png` | 2036×758 | `13d08cad9644b039ce64c5529bffb595249b915621a90e2682b78e1cc9adfd7c` |
| `02_path_interpolation.png` | 1964×776 | `8c985c0c67adf9cd657b8cb044a3644327cc1bb0995fba9b2f93bd442ed539a8` |
| `03_gradient_controls.png` | 1964×758 | `1623f75668187445e9964ab3b68c23b088acdb9f4d6f9c920b842bddf0eac3c3` |
| `04_relu_samples.png` | 1964×740 | `8cba96523adb409b73b389de006948f6cb12751dc8d0d5f26b3a238e6e1b3cd4` |
| `05_mc_convergence.png` | 1964×758 | `517cdf5b04a4f13bfe6ca58339a129b1057b77e7f6e0557fc6bdb32b36454afd` |
| `06_estimator_controls.png` | 1964×758 | `7e01b288602f7d85aef87ab997439193e3e375c1276cf8269641eec09ddec40a` |
| `07_quadrature_doubling.png` | 1964×758 | `396f9d35355f39b0180fffa78e27f818b6ac40646576ac6f473ff8ef2381d247` |
| `08_background_average.png` | 1964×758 | `afc5ae3cbf3eeb8bc8d037433f6cc042c9c91207e9fd7df05d141f55902a8c69` |
| `09_gaussian_target_shift.png` | 1964×758 | `cb51d5ff11ebb2f75d3baaa5e003d96e86faa2c7d2cef4015240fc7876b74014` |
| `10_path_vs_coalition.png` | 1964×740 | `e1a3541f575611c5d6b044308949aefecb910dee219887bd7cd16059d0dc5bd3` |
| `11_kink_representation.png` | 1964×740 | `8828bb1c26cc3cef705be9a9acbfd28905594f9aa1c03b2ccb3804a91ddaae26` |
| `12_replacement_fixture.png` | 1964×740 | `ac34938cabb50f62565cef6f0deeea84dcf92eebbde9f15413fbed8b06d549ec` |
| `13_threshold_play.png` | 2360×758 | `e1054231e09209f1e0c5ad8cf09a18e58438b36e8d9955874f989d388ca35130` |
| `14_native_overview.png` | 2756×875 | `440cf2f3a42d84f56094ac431276fe0e2224a1ee8bef5ed1e8378716690431e7` |
| `15_allrow_method_map.png` | 2792×3233 | `71945a5053a6f66334c6d9ef07e3fc99c744b0bfa3f60fe134fe679fb941ecb4` |
| `16_fixed_waterfall.png` | 2396×1036 | `72072e6864709128b876739427f055f47df0ee3bb01379f6017a8d9b9a2a8ce6` |
| `17_background_and_noise.png` | 2396×1514 | `789cd34f5befb9213c11ca5e0c0da294a828aea90043b7e2ace72ded44a30bfe` |
| `18_replicates_and_distance.png` | 2324×894 | `9419195318af1a757d4e439c5417967bfbf05ab57374496bcaef89dbe5ac36c4` |
| `19_replacement_curves.png` | 4006×883 | `e50acea902c60786ef3a77614aff0fd7535e34cf48cab464dcddfb3b3762742f` |
| `20_real_recipe_play.png` | 2468×1063 | `14b57325c7f3edb2196a44fc478b95da9797813f46a92a074788494e6f06719a` |

## Per-figure visual findings

| Figure | Status | Labels, math, colors, controls and evidence |
|---|---|---|
| `01_schedule_prefix` | **PASS** | Literal donor indices, source IDs, K=8 shading, alpha symbol and 0–1 scale are readable; heatmap and three alpha streams use distinct encodings. |
| `02_path_interpolation` | **PASS** | Donors, query, interpolated points, alpha colorbar and donor-preserving displacement bars are readable and unclipped. |
| `03_gradient_controls` | **PASS** | Analytic and student affine bars coincide visibly; quadratic student samples lie on the analytic 2z line. Math subscripts render correctly. |
| `04_relu_samples` | **PASS** | The ReLU 0/2 step and quadratic 2-alpha control are visibly distinct; axes, symbols and legends are clear. |
| `05_mc_convergence` | **PASS** | Nested-prefix estimate, ordinary MC SE, target and 1/sqrt(K) reference are separated by color, marker and line style; log axes and powers of two are legible. |
| `06_estimator_controls` | **PASS** | Full-background completeness bars and exact-zero versus finite-ReLU controls are readable; the finite non-closure magnitude is labeled. |
| `07_quadrature_doubling` | **PASS** | The title explicitly rejects an exact-oracle reading; finite path attribution, analytic target, absolute error and doubling drift are distinguishable on the log panel. |
| `08_background_average` | **PASS** | Per-donor path controls agree with analytic values while the mean-donor counterexample differs; labels and value annotations are clear. |
| `09_gaussian_target_shift` | **PASS** | Clean and smoothed targets are separated; ordinary MC SE and residuals against both targets are readable, with sigma math rendered. |
| `10_path_vs_coalition` | **PASS** | Path, q512 and exact coalition credit remain visually distinct; the removal control shows that completeness/necessity do not identify allocation. |
| `11_kink_representation` | **PASS** | Binary-input agreement, graph-route colors and exact discrete Shapley bars are visible; the exact-kink qualification is explicit. |
| `12_replacement_fixture` | **PASS** | All six orders, selected signed order, insertion/deletion endpoints and possible dummy plateau remain visible without clipping. |
| `13_threshold_play` | **PASS** | Editable gate path, three credit methods and local insertion/deletion are readable; the coincident-ranking annotation is unobstructed. |
| `14_native_overview` | **PASS** | All seven models and 15,232 coordinates are declared. Audit MSE uses MPa²; EG-minus-q512 error, ordinary SE and q512-minus-q256 drift use MPa and remain separate. Clean/ridge and shuffled controls are visually obvious; q512 is explicitly approximate. |
| `15_allrow_method_map` | **PASS** | All seven model rows and all 15,232 signed coordinates are retained. Dedicated MPa scales/colorbars, mean/max gaps, feature labels and explanation/audit boundary are readable in full-resolution crops; clean, shuffled and ridge patterns are not selectively culled. |
| `16_fixed_waterfall` | **NEEDS_LAYOUT_FIX** | Scientific content is readable: source 1, model, base/prediction, finite EG reconstruction, ordinary SE and five aligned methods are explicit. The bottom population-limitation note overlaps the left x-axis label. |
| `17_background_and_noise` | **PASS** | All five frozen backgrounds, all 272 rows, base movement, EG error, ordinary SE, quadrature drift, clean-target residual and smoothed-target residual/SE are distinct and unit-labeled. |
| `18_replicates_and_distance` | **NEEDS_LAYOUT_FIX** | Coverage shows three models, 64 predeclared rows, 64 schedules and the nominal reference; the note truthfully says descriptive/approximate and geometry is not density/OOD probability. That note overlaps the second line of the right x-axis label. |
| `19_replacement_curves` | **NEEDS_LAYOUT_FIX** | All 119 audit rows, five retained methods, 100 random orders, insertion/deletion, negative prefixes and the no-superiority limitation are present. The unwrapped coincidence/limitation title expands the PNG to 4006×883, shrinking both panels severely at notebook/page width. |
| `20_real_recipe_play` | **PASS** | Source/model/background/K/sigma/audit status are explicit. Five local explanations, ordinary SE, insertion/deletion and MPa units are readable; coincident native curves remain present rather than culled. |

## Defects requiring a source-coordinated rerun

1. **Figure 16:** move the one-recipe population limitation into reserved title/subtitle space or explicitly reserve bottom margin. Its current `fig.text` collides with `Predicted compressive strength (MPa)`.
2. **Figure 18:** move the coverage/geometry limitation into reserved title/subtitle space or explicitly reserve bottom margin. Its current `fig.text` collides with `(train-standardized feature space)`.
3. **Figure 19:** wrap and shorten the audit qualification inside the intended figure width. The three equivalent pairwise coincidence statements can be stated truthfully as `DeepSHAP = Expected Gradients K=2048 = 512-node path control`, followed on a separate bounded line by the no-superiority limitation.

These are presentation defects. No missing array, selective outcome removal, false unit, model-count mismatch or scientific-result defect was observed in the reviewed PNGs. Figures 16, 18 and 19 should be regenerated from the already persisted payload after the plotting-only correction and reviewed again before publication.

## Plotting-only correction checkpoint for v3

Root authorized three presentation-only changes after the v2 review. The scientific arrays, controls, model set, row set, selected recipe and plotted limits were unchanged.

- `gradientshap_plots.py` SHA-256: `f7369b14f53d0ac3cac2c54efa12ed2b9b799bb2e94336cb0b030b5d585380d0`
- `gradientshap_plots_tests.py` SHA-256: `b5acaabd5d2062a31c8b36c132cd48c5b9e33fc8f8f6e7f04158248a8f31f93a`
- No-fit section gate: 47 passed, 1 explicit native-fit skip, 3 unrelated SHAP `PendingDeprecationWarning` messages, 24.64 seconds.
- `git diff --check` passed for both owned plotting files.

The corrected figures were rendered directly from the immutable v2 `play.pt` and `evaluated.pt` into `layout-fixes-v3`; the model study was not rerun.

| Corrected figure | Pixels | SHA-256 | Review result |
|---|---:|---|---|
| `16_fixed_waterfall.png` | 2396×1028 | `be1ccc8518530a9d7e5e6920de62591ba54aec3b2448eb509a3e6a849c38aa04` | PASS at original and 1200-pixel notebook width; the population limitation is now above the panels and the x-axis label is unobstructed. |
| `18_replicates_and_distance.png` | 2432×884 | `8b30d376203760f12f367cac4818c4bee0db2cf0ca49edea372695e14c00048f` | PASS at original and 1200-pixel notebook width; both lines of the distance label are unobstructed and the diagnostic qualification remains visible. |
| `19_replacement_curves.png` | 2270×883 | `95984d5bcece3ae65587f522ff8c688e8a5a58a5d9c580399ea736ca3abf63b8` | PASS at original and 1200-pixel notebook width; width decreased from 4006 to 2270 pixels and the full coincidence/no-superiority qualification remains readable. |

These corrected-cache hashes are visual QA evidence only. The coordinated v3 learner must generate and bind its own exact PNG bytes from the frozen source set.

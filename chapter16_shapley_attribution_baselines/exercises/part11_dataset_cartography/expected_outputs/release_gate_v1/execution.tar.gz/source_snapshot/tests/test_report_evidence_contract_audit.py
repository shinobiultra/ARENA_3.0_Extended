from scripts.audit_report_evidence_contracts import (
    report_freshness_blockers,
    report_contract_blockers,
    report_evidence_blockers,
    verification_report_records,
)
from arena_ext.verification import build_report_input_manifest, verify_report_input_manifest

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def _valid_lock_report():
    lock = {
        "notebook_id": "section_x",
        "gt_tier": "GT-1",
        "evidence_level": "real_cuda_preflight",
        "claim_scope": "A concrete CUDA preflight claim with baselines, controls, models, datasets, and narrow scope.",
        "controls": ["baseline_metric", "random_direction_control"],
        "expected_metrics": {"accuracy_min": 0.9},
    }
    report = {
        "notebook_id": "section_x",
        "gt_tier": "GT-1",
        "evidence_level": "real_cuda_preflight",
        "claim_scope": lock["claim_scope"],
        "tests_passed": True,
        "accepted": True,
        "known_failures": [],
        "report_inputs": build_report_input_manifest(ROOT, [ROOT / "pyproject.toml"]),
        "metrics": {
            "gpu_evidence": {
                "category": "cuda_section_metric",
                "uses_cuda": True,
                "placeholder_only": False,
                "section_specific_metric_keys": ["accuracy"],
            },
            "gpu_test": {"accuracy": 0.95},
        },
        "baselines": {
            "declared_controls": ["baseline_metric", "random_direction_control"],
            "expected_metrics": {"accuracy_min": 0.9},
        },
        "negative_controls": {"declared_controls": ["random_direction_control"]},
        "ood_tests": {"declared": "required_where_applicable"},
        "models": [{"id": "tiny-model"}],
        "datasets": [{"id": "generated"}],
        "safety_notes": ["No unsafe prompts or raw gated weights."],
    }
    return lock, report


def test_report_contract_accepts_complete_report():
    lock, report = _valid_lock_report()

    assert report_contract_blockers(lock, report) == []


def test_report_contract_flags_placeholder_report():
    lock, report = _valid_lock_report()
    lock["evidence_level"] = "notebook_contract"
    report["evidence_level"] = "notebook_contract"
    report["metrics"]["gpu_evidence"] = {
        "category": "placeholder_only",
        "uses_cuda": False,
        "placeholder_only": True,
        "section_specific_metric_keys": [],
    }
    report["negative_controls"] = {}
    report["known_failures"] = ["metric failed"]

    blockers = report_contract_blockers(lock, report)

    assert "section_x: placeholder evidence_level=notebook_contract" in blockers
    assert "section_x: gpu_evidence.category='placeholder_only'" in blockers
    assert "section_x: gpu_evidence.uses_cuda is not true" in blockers
    assert "section_x: gpu_evidence is placeholder_only" in blockers
    assert "section_x: negative_controls are empty" in blockers
    assert "section_x: accepted report has known_failures" in blockers


def test_report_contract_flags_missing_report_inputs():
    lock, report = _valid_lock_report()
    report.pop("report_inputs")

    blockers = report_contract_blockers(lock, report)

    assert "section_x: report_inputs.files must be a nonempty list" in blockers


def test_report_input_manifest_detects_changed_file(tmp_path):
    source = tmp_path / "input.py"
    source.write_text("value = 1\n")
    manifest = build_report_input_manifest(tmp_path, [source])
    source.write_text("value = 2\n")

    blockers = verify_report_input_manifest(tmp_path, manifest)

    assert "report input hash changed: input.py" in blockers
    assert "report_inputs.combined_sha256 does not match current inputs" in blockers


def test_report_freshness_blockers_prefixes_notebook_id():
    blockers = report_freshness_blockers({"notebook_id": "section_x"})

    assert "section_x: report_inputs.files must be a nonempty list" in blockers


def test_report_contract_flags_expected_metric_regression():
    lock, report = _valid_lock_report()
    report["metrics"]["gpu_test"]["accuracy"] = 0.5

    blockers = report_contract_blockers(lock, report)

    assert any("expected gpu_test.accuracy >= 0.9" in blocker for blocker in blockers)


def test_current_report_evidence_contracts_pass():
    assert report_evidence_blockers() == []


def test_report_record_discovery_includes_docs_evidence_reports():
    report_paths = {record["report_path"].as_posix() for record in verification_report_records()}

    assert any(path.endswith("docs/evidence/ioi_path_patching/verification_report.json") for path in report_paths)
    assert any(path.endswith("docs/evidence/othello_gpt/verification_report.json") for path in report_paths)


def test_cpu_native_model_contract_requires_explicit_device_and_actual_fresh_results():
    import copy
    from scripts.audit_report_evidence_contracts import has_native_cpu_model_evidence
    lock, report = _valid_lock_report()
    lock.update(execution_device='cpu',exercise_metadata={'REQUIRES_GPU':False})
    report['metrics']['gpu_evidence'].update(category='cpu_or_budget_metric',uses_cuda=False)
    report['metrics']['gpu_test'].update(device='cpu',native_model_reloaded=True,actual_learner_passed=True,
        fresh_reproduction_passed=True,own_answer_code_cells=20,fresh_compared_examples=5184,
        fresh_condition_batches=108,fresh_top_token_mismatches=0,fresh_max_logit_error=0.,
        learner_evidence_sha256='bound-by-input-manifest',fresh_evidence_sha256='also-bound-by-input-manifest')
    assert has_native_cpu_model_evidence(lock,report)
    assert report_contract_blockers(lock,report)==[]
    # CPU budget, host information, or a completion flag alone is insufficient.
    mutations={'native_model_reloaded':False,'actual_learner_passed':False,'fresh_reproduction_passed':False,
               'fresh_compared_examples':0,'fresh_condition_batches':0,'fresh_top_token_mismatches':1,
               'fresh_max_logit_error':float('nan'),'learner_evidence_sha256':'','fresh_evidence_sha256':''}
    for key,value in mutations.items():
        broken=copy.deepcopy(report);broken['metrics']['gpu_test'][key]=value
        assert not has_native_cpu_model_evidence(lock,broken), key
        assert report_contract_blockers(lock,broken), key
    for bad_lock in [{**lock,'execution_device':'cuda'},{**lock,'exercise_metadata':{'REQUIRES_GPU':True}}]:
        assert not has_native_cpu_model_evidence(bad_lock,report)
def test_cpu_scratch_model_requires_held_out_refits_and_full_numerical_evidence():
    from copy import deepcopy
    from scripts.audit_report_evidence_contracts import has_native_cpu_model_evidence

    lock = {'execution_device': 'cpu', 'exercise_metadata': {'REQUIRES_GPU': False}}
    measured = dict(
        device='cpu', native_model_retrained=True, native_model_retrained_in_this_report=True,
        native_evidence_reused=False, actual_learner_passed=True, fresh_reproduction_passed=True,
        own_answer_code_cells=40, final_query_count=64, final_used_for_selection=False,
        reference_refits=930, independent_scipy_checks=10, fresh_compared_tensors=1048,
        fresh_compared_elements=16726855, fresh_max_error=0.,
        learner_evidence_sha256='learner-evidence', fresh_evidence_sha256='fresh-evidence',
    )
    report = {'metrics': {'gpu_evidence': {'category': 'cpu_or_budget_metric', 'uses_cuda': False},
                          'gpu_test': measured}}
    assert has_native_cpu_model_evidence(lock, report)
    for key, value in [
        ('native_model_retrained', False), ('native_model_retrained_in_this_report', False),
        ('native_evidence_reused', True), ('actual_learner_passed', False),
        ('fresh_reproduction_passed', False), ('final_query_count', 1),
        ('final_used_for_selection', True), ('reference_refits', 0),
        ('independent_scipy_checks', 0), ('fresh_compared_tensors', 0),
        ('fresh_compared_elements', 0), ('fresh_max_error', 1e-3),
        ('fresh_max_error', float('nan')), ('learner_evidence_sha256', ''),
        ('fresh_evidence_sha256', ''),
    ]:
        broken = deepcopy(report)
        broken['metrics']['gpu_test'][key] = value
        assert not has_native_cpu_model_evidence(lock, broken), key
    assert not has_native_cpu_model_evidence(
        {**lock, 'exercise_metadata': {'REQUIRES_GPU': True}}, report,
    )


def test_datamodel_evidence_distinguishes_heldout_subsets_from_query_targets():
    from copy import deepcopy
    from scripts.audit_report_evidence_contracts import has_native_cpu_model_evidence

    lock = {'execution_device': 'cpu', 'exercise_metadata': {'REQUIRES_GPU': False}}
    measured = dict(
        device='cpu', native_model_retrained=True, native_model_retrained_in_this_report=True,
        native_evidence_reused=False, actual_learner_passed=True, fresh_reproduction_passed=True,
        own_answer_code_cells=31, reference_refits=10753, independent_scipy_checks=10,
        independent_lasso_checks=12, fresh_compared_tensors=263, fresh_compared_elements=5546159,
        fresh_max_error=0., learner_evidence_sha256='bound-input', fresh_evidence_sha256='bound-input',
        heldout_unit='training_subset_model', heldout_model_count=768,
        test_responses_used_for_selection=False, query_image_count=64,
        query_images_used_as_regression_targets=True, query_images_excluded_from_classifier_training=True,
    )
    report = {'metrics': {'gpu_evidence': {'category': 'cpu_or_budget_metric', 'uses_cuda': False},
                          'gpu_test': measured}}
    assert has_native_cpu_model_evidence(lock, report)
    assert 'final_used_for_selection' not in measured
    for key, value in [
        ('native_model_retrained', False), ('native_model_retrained_in_this_report', False),
        ('native_evidence_reused', True), ('heldout_unit', 'image'), ('heldout_model_count', 0),
        ('test_responses_used_for_selection', True), ('query_image_count', 1),
        ('query_images_used_as_regression_targets', False),
        ('query_images_excluded_from_classifier_training', False),
        ('independent_lasso_checks', 0), ('reference_refits', 64), ('fresh_compared_elements', 64),
        ('fresh_max_error', float('nan')), ('fresh_max_error', 1e-3),
    ]:
        broken = deepcopy(report)
        broken['metrics']['gpu_test'][key] = value
        assert not has_native_cpu_model_evidence(lock, broken), key


def test_cartography_evidence_requires_independent_sgd_paths_and_real_selection_controls():
    from copy import deepcopy
    from scripts.audit_report_evidence_contracts import has_native_cpu_model_evidence

    lock = {'execution_device': 'cpu', 'exercise_metadata': {'REQUIRES_GPU': False}}
    measured = dict(
        device='cpu', native_model_retrained=True, native_model_retrained_in_this_report=True,
        native_evidence_reused=False, actual_learner_passed=True, fresh_reproduction_passed=True,
        own_answer_code_cells=30, reference_refits=140, mapping_runs=20, selection_refits=120,
        independent_optimizer_checks=4, independent_numpy_checks=24, separate_training_checks=2,
        optimizer_updates=53550, fresh_compared_tensors=675, fresh_compared_elements=41903198,
        fresh_max_error=0., learner_evidence_sha256='bound-input', fresh_evidence_sha256='bound-input',
        heldout_unit='evaluation_image', heldout_image_count=2620, heldout_split_count=2,
        final_used_for_selection=False, heldout_images_excluded_from_training=True,
        both_logging_conventions_recorded=True, all_retraining_seeds_retained=True,
        class_matched_controls=True, equal_update_control=True,
    )
    report = {'metrics': {'gpu_evidence': {'category': 'cpu_or_budget_metric', 'uses_cuda': False},
                          'gpu_test': measured}}
    assert has_native_cpu_model_evidence(lock, report)
    assert 'independent_scipy_checks' not in measured
    for key, value in [
        ('native_model_retrained', False), ('native_evidence_reused', True),
        ('heldout_unit', 'training_example'), ('heldout_image_count', 0),
        ('heldout_split_count', 1), ('final_used_for_selection', True),
        ('heldout_images_excluded_from_training', False), ('independent_optimizer_checks', 0),
        ('independent_numpy_checks', 0), ('separate_training_checks', 0),
        ('mapping_runs', 0), ('selection_refits', 0), ('reference_refits', 1),
        ('optimizer_updates', 0), ('both_logging_conventions_recorded', False),
        ('all_retraining_seeds_retained', False), ('class_matched_controls', False),
        ('equal_update_control', False), ('fresh_compared_elements', 3000),
        ('fresh_max_error', float('nan')), ('fresh_reproduction_passed', False),
    ]:
        broken = deepcopy(report)
        broken['metrics']['gpu_test'][key] = value
        assert not has_native_cpu_model_evidence(lock, broken), key

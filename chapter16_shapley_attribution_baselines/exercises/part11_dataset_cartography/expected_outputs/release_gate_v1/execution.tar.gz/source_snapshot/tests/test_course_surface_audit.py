import json
from copy import deepcopy

from scripts.audit_course_surface import (
    course_surface_blockers,
    _exercise_notebook_declares_verification_contract,
    _has_direct_experiment_contract,
    _page_has_arena_shape,
    is_extension_section,
    load_config,
)


def test_is_extension_section_tracks_original_additions_and_new_chapters():
    assert is_extension_section("0.6")
    assert is_extension_section("1.6")
    assert is_extension_section("5.1")
    assert is_extension_section("17.1")
    assert not is_extension_section("1.2")
    assert not is_extension_section("4.5")


def test_course_surface_audit_flags_conversion_map_mismatch():
    config = deepcopy(load_config())
    config["conversion_map"]["5.1"]["exercise_dir"] = "wrong_dir"

    blockers = course_surface_blockers(config)

    assert "5.1: conversion_map exercise_dir mismatch" in blockers


def test_course_surface_audit_flags_missing_home_renderer():
    config = deepcopy(load_config())
    chapter = config["chapter_names"][5]
    config["chapter_names"][5] = chapter
    # The live audit covers filesystem presence; this mutation makes sure the
    # fixture still exercises chapter-level checks through the real config.
    blockers = course_surface_blockers(config)

    assert not any("missing instructions/Home.py" in blocker for blocker in blockers)


def test_notebook_verification_contract_detector_requires_visible_gpu_surface(tmp_path):
    notebook_path = tmp_path / "example_exercises.ipynb"
    notebook_path.write_text(
        json.dumps(
            {
                "cells": [
                    {
                        "cell_type": "code",
                        "source": [
                            "def run_gpu_test(max_vram_gb: float = 24.0):\n",
                            "    return json.loads((section_dir / 'verification_report.json').read_text())\n",
                            "\n",
                            "def run_full_experiment(max_vram_gb: float = 24.0):\n",
                            "    return run_gpu_test(max_vram_gb=max_vram_gb)\n",
                        ],
                    }
                ]
            }
        )
    )

    assert _exercise_notebook_declares_verification_contract(notebook_path)

    notebook_path.write_text(json.dumps({"cells": [{"cell_type": "code", "source": []}]}))

    assert not _exercise_notebook_declares_verification_contract(notebook_path)


def test_current_course_surface_passes():
    assert course_surface_blockers() == []


def test_explicit_cpu_first_page_has_runtime_guidance():
    page = "# [12.3] Mini VLM\n## Core Question\n## Learning Objectives\nExercise\ntests.check()\nREQUIRES_GPU = False"
    assert _page_has_arena_shape(page, "12.3", "Mini VLM")
    assert not _page_has_arena_shape(page.replace("REQUIRES_GPU = False", ""), "12.3", "Mini VLM")
    assert _page_has_arena_shape(page.replace("Core Question", "Core question").replace("Learning Objectives", "Learning objectives"), "12.3", "Mini VLM")


def test_separate_publication_requires_validated_outputs_and_complete_execution(tmp_path):
    from pathlib import Path
    import shutil
    root=Path(__file__).resolve().parents[1]
    section=root/'chapter5_modern_architectures/exercises/part5_diffusion_language_models'
    source=next(section.glob('*_exercises.ipynb'))
    for name in (source.name,'lesson.md','execute_learner.py','solutions.py','publish_study.py','study_release.py'):
        shutil.copyfile(section/name,tmp_path/name)
    notebook=tmp_path/source.name
    assert _has_direct_experiment_contract(notebook)
    publisher=tmp_path/'publish_study.py';original=publisher.read_text()
    publisher.write_text('# A named file cannot stand in for validated publication\n')
    assert not _has_direct_experiment_contract(notebook)
    publisher.write_text(original)
    delegate=tmp_path/'study_release.py'
    delegate.write_text(delegate.read_text().replace('execute_learner.py','unrelated.py'))
    assert not _has_direct_experiment_contract(notebook)


def test_direct_learner_contract_requires_own_methods_answers_and_experiments(tmp_path):
    from pathlib import Path
    import shutil
    root = Path(__file__).resolve().parents[1]
    section = root / "chapter9_alignment_interpretability/exercises/part1_refusal_directions_safe_steering"
    source = next(section.glob("*_exercises.ipynb"))
    for name in (source.name, "lesson.md", "execute_learner.py", "solutions.py"):
        shutil.copyfile(section / name, tmp_path / name)
    notebook = tmp_path / source.name
    original = json.loads(notebook.read_text())
    assert _has_direct_experiment_contract(notebook)
    no_answers = deepcopy(original)
    for cell in no_answers["cells"]:
        if cell["cell_type"] == "markdown":
            cell["source"] = "".join(cell["source"]).replace("<summary>Solution</summary>", "<summary>Placeholder</summary>")
    notebook.write_text(json.dumps(no_answers))
    assert not _has_direct_experiment_contract(notebook)
    no_figures = deepcopy(original)
    for cell in no_figures["cells"]:
        if cell["cell_type"] == "code":
            cell["source"] = "".join(cell["source"]).replace(".savefig(", ".unrelated(")
    notebook.write_text(json.dumps(no_figures))
    assert not _has_direct_experiment_contract(notebook)
    notebook.write_text(json.dumps(original))
    (tmp_path / "execute_learner.py").write_text("# A filename alone is not an execution path\n")
    assert not _has_direct_experiment_contract(notebook)


def test_native_reproduction_requires_validation_actual_model_and_called_entrypoint(tmp_path):
    from pathlib import Path
    import shutil
    root=Path(__file__).resolve().parents[1]
    section=root/'chapter11_representation_geometry/exercises/part1_pca_svd_geometry_controls'
    source=next(section.glob('*_exercises.ipynb'))
    for name in (source.name,'lesson.md','execute_learner.py','solutions.py','publish_study.py','geometry_cuda.py'):
        shutil.copyfile(section/name,tmp_path/name)
    notebook=tmp_path/source.name
    assert _has_direct_experiment_contract(notebook)
    delegate=tmp_path/'geometry_cuda.py';original=delegate.read_text()
    for old,new in [('validate_learner(','unrelated('),('AutoModelForCausalLM.from_pretrained(','AutoModelForCausalLM.unrelated(')]:
        delegate.write_text(original.replace(old,new))
        assert not _has_direct_experiment_contract(notebook)
    delegate.write_text(original)
    source=tmp_path/'solutions.py';source.write_text(source.read_text().replace('fresh=reproduce(','fresh=unrelated('))
    assert not _has_direct_experiment_contract(notebook)


def test_das_reproduction_requires_visible_swap_native_continuation_and_hook_oracle(tmp_path):
    from pathlib import Path
    import shutil

    root = Path(__file__).resolve().parents[1]
    section = root / "chapter11_representation_geometry/exercises/part3_causal_abstraction_das"
    source = next(section.glob("*_exercises.ipynb"))
    for name in (source.name, "lesson.md", "execute_learner.py", "solutions.py",
                 "publish_study.py", "das_reproduction.py"):
        shutil.copyfile(section / name, tmp_path / name)
    notebook = tmp_path / source.name
    assert _has_direct_experiment_contract(notebook)
    delegate = tmp_path / "das_reproduction.py"
    original = delegate.read_text()
    mutations = [
        ("validate_learner(learner)", "unrelated(learner)"),
        ("AutoModelForCausalLM.from_pretrained(", "AutoModelForCausalLM.unrelated("),
        ("cache = capture_native(", "cache = unrelated("),
        ("hook = full_forward_intervention(", "hook = unrelated("),
        ('methods["subspace_interchange"](', 'methods["unrelated"]('),
        ('methods["continue_native"](', 'methods["unrelated"]('),
    ]
    for old, new in mutations:
        assert old in original, f"The mutation must target an actual call: {old}"
        delegate.write_text(original.replace(old, new))
        assert not _has_direct_experiment_contract(notebook), old
    delegate.write_text(original)
    entrypoint = tmp_path / "solutions.py"
    original_entrypoint = entrypoint.read_text()
    assert "fresh = reproduce(" in original_entrypoint
    entrypoint.write_text(original_entrypoint.replace("fresh = reproduce(", "fresh = unrelated("))
    assert not _has_direct_experiment_contract(notebook)


def test_plain_cpu_runtime_guidance_accepts_singular_and_plural():
    page = '# [11.4] Concept Erasure\n# Introduction\n## Content & Learning Objectives\nExercise\ntests.check()\nThe examples run on CPU.'
    assert _page_has_arena_shape(page, '11.4', 'Concept Erasure')
    assert _page_has_arena_shape(page.replace('examples run', 'example runs'), '11.4', 'Concept Erasure')
    assert not _page_has_arena_shape(page.replace('run on CPU', 'show a plot'), '11.4', 'Concept Erasure')


def test_erasure_reproduction_requires_refits_native_calls_and_matched_controls(tmp_path):
    from pathlib import Path
    import shutil

    root = Path(__file__).resolve().parents[1]
    section = root / 'chapter11_representation_geometry/exercises/part4_concept_erasure'
    source = next(section.glob('*_exercises.ipynb'))
    for name in [source.name, 'lesson.md', 'execute_learner.py', 'solutions.py',
                 'publish_study.py', 'erasure_reproduction.py']:
        shutil.copyfile(section / name, tmp_path / name)
    notebook = tmp_path / source.name
    assert _has_direct_experiment_contract(notebook)
    delegate = tmp_path / 'erasure_reproduction.py'
    original = delegate.read_text()
    for old, new in [
        ('validate_learner(learner)', 'unrelated(learner)'),
        ('AutoModelForCausalLM.from_pretrained(', 'AutoModelForCausalLM.unrelated('),
        ('capture_native(model,', 'unrelated(model,'),
        ('full_forward_intervention(model,', 'unrelated(model,'),
        ('= construct_conditions(', '= unrelated('),
        ('compare_fitted_conditions(fresh_bank', 'unrelated(fresh_bank'),
        ('= infer(model,', '= unrelated(model,'),
        ('m.fit_leace(', 'm.unrelated('),
        ('m.fit_binary_probe(', 'm.unrelated('),
        ('m.fit_orthogonal_eraser(', 'm.unrelated('),
        ('continue_native(model,', 'unrelated(model,'),
        ('replacement = edit(', 'replacement = unrelated('),
        ('m.matched_random_edit(', 'm.unrelated('),
        ('m.apply_eraser(', 'm.unrelated('),
    ]:
        assert old in original, f'The mutation must target an actual scientific call: {old}'
        delegate.write_text(original.replace(old, new))
        assert not _has_direct_experiment_contract(notebook), old
    delegate.write_text(original)
    entry = tmp_path / 'solutions.py'
    assert 'fresh = run(' in entry.read_text()
    entry.write_text(entry.read_text().replace('fresh = run(', 'fresh = unrelated('))
    assert not _has_direct_experiment_contract(notebook)


def test_ccs_contract_follows_capture_refits_calibration_and_native_metrics(tmp_path):
    import shutil
    from pathlib import Path
    from chapter11_representation_geometry.exercises.part5_contrast_consistent_search.build_notebooks import lesson_cells

    section = Path(__file__).resolve().parents[1] / 'chapter11_representation_geometry/exercises/part5_contrast_consistent_search'
    notebook = tmp_path / '11.5_exercises.ipynb'
    notebook.write_text(json.dumps({'cells': lesson_cells()}))
    files = ['lesson.md', 'execute_learner.py', 'solutions.py', 'publish_study.py',
             'ccs_reproduction.py', 'ccs_native.py', 'ccs_study.py']
    for name in files:
        shutil.copyfile(section / name, tmp_path / name)
    assert _has_direct_experiment_contract(notebook)
    original_notebook = notebook.read_text()
    assert '.savefig(' in original_notebook
    notebook.write_text(original_notebook.replace('.savefig(', '.unrelated('))
    assert not _has_direct_experiment_contract(notebook)
    notebook.write_text(original_notebook)
    mutations = {
        'solutions.py': ['fresh = reproduce('],
        'ccs_reproduction.py': ['validate_learner(', 'compare_nested(', 'validate_complete_result(',
                               'native.load_model(', 'native.capture_pairs(', 'native.check_capture(',
                               'study.fit_reporters(', 'study.calibrate_reporters(', 'study.reporter_scores(',
                               'study.evaluate_reporters(', 'study.summarize_native_outputs('],
        'ccs_native.py': ['AutoModelForCausalLM.from_pretrained(', 'model.transformer(', 'model.lm_head(',
                          'expected = direct.logits'],
        'ccs_study.py': ['m.fit_pair_centering(', 'm.fit_ccs_restarts(', 'm.select_restart(',
                         'm.fit_difference_pca(', 'fit_binary_probe(', 'torch.randn(',
                         'm.calibrate_orientation(', 'm.paired_probabilities(', 'nm.paired_opinion_change(',
                         'nm.model_answer_metrics('],
    }
    # The oracle mutation changes the model call itself, not a metric label.
    mutations['ccs_native.py'][-1] = 'direct = model('
    for name, calls in mutations.items():
        path = tmp_path / name
        original = path.read_text()
        for call in calls:
            assert call in original, (name, call)
            replacement = call.rsplit('(', 1)[0].rsplit('.', 1)[0] + '.unrelated(' if '.' in call else 'unrelated('
            if call.startswith('fresh = '):
                replacement = 'fresh = unrelated('
            elif call.startswith('direct = '):
                replacement = 'direct = unrelated('
            path.write_text(original.replace(call, replacement))
            assert not _has_direct_experiment_contract(notebook), (name, call)
        path.write_text(original)
def test_data_attribution_contract_requires_actual_refits_and_all_comparisons(tmp_path):
    from pathlib import Path
    from scripts.audit_course_surface import _has_direct_experiment_contract

    root = Path(__file__).resolve().parents[1]
    section = root / 'chapter16_shapley_attribution_baselines/exercises/part9_influence_and_tracin'
    notebook = tmp_path / '16.9_Influence_Functions_and_TracIn_exercises.ipynb'
    names = ['16.9_Influence_Functions_and_TracIn_exercises.ipynb', 'lesson.md',
             'execute_learner.py', 'solutions.py', 'publish_study.py', 'reproduce_native.py',
             'attribution_study.py', 'attribution_data.py', 'attribution_play.py']
    for name in names:
        (tmp_path / name).write_bytes((section / name).read_bytes())
    assert _has_direct_experiment_contract(notebook)
    mutations = {
        'reproduce_native.py': ['prepare_study(', 'evaluate_final(', 'compare(', 'scipy_logistic_optimum('],
        'attribution_study.py': ['m.fit_weighted_logistic(', 'm.sgd_trace(', 'm.upweight_influence(',
                                 'm.trace_loss_reductions(', 'm.ghost_linear_products(', 'm.class_matched_removals('],
        'attribution_data.py': ['zipfile.ZipFile('],
        'attribution_play.py': ['m.fit_weighted_logistic('],
    }
    for name, calls in mutations.items():
        path = tmp_path / name
        original = path.read_text()
        for call in calls:
            path.write_text(original.replace(call, 'missing_required_operation('))
            assert not _has_direct_experiment_contract(notebook), (name, call)
            path.write_text(original)


def test_datamodel_contract_follows_subset_training_selection_and_reproduction(tmp_path):
    from pathlib import Path
    from scripts.audit_course_surface import _has_direct_experiment_contract

    section = Path(__file__).resolve().parents[1] / 'chapter16_shapley_attribution_baselines/exercises/part10_datamodels'
    notebook = tmp_path / '16.10_Datamodels_exercises.ipynb'
    names = ['16.10_Datamodels_exercises.ipynb', 'lesson.md', 'execute_learner.py',
             'solutions.py', 'publish_study.py', 'reproduce_native.py', 'run_native.py',
             'datamodel_study.py', 'datamodel_data.py', 'datamodel_methods.py']
    for name in names:
        (tmp_path / name).write_bytes((section / name).read_bytes())
    assert _has_direct_experiment_contract(notebook)
    mutations = {
        'reproduce_native.py': ['native_state = run(', 'compare('],
        'run_native.py': ['data = load_data(', 'study.prepare_study(', 'study.evaluate_study(',
                          'study.deletion_play(', 'scipy_logistic_optimum(', ').fit('],
        'datamodel_study.py': ['fit_weighted_logistic(', 'methods.fit_datamodel_path(',
                              'methods.sample_subsets(', 'methods.matched_random_removals(',
                              'methods.correct_class_margins('],
        'datamodel_data.py': ['arrays = source_arrays('],
        'datamodel_methods.py': ['fit = fit_lasso(', 'updated = soft_threshold(', 'residual = lasso_kkt('],
    }
    for name, calls in mutations.items():
        path = tmp_path / name
        original = path.read_text()
        for call in calls:
            assert call in original, (name, call)
            replacement = ').unrelated(' if call == ').fit(' else 'missing_required_operation('
            path.write_text(original.replace(call, replacement))
            assert not _has_direct_experiment_contract(notebook), (name, call)
            path.write_text(original)


def test_cartography_contract_requires_training_logging_selection_and_refits(tmp_path):
    from pathlib import Path
    from scripts.audit_course_surface import _has_direct_experiment_contract

    section = Path(__file__).resolve().parents[1] / 'chapter16_shapley_attribution_baselines/exercises/part11_dataset_cartography'
    notebook = tmp_path / '16.11_Dataset_Cartography_exercises.ipynb'
    names = ['16.11_Dataset_Cartography_exercises.ipynb', 'lesson.md', 'execute_learner.py',
             'solutions.py', 'publish_study.py', 'reproduce_native.py', 'run_native.py',
             'cartography_methods.py', 'cartography_study.py', 'cartography_data.py',
             'cartography_reference.py']
    for name in names:
        (tmp_path / name).write_bytes((section / name).read_bytes())
    assert _has_direct_experiment_contract(notebook)
    mutations = {
        'reproduce_native.py': ['native_state = run(', 'compare('],
        'run_native.py': ['mapping = map_training_data(', 'prepared = retrain_selections(',
                          'evaluated = evaluate_study(', 'play = retraining_play(',
                          'implementation.train_ensemble(', 'np.testing.assert_allclose('],
        'cartography_methods.py': ['torch.autograd.grad(', 'align_epoch(torch.cat(',
                                   'probabilities.std(', 'value.add_('],
        'cartography_study.py': ['methods.train_ensemble(', 'methods.select_indices(',
                                'methods.matched_random_indices(', 'methods.evaluate_models('],
        'cartography_data.py': ['arrays = source_arrays('],
        'cartography_reference.py': ['optimizer.step('],
    }
    for name, calls in mutations.items():
        path = tmp_path / name
        original = path.read_text()
        for call in calls:
            assert call in original, (name, call)
            replacement = 'missing_required_operation(torch.cat(' if call == 'align_epoch(torch.cat(' else 'missing_required_operation('
            path.write_text(original.replace(call, replacement))
            assert not _has_direct_experiment_contract(notebook), (name, call)
            path.write_text(original)

<!-- ARENA:cell markdown -->
# [11.4] Concept Erasure

# Introduction

You remove a probe's direction. That probe now predicts nothing useful. Have
you removed the concept—or only broken one way of reading it?

We will construct four points for which this distinction is exact. You will
implement a closed-form eraser, compare it with an independent constrained
optimizer, and ask what its guarantee actually covers. Then we will erase a
name-role representation in frozen GPT-2 and inspect both its answers and an
unrelated object task. The useful result is a comparison of representations,
readouts and behavior, not a single “erasure score”.

## Content & Learning Objectives

### 1️⃣ Specify what “removed” means

> - Distinguish a disabled probe from a class of disabled predictors.
> - Relate class means to centered cross-covariance.
> - Keep convex probe loss separate from thresholded accuracy.

### 2️⃣ Derive the least-distorting affine edit

> - Whiten only directions with empirical variance.
> - Implement orthogonal removal and the LEACE oblique eraser.
> - Preserve the mean and compare with an independent optimization oracle.

### 3️⃣ Try to recover the information

> - Refit a probe after changing its inputs.
> - Exhibit nonlinear information that survives linear guardedness.
> - Separate fitting-set properties from new-data behavior.

### 4️⃣ Erase a role inside a real transformer

> - Fit the eraser and the evaluation probe on separate sentences.
> - Compare actual next-token answers with matched controls.
> - Measure representation distortion and unrelated-task damage.

## Setup

The exact examples run on CPU in seconds. Allow roughly 90 minutes to implement
and investigate them, followed by two hours for the transformer study. Complete
a function before running its immediate tests, or use its own solution dropdown
when you need help. PyTorch and plotting use the repository's `uv` environment.

<!-- ARENA:cell code -->
```python
import itertools
import json
import math
import os
import sys
from pathlib import Path
from types import SimpleNamespace

import matplotlib.pyplot as plt
import numpy as np
import torch as t
import torch.nn.functional as F
from IPython import get_ipython

if get_ipython() is not None:
    get_ipython().run_line_magic("matplotlib", "inline")
root_dir = next(p for p in [Path.cwd(), *Path.cwd().parents] if (p / "chapter11_representation_geometry").exists())
if str(root_dir) not in sys.path:
    sys.path.append(str(root_dir))
from chapter11_representation_geometry.exercises.part4_concept_erasure import erasure_methods_tests as tests
assets_dir = Path(os.environ.get("ARENA_ERASURE_OUTPUT_DIRECTORY", "erasure_outputs"))
assets_dir.mkdir(parents=True, exist_ok=True)
t.set_num_threads(4)
plt.style.use("seaborn-v0_8-whitegrid")
```

<!-- ARENA:cell markdown -->
# 1️⃣ What should an eraser remove?

## Four points, two variables

Let $U$ be an unrelated side variable taking values $-2$ and $2$, and let
$Z\in\{-1,1\}$ be the concept. Every combination occurs equally often. The
representation is $X=(U,U+Z)$. A linear readout recovers $Z$ exactly by subtracting
the first coordinate from the second.

Suppose you project away that readout's normal, $(-1,1)$. The edited points lie
on the line $x_1=x_2$, so the old subtraction returns zero. But the points are now
$(U+Z/2,U+Z/2)$: both coordinates still contain some of $Z$. We will measure that
remaining information rather than judging only the original probe.

An alternative target is to make every class centroid equal. With one-hot
labels, the $j$th column of the cross-covariance is

$$\operatorname{Cov}(X,1_{Z=j})=P(Z=j)\left(E[X\mid Z=j]-E[X]\right).$$

Thus zero cross-covariance equalizes the centroids. For affine predictors trained
with loss convex in their logits, Jensen's inequality then makes a constant
predictor optimal on this distribution. This is *linear guardedness* in the
[LEACE paper](https://proceedings.neurips.cc/paper_files/paper/2023/file/d066d21c619d0a78c5b557fa3291a8f4-Paper-Conference.pdf).
It is a claim about a predictor class, loss and distribution. It does not say
that the two class distributions are identical. We will build a counterexample.

<!-- ARENA:cell markdown -->
### Exercise 1 — Compute the paired moments

> ```yaml
> Difficulty: 🔴🔴⚪⚪⚪
> Importance: 🔵🔵🔵🔵⚪
>
> You should spend 10–15 minutes on this exercise.
> ```

Return the two means, the population covariance of `x`, and its cross-covariance with `z`. Use denominator `n`, center both arrays, and preserve their dtype and device. For our binary example a single signed label column has the same removable span as centered two-column one-hot labels.

<details>
<summary>Help</summary>

Write `xc = x - x.mean(0)` and `zc = z - z.mean(0)`. Cross-covariance has shape `[representation_width, concept_width]`; it is not `zc.T @ xc`.

</details>

<details>
<summary>Expected output</summary>

For the four points, the covariance is `[[4, 4], [4, 5]]` and the signed-label cross-covariance is `[[0], [1]]`. Translating the representations changes the mean but neither covariance.

</details>

<details>
<summary>Solution</summary>

```python
def centered_statistics(x: t.Tensor, z: t.Tensor) -> dict:
    """Population second moments of paired rows, preserving their affine means."""
    if x.ndim != 2 or z.ndim != 2 or len(x) != len(z) or len(x) < 2:
        raise ValueError("Use at least two paired rows in X and Z.")
    if not x.is_floating_point() or not z.is_floating_point():
        raise ValueError("Use floating representations and floating one-hot labels.")
    if x.dtype != z.dtype or x.device != z.device or not x.shape[1] or not z.shape[1]:
        raise ValueError("Use nonempty features with matching dtype and device.")
    if not t.isfinite(x).all() or not t.isfinite(z).all():
        raise ValueError("Moments require finite data.")
    mean_x, mean_z = x.mean(0), z.mean(0)
    xc, zc = x - mean_x, z - mean_z
    return dict(mean_x=mean_x, mean_z=mean_z,
                covariance=xc.T @ xc / len(x), cross_covariance=xc.T @ zc / len(x))
```

</details>

<!-- ARENA:cell code -->
```python
def centered_statistics(x: t.Tensor, z: t.Tensor) -> dict:
    """Population second moments of paired rows, preserving their affine means."""
    raise NotImplementedError()

tests.test_centered_moments(SimpleNamespace(**globals()))
```

<!-- ARENA:cell code -->
```python
u, concept = t.tensor(list(itertools.product((-2., 2.), (-1., 1.))), dtype=t.float64).T
points = t.stack((u, u + concept), 1)
concept_column = concept[:, None]
labels = (concept > 0).long()
old_normal = t.tensor([-1., 1.], dtype=t.float64)
old_normal /= old_normal.norm()
old_probe_erasure = dict(mean=points.mean(0), left=old_normal[:, None], right=old_normal[None], rank=1)
print("Every point (U, Z, x1, x2):")
for side, z, row in zip(u, concept, points):
    print(f"U={side:+.0f}, Z={z:+.0f}: ({row[0]:+.0f}, {row[1]:+.0f})")
```

<!-- ARENA:cell markdown -->
# 2️⃣ Derive a small edit

## The constraint fixes the nullspace, not the destination

For an affine edit $r(x)=Px+b$, the erasure constraint is $P\Sigma_{XZ}=0$.
Orthogonally removing the column span of $\Sigma_{XZ}$ satisfies it. But this
only chooses one possible destination for the edited points.

In our example, the removable span is the second coordinate. Setting that
coordinate to zero loses both $Z$ and the useful contribution $U$. Replacing it
with the first coordinate also removes $Z$, but preserves $U$. Before computing
anything, predict the mean squared edit distance in those two cases.

Whitening will let us solve the general problem. In directions where empirical
variance is zero, there is nothing to rescale. Track that support explicitly;
blindly dividing by tiny eigenvalues can turn a small new-data difference into
a large intervention.

<!-- ARENA:cell markdown -->
### Exercise 2 — Whiten the empirical support

> ```yaml
> Difficulty: 🔴🔴🔴⚪⚪
> Importance: 🔵🔵🔵🔵⚪
>
> You should spend 10–15 minutes on this exercise.
> ```

Diagonalize a symmetric positive-semidefinite covariance. Return whitening and unwhitening matrices, the numerical rank, eigenvalues and cutoff. By default use `width * machine_epsilon` as the relative eigenvalue cutoff. Reject materially negative or nonsymmetric inputs; tiny numerical negatives may be clipped.

<details>
<summary>Help</summary>

For an eigenvalue `s > cutoff`, use `1 / sqrt(s)` to whiten and `sqrt(s)` to unwhiten. Use zero in both matrices outside the retained support. Their product is the support projector, not necessarily the identity.

</details>

<details>
<summary>Expected output</summary>

For `diag([9, 1, 0])`, whitening is `diag([1/3, 1, 0])`, unwhitening is `diag([3, 1, 0])`, and the retained rank is two.

</details>

<details>
<summary>Solution</summary>

```python
def psd_whitener(covariance: t.Tensor, rcond: float | None = None) -> dict:
    """Whiten on the empirical support and preserve an explicit numerical rank."""
    if covariance.ndim != 2 or covariance.shape[0] != covariance.shape[1] or not len(covariance):
        raise ValueError("The covariance must be a nonempty square matrix.")
    if not covariance.is_floating_point() or not t.isfinite(covariance).all():
        raise ValueError("Use a finite real floating covariance.")
    eps = t.finfo(covariance.dtype).eps
    relative = len(covariance) * eps if rcond is None else rcond
    if relative < 0 or not t.isfinite(t.tensor(relative)):
        raise ValueError("The relative eigenvalue cutoff must be finite and nonnegative.")
    scale = float(covariance.abs().max())
    if not t.allclose(covariance, covariance.T, atol=10 * len(covariance) * eps * scale, rtol=0):
        raise ValueError("The covariance must be symmetric.")
    eigenvalues, vectors = t.linalg.eigh((covariance + covariance.T) / 2)
    if eigenvalues.min() < -10 * len(covariance) * eps * eigenvalues.abs().max():
        raise ValueError("The covariance must be positive semidefinite.")
    eigenvalues = eigenvalues.clamp_min(0)
    threshold = eigenvalues.max() * relative
    keep = eigenvalues > threshold
    roots = t.where(keep, eigenvalues.sqrt(), 0)
    inverse_roots = t.zeros_like(roots)
    inverse_roots[keep] = 1 / roots[keep]
    return dict(whiten=(vectors * inverse_roots) @ vectors.T,
                unwhiten=(vectors * roots) @ vectors.T,
                rank=int(keep.sum()), eigenvalues=eigenvalues, threshold=float(threshold))
```

</details>

<!-- ARENA:cell code -->
```python
def psd_whitener(covariance: t.Tensor, rcond: float | None=None) -> dict:
    """Whiten on the empirical support and preserve an explicit numerical rank."""
    raise NotImplementedError()

tests.test_psd_support_and_rejection(SimpleNamespace(**globals()))
```

<!-- ARENA:cell markdown -->
### Exercise 3 — Remove the cross-covariance span

> ```yaml
> Difficulty: 🔴🔴⚪⚪⚪
> Importance: 🔵🔵🔵🔵⚪
>
> You should spend 10–15 minutes on this exercise.
> ```

Compute a thin orthonormal basis `Q` for the nonzero left singular space of the cross-covariance. Store the edit as `left=Q`, `right=Q.T`, plus the training mean and rank. This is a baseline with a precise guarantee, unlike removing whichever classifier happened to fit well.

<details>
<summary>Help</summary>

The actual retained map is `I - left @ right`. A zero-rank cross-covariance should produce factors of shapes `[width, 0]` and `[0, width]`.

</details>

<details>
<summary>Expected output</summary>

For our example the rank-one removable span is the second coordinate. Its projector is `diag([0, 1])`.

</details>

<details>
<summary>Solution</summary>

```python
def fit_orthogonal_eraser(x: t.Tensor, z: t.Tensor, svd_atol: float = 1e-10) -> dict:
    """Remove the cross-covariance span, rather than a fitted classifier's normal."""
    if svd_atol < 0 or not t.isfinite(t.tensor(svd_atol)):
        raise ValueError("Use a finite nonnegative singular-value cutoff.")
    stats = centered_statistics(x, z)
    u, singular, _ = t.linalg.svd(stats["cross_covariance"], full_matrices=False)
    basis = u[:, singular > svd_atol]
    return dict(mean=stats["mean_x"], left=basis, right=basis.T,
                rank=basis.shape[1], cross_singular_values=singular)
```

</details>

<!-- ARENA:cell code -->
```python
def fit_orthogonal_eraser(x: t.Tensor, z: t.Tensor, svd_atol: float=1e-10) -> dict:
    """Remove the cross-covariance span, rather than a fitted classifier's normal."""
    raise NotImplementedError()

orthogonal = fit_orthogonal_eraser(points, concept_column)
t.testing.assert_close(orthogonal["left"] @ orthogonal["right"], t.diag(t.tensor([0., 1.], dtype=t.float64)))
print("The orthogonal baseline removes exactly the cross-covariance span.")
```

<!-- ARENA:cell markdown -->
## Keep the predictable part of each coordinate

Write $W=(\Sigma_{XX}^{1/2})^+$ for whitening on the empirical support, and let
$Q$ span the columns of $W\Sigma_{XZ}$. In whitened coordinates the unwanted
correlation lives in an orthogonal subspace. Remove that component, map the
removed amount back to the original coordinates, and subtract it:

$$r(x)=x-W^+QQ^TW(x-\mu),\qquad \mu=E[X].$$

The two thin factors are $L=W^+Q$ and $R=Q^TW$, so $P=I-LR$.
Generally $L\ne R^T$: this is an oblique projection. The loss being minimized
is the expected squared displacement of the original data, subject to the
zero-cross-covariance constraint. In a singular problem, this identifies the
edit on the observed support; behavior outside that support needs care.

We will also expose a covariance-shrinkage option for the native experiment.
With positive shrinkage, whitening uses a spherical covariance mixture. That
changes the fitting objective; it must not be described as the unregularized
empirical optimum. Leave it at zero for the following exact exercises.

<!-- ARENA:cell markdown -->
### Exercise 4 — Fit LEACE from the paired moments

> ```yaml
> Difficulty: 🔴🔴🔴⚪⚪
> Importance: 🔵🔵🔵🔵⚪
>
> You should spend 15–20 minutes on this exercise.
> ```

Construct `L` and `R` using your moments and whitening function. Use the same explicitly named SVD cutoff throughout. Return both factors and diagnostics, including the covariance support rank. The optional spherical covariance mixture is `(1-alpha) * covariance + alpha * trace(covariance)/width * I`.

<details>
<summary>Help</summary>

Perform SVD on `W @ cross_covariance`, not on raw activations or on the fitted probe coefficients. The factor shapes are `[width, removed_rank]` and `[removed_rank, width]`. Keep the original training mean.

</details>

<details>
<summary>Expected output</summary>

The four-point fitted map is `[[1, 0], [1, 0]]`. An independent KKT constrained-quadratic solve should agree on a separate random full-rank problem.

</details>

<details>
<summary>Solution</summary>

```python
def fit_leace(x: t.Tensor, z: t.Tensor, *, covariance_rcond: float | None = None,
              svd_atol: float = 1e-10, shrinkage: float = 0.0) -> dict:
    """Fit the whiten-project-unwhiten eraser as two thin factors.

    shrinkage=0 is the empirical least-squares solution. Positive shrinkage
    uses a spherical covariance surrogate; it is a different fitting objective.
    """
    if not 0 <= shrinkage <= 1 or svd_atol < 0 or not t.isfinite(t.tensor(svd_atol)):
        raise ValueError("Use shrinkage in [0, 1] and a finite nonnegative SVD cutoff.")
    stats = centered_statistics(x, z)
    covariance = stats["covariance"]
    eye = t.eye(len(covariance), dtype=x.dtype, device=x.device)
    surrogate = (1 - shrinkage) * covariance + shrinkage * covariance.trace() / len(covariance) * eye
    geometry = psd_whitener(surrogate, covariance_rcond)
    whiten, unwhiten = geometry["whiten"], geometry["unwhiten"]
    u, singular, _ = t.linalg.svd(whiten @ stats["cross_covariance"], full_matrices=False)
    basis = u[:, singular > svd_atol]
    return dict(mean=stats["mean_x"], left=unwhiten @ basis, right=basis.T @ whiten,
                rank=basis.shape[1], covariance_rank=geometry["rank"],
                covariance_threshold=geometry["threshold"],
                cross_singular_values=singular, shrinkage=shrinkage)
```

</details>

<!-- ARENA:cell code -->
```python
def fit_leace(x: t.Tensor, z: t.Tensor, *, covariance_rcond: float | None=None, svd_atol: float=1e-10, shrinkage: float=0.0) -> dict:
    """Fit the whiten-project-unwhiten eraser as two thin factors.

    shrinkage=0 is the empirical least-squares solution. Positive shrinkage
    uses a spherical covariance surrogate; it is a different fitting objective.
    """
    raise NotImplementedError()

tests.test_independent_kkt_optimality(SimpleNamespace(**globals()))
```

<!-- ARENA:cell markdown -->
### Exercise 5 — Apply the affine edit

> ```yaml
> Difficulty: 🔴🔴⚪⚪⚪
> Importance: 🔵🔵🔵🔵⚪
>
> You should spend 10–15 minutes on this exercise.
> ```

Apply the fitted low-rank factors to new row vectors. Keep the unconditional mean, avoid changing the input tensor, and multiply in an order that uses the thin intermediate rather than materializing a dense matrix.

<details>
<summary>Help</summary>

The column-vector equation becomes `x - ((x - mean) @ right.T) @ left.T` for row vectors. Preserve the fit's dtype and device; convert explicitly at the transformer boundary later.

</details>

<details>
<summary>Expected output</summary>

LEACE maps `(U, U+Z)` to `(U, U)`, with average squared edit distance 1. Orthogonal covariance removal costs 5. Applying either exact projector twice gives the same result.

</details>

<details>
<summary>Solution</summary>

```python
def apply_eraser(x: t.Tensor, eraser: dict) -> t.Tensor:
    """Apply an affine low-rank edit to row vectors without an O(d squared) map."""
    left, right, mean = eraser["left"], eraser["right"], eraser["mean"]
    if (x.ndim != 2 or mean.shape != (x.shape[1],) or left.ndim != 2 or right.ndim != 2
            or left.shape[0] != x.shape[1] or right.shape != (left.shape[1], x.shape[1])):
        raise ValueError("Use X[n,d], mean[d], left[d,k], and right[k,d].")
    if any(a.dtype != x.dtype or a.device != x.device for a in (left, right, mean)):
        raise ValueError("Apply the eraser in its fitted dtype and device.")
    return x - ((x - mean) @ right.T) @ left.T
```

</details>

<!-- ARENA:cell code -->
```python
def apply_eraser(x: t.Tensor, eraser: dict) -> t.Tensor:
    """Apply an affine low-rank edit to row vectors without an O(d squared) map."""
    raise NotImplementedError()

tests.test_four_point_optimal_edit(SimpleNamespace(**globals()))
tests.test_affine_mean_preservation_and_identity(SimpleNamespace(**globals()))
tests.test_singular_covariance_and_randomized_invariants(SimpleNamespace(**globals()))
```

<!-- ARENA:cell markdown -->
## See where the points went

The same colors identify the concept in every panel. Each arrow joins an
original point to its edited position. The old-probe projection puts all points
on the diagonal, yet the two class centroids still differ along that diagonal.
LEACE puts corresponding concept values at the same side-variable position.
The orthogonal baseline also merges the classes, but discards a predictable
part of the second coordinate.

<!-- ARENA:cell code -->
```python
exact_erasers = {
    "No intervention": dict(mean=points.mean(0), left=t.empty(2, 0, dtype=t.float64), right=t.empty(0, 2, dtype=t.float64), rank=0),
    "Remove old probe": old_probe_erasure,
    "Orthogonal covariance": fit_orthogonal_eraser(points, concept_column),
    "LEACE": fit_leace(points, concept_column),
}
exact_edits = {name: apply_eraser(points, fit) for name, fit in exact_erasers.items()}
fig, axes = plt.subplots(2, 2, figsize=(10, 8), constrained_layout=True)
for ax, (name, edited) in zip(axes.flat, exact_edits.items()):
    for label, color in [(0, "#487d9b"), (1, "#bf4c28")]:
        mask = labels == label
        ax.scatter(points[mask, 0], points[mask, 1], facecolors="none", edgecolors=color, s=85, label=f"Z={2*label-1:+d} original")
        ax.scatter(edited[mask, 0], edited[mask, 1], color=color, s=32, label=f"Z={2*label-1:+d} edited")
        for start, end in zip(points[mask], edited[mask]):
            ax.annotate("", xy=end.numpy(), xytext=start.numpy(), arrowprops=dict(arrowstyle="->", color=color, alpha=.65))
    covariance = centered_statistics(edited, concept_column)["cross_covariance"].norm()
    ax.set(title=f"{name}: cross-covariance norm {covariance:.2f}", xlim=(-3.5, 3.5), ylim=(-3.5, 3.5), xlabel="First coordinate", ylabel="Second coordinate", aspect="equal")
axes[0, 0].legend(fontsize=7)
fig.savefig(assets_dir / "erasure_four_point_geometry.png", dpi=160)
plt.show()
```

<!-- ARENA:cell code -->
```python
comparison_edits = {**exact_edits, "Erase everything": points.mean(0).expand_as(points)}
fig, axes = plt.subplots(1, 3, figsize=(12, 4), constrained_layout=True)
for ax, values, title in [
    (axes[0], [float(centered_statistics(x, concept_column)["cross_covariance"].norm()) for x in comparison_edits.values()], "Remaining cross-covariance"),
    (axes[1], [float((x - points).square().sum(1).mean()) for x in comparison_edits.values()], "Mean squared edit distance"),
    (axes[2], [float((x[:, 0] - u).square().mean()) for x in comparison_edits.values()], "Damage to side coordinate U"),
]:
    ax.bar(range(len(values)), values, color=["#8a9eb2", "#8a9eb2", "#487d9b", "#bf4c28", "#8a9eb2"])
    ax.set_xticks(range(len(values)), list(comparison_edits), rotation=35, ha="right")
    ax.set(title=title)
fig.savefig(assets_dir / "erasure_constraint_and_distortion.png", dpi=160)
plt.show()
```

<!-- ARENA:cell markdown -->
<details>
<summary>Interpretation — why is the oblique projection smaller?</summary>

Orthogonal projection minimizes distance to a *fixed destination subspace*.
Our constraint does not fix that subspace: it requires the class-mean difference
to lie in the removed map's nullspace. The first coordinate predicts part of
the second, so retaining that prediction gives a different destination with
less average distortion. Removing everything also satisfies the constraint,
but destroys the side variable. A successful constraint alone is insufficient.

</details>

<!-- ARENA:cell code -->
```python
from chapter11_representation_geometry.exercises.part4_concept_erasure.reference_parity import compare_reference
reference_comparison = compare_reference(SimpleNamespace(**globals()))
(assets_dir / "author_parity.json").write_text(json.dumps(reference_comparison, indent=2) + "\n")
```

<!-- ARENA:cell markdown -->
The comparison loads hash-checked author code from a pinned commit and checks
full-rank, singular and translated examples. It explicitly disables the author
package's covariance shrinkage and trace regularization, so it compares the
same empirical objective. Library defaults are not interchangeable scientific
settings. The separate KKT test gives an oracle that does not reuse whitening.

<!-- ARENA:cell markdown -->
# 3️⃣ Try to read the concept again

## A new probe gets a new direction

Do not evaluate an eraser solely by applying a probe trained on the original
activations. Its input distribution has changed. Fit a fresh predictor and keep
its intercept: erasure does not make an imbalanced class prior disappear.

For these small balanced examples, constant prediction has log loss `log(2)`.
The following probe standardizes using its training rows only, then minimizes a
convex binary logistic objective with a small, explicit L2 penalty. It returns
the coefficient in the original coordinate system. Its thresholded accuracy
and log loss are separate measurements.

<!-- ARENA:cell markdown -->
### Exercise 6 — Refit and evaluate a logistic probe

> ```yaml
> Difficulty: 🔴🔴🔴⚪⚪
> Importance: 🔵🔵🔵🔵⚪
>
> You should spend 15–20 minutes on this exercise.
> ```

Implement the training-only standardization, scalar intercept and stable logistic objective. Only the probe coefficient and intercept belong in LBFGS. Return a coefficient and intercept usable directly on unstandardized new rows, plus the fitting history. Evaluation must report both log loss and the fraction of correct thresholded predictions.

<details>
<summary>Help</summary>

If the standardized predictor is `(x-mean)/scale @ w + b`, the original-coordinate coefficient is `w/scale` and its intercept is `b - mean @ (w/scale)`. An empty or single-class training task cannot support the intended comparison.

</details>

<details>
<summary>Expected output</summary>

The old probe has loss `log(2)` after its direction is removed, but a new probe improves that loss. After the exact LEACE edit, the constant logistic predictor is optimal on these four points.

</details>

<details>
<summary>Solution</summary>

```python
def fit_binary_probe(x: t.Tensor, labels: t.Tensor, *, l2: float = 1e-3,
                     steps: int = 150) -> dict:
    """Refit a convex logistic probe from training rows only, including an intercept."""
    if x.ndim != 2 or labels.shape != (len(x),) or len(x) < 2:
        raise ValueError("Use one binary label for each representation row.")
    if not t.all((labels == 0) | (labels == 1)) or labels.unique().numel() != 2:
        raise ValueError("Training must contain both binary classes.")
    if not x.is_floating_point() or not t.isfinite(x).all() or l2 < 0 or steps < 1:
        raise ValueError("Use finite floating activations and a valid optimization budget.")
    mean = x.mean(0)
    scale = (x - mean).square().mean(0).sqrt()
    scale = t.where(scale > t.finfo(x.dtype).eps, scale, 1)
    standardized = (x - mean) / scale
    target = labels.to(dtype=x.dtype, device=x.device)
    w = t.zeros(x.shape[1], dtype=x.dtype, device=x.device, requires_grad=True)
    b = target.mean().logit().detach().requires_grad_(True)
    optimizer = t.optim.LBFGS([w, b], max_iter=steps, tolerance_grad=1e-10,
                             tolerance_change=1e-12, line_search_fn="strong_wolfe")
    history = []

    def closure():
        optimizer.zero_grad()
        loss = F.binary_cross_entropy_with_logits(standardized @ w + b, target)
        objective = loss + l2 * w.square().sum() / 2
        objective.backward()
        history.append(float(objective.detach()))
        return objective

    optimizer.step(closure)
    coefficient = w.detach() / scale
    intercept = b.detach() - mean @ coefficient
    return dict(coefficient=coefficient, intercept=intercept, training_mean=mean,
                training_scale=scale, objective_history=history, l2=l2)

def evaluate_binary_probe(x: t.Tensor, labels: t.Tensor, probe: dict) -> dict:
    """Keep convex log loss and thresholded accuracy as different measurements."""
    logits = x @ probe["coefficient"] + probe["intercept"]
    loss = F.binary_cross_entropy_with_logits(logits, labels.to(logits))
    return dict(log_loss=float(loss), accuracy=float(((logits > 0) == labels.bool()).double().mean()),
                probabilities=logits.sigmoid(), logits=logits)
```

</details>

<!-- ARENA:cell code -->
```python
def fit_binary_probe(x: t.Tensor, labels: t.Tensor, *, l2: float=0.001, steps: int=150) -> dict:
    """Refit a convex logistic probe from training rows only, including an intercept."""
    raise NotImplementedError()

def evaluate_binary_probe(x: t.Tensor, labels: t.Tensor, probe: dict) -> dict:
    """Keep convex log loss and thresholded accuracy as different measurements."""
    raise NotImplementedError()

tests.test_probe_removal_requires_refitting(SimpleNamespace(**globals()))
tests.test_nonlinear_information_and_loss_boundary(SimpleNamespace(**globals()))
```

<!-- ARENA:cell code -->
```python
old_probe = dict(coefficient=t.tensor([-1., 1.], dtype=t.float64), intercept=t.tensor(0., dtype=t.float64))
probe_results = {}
for name, edited in exact_edits.items():
    fresh_probe = fit_binary_probe(edited, labels, l2=1e-4)
    probe_results[name] = dict(old=evaluate_binary_probe(edited, labels, old_probe), fresh=evaluate_binary_probe(edited, labels, fresh_probe))
fig, ax = plt.subplots(figsize=(8, 4), constrained_layout=True)
for offset, field, color in [(-.18, "old", "#8a9eb2"), (.18, "fresh", "#bf4c28")]:
    ax.bar(np.arange(len(probe_results)) + offset, [row[field]["log_loss"] for row in probe_results.values()], width=.35, label=f"{field.capitalize()} probe", color=color)
ax.axhline(math.log(2), color="#182c3a", linestyle="--", label="Constant class-prior predictor")
ax.set_xticks(range(len(probe_results)), list(probe_results), rotation=20, ha="right")
ax.set(ylabel="Binary log loss (lower is better)", title="Breaking one probe does not erase a predictor class")
ax.legend(fontsize=8)
fig.savefig(assets_dir / "erasure_probe_refitting.png", dpi=160)
plt.show()
```

<!-- ARENA:cell markdown -->
## A guarantee can hold while information survives

Consider representations at `-2, +2` for class 1 and `-1, +1` for class 0.
Both class means are zero. LEACE correctly makes no edit. Squaring the
representation still reveals the class perfectly.

There is a subtler point: the hard threshold `x > 1.5` is correct on three of
four examples. Its log loss is worse than constant prediction. The theorem
concerns losses convex in affine logits; 0–1 classification loss is not one of
them. Inspect both panels before deciding what “chance performance” means.

<!-- ARENA:cell code -->
```python
nonlinear_x = t.tensor([[-2.], [2.], [-1.], [1.]], dtype=t.float64)
nonlinear_labels = t.tensor([1, 1, 0, 0])
nonlinear_z = F.one_hot(nonlinear_labels, 2).double()
nonlinear_edit = apply_eraser(nonlinear_x, fit_leace(nonlinear_x, nonlinear_z))
slopes = t.linspace(-3, 3, 151, dtype=t.float64)
logits = slopes[:, None] * (nonlinear_edit[:, 0] - 1.5)[None]
losses = F.binary_cross_entropy_with_logits(logits, nonlinear_labels.double().expand_as(logits), reduction="none").mean(1)
accuracies = ((logits > 0) == nonlinear_labels.bool()).double().mean(1)
fig, axes = plt.subplots(1, 2, figsize=(10, 4), constrained_layout=True)
axes[0].plot(slopes, losses, label="Affine threshold family", color="#bf4c28")
axes[0].axhline(math.log(2), color="#8a9eb2", linestyle="--", label="Constant loss")
axes[0].set(xlabel="Slope in slope × (x − 1.5)", ylabel="Binary log loss", title="The constant predictor minimizes convex loss")
axes[0].legend(fontsize=8)
axes[1].plot(slopes, accuracies, color="#487d9b", label="Hard linear threshold")
axes[1].axhline(.5, color="#8a9eb2", linestyle="--", label="Class-prior accuracy")
axes[1].axhline(float(((nonlinear_edit[:, 0].square() > 2.5) == nonlinear_labels.bool()).double().mean()), color="#bf4c28", linestyle=":", label="Quadratic readout")
axes[1].set(xlabel="Same affine slope", ylabel="Accuracy", ylim=(0, 1.05), title="Different predictor/loss, different conclusion")
axes[1].legend(fontsize=8)
fig.savefig(assets_dir / "erasure_nonlinear_counterexample.png", dpi=160)
plt.show()
```

<!-- ARENA:cell markdown -->
## Try It Yourself — change the predictable side contribution

Change `SIDE_SCALE` and `COUPLING`. Predict how the orthogonal baseline's
collateral distortion changes before rerunning. The complete pairing of each
side value with both concepts keeps the two latent variables independent in
this finite dataset. This play alters the mechanism, not only the plot limits.
Afterwards, add an independent constant third coordinate and verify that the
affine eraser preserves it without trying to invert its zero variance.

<!-- ARENA:cell code -->
```python
SIDE_SCALE, COUPLING = 2., 1.5
side_grid = t.linspace(-SIDE_SCALE, SIDE_SCALE, 31, dtype=t.float64).repeat_interleave(2)
play_concept = t.tensor([-1., 1.], dtype=t.float64).repeat(31)
play_x = t.stack((side_grid, COUPLING * side_grid + play_concept), 1)
play_edits = {
    "No intervention": play_x,
    "Orthogonal covariance": apply_eraser(play_x, fit_orthogonal_eraser(play_x, play_concept[:, None])),
    "LEACE": apply_eraser(play_x, fit_leace(play_x, play_concept[:, None])),
}
fig, axes = plt.subplots(1, 2, figsize=(10, 4), constrained_layout=True)
for name, edited in play_edits.items():
    axes[0].scatter(edited[:, 0], edited[:, 1], s=10, alpha=.65, label=name)
axes[0].set(xlabel="First coordinate", ylabel="Second coordinate", title=f"Side scale {SIDE_SCALE}, coupling {COUPLING}")
axes[0].legend(fontsize=7)
axes[1].bar(list(play_edits), [float((x - play_x).square().sum(1).mean()) for x in play_edits.values()], color=["#8a9eb2", "#487d9b", "#bf4c28"])
axes[1].set(ylabel="Mean squared displacement", title="Same concept constraint, different edit cost")
axes[1].tick_params(axis="x", rotation=15)
fig.savefig(assets_dir / "erasure_covariance_play.png", dpi=160)
plt.show()
```

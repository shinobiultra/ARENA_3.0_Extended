"""Execute the current CCS draft from its own answers in a fresh notebook kernel."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time

import nbformat
from nbclient import NotebookClient

ROOT = Path(__file__).resolve().parents[3]
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from chapter11_representation_geometry.exercises.part5_contrast_consistent_search.build_notebooks import (
    complete_learner,
    lesson_cells,
)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def execute(directory):
    directory.mkdir(parents=True, exist_ok=False)
    names = ["lesson.md", "ccs_methods.py", "ccs_methods_tests.py", "reference_parity.py",
             "build_notebooks.py", "execute_learner.py"]
    hashes = {}
    for name in names:
        path = HERE / name
        relative = str(path.relative_to(ROOT))
        snapshot = directory / "source_snapshot" / relative
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        snapshot.write_bytes(path.read_bytes())
        hashes[relative] = digest(path)
    started = time.perf_counter()
    state = {"status": "RUNNING", "source_inputs": hashes,
             "completed_from_own_answers": True, "native_model_executed": False}
    notebook = None

    def save():
        state["elapsed_seconds"] = time.perf_counter() - started
        (directory / "execution.json").write_text(json.dumps(state, indent=2) + "\n")

    def finished(cell, cell_index, **kwargs):
        state["last_completed_cell"] = cell_index
        save()

    save()
    try:
        draft = {"cells": lesson_cells(), "metadata": {"kernelspec": {
            "name": "python3", "display_name": "Python 3", "language": "python"}},
            "nbformat": 4, "nbformat_minor": 5}
        notebook = nbformat.reads(json.dumps(complete_learner(draft)), as_version=4)
        NotebookClient(notebook, timeout=1800, kernel_name="python3", on_cell_executed=finished,
                       resources={"metadata": {"path": str(ROOT)}}).execute(
            env={**os.environ, "ARENA_CCS_OUTPUT_DIRECTORY": str(directory / "figures")})
        state.update(status="PASS", cells=len(notebook.cells),
                     code_cells=sum(cell.cell_type == "code" for cell in notebook.cells),
                     embedded_figures=sum("image/png" in output.get("data", {})
                                          for cell in notebook.cells for output in cell.get("outputs", [])),
                     figures={p.name: digest(p) for p in sorted((directory / "figures").glob("*.png"))})
    except BaseException as error:
        state.update(status="FAIL", error=str(error))
        raise
    finally:
        state["changed_sources"] = [name for name, checksum in hashes.items() if digest(ROOT / name) != checksum]
        if state["changed_sources"]:
            state["status"] = "FAIL"
        if notebook is not None:
            nbformat.write(notebook, directory / "completed_learner.ipynb")
        save()
    if state["status"] != "PASS":
        raise ValueError("Learner source changed during execution.")
    print(json.dumps({key: value for key, value in state.items() if key not in {"source_inputs", "figures"}}, indent=2))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-directory", type=Path, required=True)
    execute(parser.parse_args().output_directory.resolve())

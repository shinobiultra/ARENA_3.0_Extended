<!-- ARENA:cell markdown -->
# [11.5] Contrast-Consistent Search

# Introduction

You have a frozen language model and a collection of questions. You can inspect
its activations, but you do not give your fitting algorithm the correct answers.
Could it discover a useful way to separate the answers anyway?

Consider two prompts: `Was the film enjoyable? Answer: Yes` and
`Was the film enjoyable? Answer: No`. A reporter assigning a score to each
statement should give opposite answers to the pair. It should also make a
decision instead of assigning both statements a score of one half. These two
requirements define a short optimization problem called **Contrast-Consistent
Search (CCS)**. You will implement it, see it find a feature, and then make an
independent feature satisfy exactly the same requirements.

The aim is to distinguish finding structure from identifying what that structure
means. Keep three questions in mind: **what did the algorithm fit, which way
does its score point, and what evidence identifies the feature?**

## Content & Learning Objectives

### 1️⃣ Build a contrast pair

> - Track answer-token offsets separately from variation between questions.
> - Fit centering on training data and apply it unchanged to new data.

### 2️⃣ Learn a reporter without fitting labels

> - Implement both terms of the original CCS objective.
> - Connect its scalar loss to visible probabilities and failure cases.
> - Fit independent restarts and select using their unlabelled training loss.

### 3️⃣ Find out what was learned

> - Construct a target and an unrelated distractor with equally good solutions.
> - Separate numerical sign conventions from labelled semantic orientation.
> - Compare CCS with a paired-difference principal component and random directions.

## Setup

This foundation runs on CPU. Allow roughly two hours for the derivations,
implementation and investigations. The notebook is currently a development
draft: the native-model stage and full lesson publication are still to come.
Complete each function before running its tests. Use the help and solution
dropdowns when useful, and predict the next plot before displaying it.

<!-- ARENA:cell code -->
```python
import itertools
import json
import math
import os
import sys
from collections.abc import Sequence
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
from torch import Tensor
from IPython import get_ipython

if get_ipython() is not None:
    get_ipython().run_line_magic("matplotlib", "inline")
root_dir = next(p for p in [Path.cwd(), *Path.cwd().parents] if (p / "chapter11_representation_geometry").exists())
if str(root_dir) not in sys.path:
    sys.path.append(str(root_dir))
from chapter11_representation_geometry.exercises.part5_contrast_consistent_search import ccs_methods_tests as tests
assets_dir = Path(os.environ.get("ARENA_CCS_OUTPUT_DIRECTORY", "ccs_outputs"))
assets_dir.mkdir(parents=True, exist_ok=True)
torch.set_num_threads(4)
plt.style.use("seaborn-v0_8-whitegrid")

def save_figure(figure, name):
    figure.savefig(assets_dir / name, dpi=160, bbox_inches="tight")
    plt.show()

def _check_pairs(plus: Tensor, minus: Tensor) -> None:
    if plus.ndim != 2 or plus.shape != minus.shape or min(plus.shape) == 0:
        raise ValueError("Paired activations must have matching nonempty (examples, features) shapes.")
    if plus.dtype != minus.dtype or plus.device != minus.device:
        raise ValueError("Both branches must have the same dtype and device.")
    if not plus.is_floating_point() or not torch.isfinite(plus).all() or not torch.isfinite(minus).all():
        raise ValueError("Activations must be finite floating-point tensors.")

def _check_scores_labels(scores: Tensor, labels: Tensor) -> None:
    if scores.ndim != 1 or scores.shape != labels.shape or len(scores) == 0:
        raise ValueError("Provide equally sized nonempty score and label vectors.")
    if not torch.isfinite(scores).all() or ((scores < 0) | (scores > 1)).any():
        raise ValueError("Scores must lie in [0, 1].")
    if ((labels != 0) & (labels != 1)).any():
        raise ValueError("Labels must be binary.")
```

<!-- ARENA:cell markdown -->
# 1️⃣ What makes the two activations different?

## A representation whose coordinates we understand

Let $Y$ be the answer we care about and $S$ an independent distractor. Each takes
values $-1$ or $+1$. Let $U$ be content shared by both members of a pair. Use
every combination of $(Y,S,U)$ equally often, and construct

$$x^+=(8,Y,3S,U),\qquad x^-=(-8,-Y,-3S,U).$$

The first coordinate only identifies the proposed answer. It is always positive
for the plus branch, regardless of whether that answer is correct. The second
coordinate is a useful target feature. The third tracks a distractor, and the
fourth does not reverse across the pair. We deliberately put both a useful and
a misleading answer-dependent feature into this representation. This makes
their availability explicit; it does not assume every language model has them.

Before fitting anything, write down the mean of each branch. A single pooled
mean is zero and removes neither answer offset. Separate means remove that
offset while retaining variation between questions. We will use mean-only
centering, matching the default of the original demonstration code.

<!-- ARENA:cell code -->
```python
target_sign, distractor_sign, content = torch.tensor(
    list(itertools.product((-1.0, 1.0), repeat=3)), dtype=torch.float64
).T
plus_raw = torch.stack((torch.full_like(target_sign, 8), target_sign, 3 * distractor_sign, content), dim=-1)
minus_raw = torch.stack((torch.full_like(target_sign, -8), -target_sign, -3 * distractor_sign, content), dim=-1)
target_labels = (target_sign > 0).long()
distractor_labels = (distractor_sign > 0).long()
print("Each branch:", tuple(plus_raw.shape), "— examples × features")
print("Plus mean:", plus_raw.mean(0).tolist())
print("Minus mean:", minus_raw.mean(0).tolist())
```

<!-- ARENA:cell markdown -->
### Exercise 1 — Fit and apply branch centering

> ```yaml
> Difficulty: 🔴🔴⚪⚪⚪
> Importance: 🔵🔵🔵🔵⚪
>
> You should spend 10–15 minutes on this exercise.
> ```

Return the two training means, each with shape `[features]`. Then apply
those fitted means to both branches of any split. Do not modify the original
activations. In particular, the application function must not estimate a new
mean from the data passed to it.

<details>
<summary>Help</summary>

Use `.mean(0)` separately. Test-time centering would answer a different, transductive question: it uses the unlabelled evaluation distribution.

</details>

<details>
<summary>Expected output</summary>

Training means after centering are zero. The held-out shift in the test remains visible instead of being silently removed.

</details>

<details>
<summary>Solution</summary>

```python
def fit_pair_centering(plus: Tensor, minus: Tensor) -> dict[str, Tensor]:
    """Fit separate branch means on training data; there is no scale normalization."""
    _check_pairs(plus, minus)
    return {"plus_mean": plus.detach().mean(0), "minus_mean": minus.detach().mean(0)}
def apply_pair_centering(
    plus: Tensor, minus: Tensor, centering: dict[str, Tensor]
) -> tuple[Tensor, Tensor]:
    """Apply fitted means to any split, without refitting on that split."""
    _check_pairs(plus, minus)
    if any(centering[key].shape != (plus.shape[1],) for key in ("plus_mean", "minus_mean")):
        raise ValueError("A training mean must have one value per feature.")
    return plus - centering["plus_mean"], minus - centering["minus_mean"]
```

</details>

<!-- ARENA:cell code -->
```python
def fit_pair_centering(plus: Tensor, minus: Tensor) -> dict[str, Tensor]:
    """Fit separate branch means on training data; there is no scale normalization."""
    raise NotImplementedError()

def apply_pair_centering(plus: Tensor, minus: Tensor, centering: dict[str, Tensor]) -> tuple[Tensor, Tensor]:
    """Apply fitted means to any split, without refitting on that split."""
    raise NotImplementedError()

tests.test_pair_centering(fit_pair_centering, apply_pair_centering)
print("Training centering and held-out shift checks passed!")
```

<!-- ARENA:cell code -->
```python
centering = fit_pair_centering(plus_raw, minus_raw)
plus, minus = apply_pair_centering(plus_raw, minus_raw, centering)
fig, axes = plt.subplots(1, 2, figsize=(11.2, 4.2))
for branch, matrix, marker in [("Plus", plus_raw, "o"), ("Minus", minus_raw, "s")]:
    axes[0].scatter(matrix[:, 0], matrix[:, 1], marker=marker, s=90, alpha=.7, label=branch)
axes[0].set(xlabel="Answer-token coordinate", ylabel="Target coordinate", title="Raw: branch identity is easy")
axes[0].legend()
for label, color in [(0, "#d65f5f"), (1, "#277da8")]:
    use = target_labels == label
    axes[1].scatter(plus[use, 1], plus[use, 2], s=110, c=color, label=f"Target Y={2 * label - 1:+}")
axes[1].set(xlabel="Target coordinate Y", ylabel="Distractor coordinate 3S", title="Centered plus branch: two independent features")
axes[1].legend(loc="upper center", fontsize=9)
fig.tight_layout()
save_figure(fig, "ccs_contrast_geometry.png")
```

<!-- ARENA:cell markdown -->
<details>
<summary>Interpretation — why do only four points appear on the right?</summary>

The two values of $U$ overlap when we display only the target and distractor
coordinates. No examples were dropped. The distractor is exactly balanced within
each target class. A vertical boundary reads $Y$; a horizontal boundary reads
$S$. Both features will reverse between the plus and minus branches.

</details>

# 2️⃣ Turn consistency into an objective

For each branch, an affine reporter produces
$p^\pm=\sigma(w^\top x^\pm+b)$. Here $p^+$ is a score for the plus statement,
not yet a reliably oriented probability that the question's correct answer is
plus. Define the original loss for one pair as

$$L_\mathrm{cons}=(p^++p^--1)^2,\qquad
L_\mathrm{conf}=\min(p^+,p^-)^2.$$

Average their sum over questions. At $(p^+,p^-)=(1/2,1/2)$, consistency alone is
perfect but neither statement has been selected. At $(0,0)$, confidence alone
is perfect but the two statements are both rejected. The combined objective
prefers opposite, confident predictions. It has no term referring to $Y$.

These equations are from [Burns et al.'s CCS method](https://arxiv.org/html/2212.03827v2).
The reporter parameters change; the representation that supplies its input does
not. In a transformer study this means freezing the pretrained model.

<!-- ARENA:cell markdown -->
### Exercise 2 — Compute both CCS losses

> ```yaml
> Difficulty: 🔴🔴⚪⚪⚪
> Importance: 🔵🔵🔵🔵⚪
>
> You should spend 10–15 minutes on this exercise.
> ```

Implement the loss for probabilities shaped `[examples]`, or
`[examples, restarts]` when fitting independent reporters together. Average over
examples only. Return `(total, consistency, confidence)`. Reject shape mismatch
instead of allowing broadcasting to compare every plus example with every minus
example.

<details>
<summary>Help</summary>

Use `torch.minimum` before squaring. Averaging over restarts here would rescale the independent optimization problems.

</details>

<details>
<summary>Expected output</summary>

Opposite confident pairs have loss 0; two half scores give .25; two zero scores give 1. The independent analytic-gradient check also passes.

</details>

<details>
<summary>Solution</summary>

```python
def ccs_loss(p_plus: Tensor, p_minus: Tensor) -> tuple[Tensor, Tensor, Tensor]:
    """Original loss, consistency and confidence, averaged over examples only.

    Inputs are (examples,) or (examples, independent_reporters). Returning one
    loss per reporter makes batching equivalent to fitting each independently.
    """
    if p_plus.ndim not in (1, 2) or p_plus.shape != p_minus.shape or p_plus.shape[0] == 0:
        raise ValueError("Probabilities must have matching nonempty shapes; broadcasting is forbidden.")
    if any(not torch.isfinite(p).all() or ((p < 0) | (p > 1)).any() for p in (p_plus, p_minus)):
        raise ValueError("Probabilities must be finite and lie in [0, 1].")
    consistency = (p_plus + p_minus - 1).square().mean(0)
    confidence = torch.minimum(p_plus, p_minus).square().mean(0)
    return consistency + confidence, consistency, confidence
```

</details>

<!-- ARENA:cell code -->
```python
def ccs_loss(p_plus: Tensor, p_minus: Tensor) -> tuple[Tensor, Tensor, Tensor]:
    """Original loss, consistency and confidence, averaged over examples only.

    Inputs are (examples,) or (examples, independent_reporters). Returning one
    loss per reporter makes batching equivalent to fitting each independently.
    """
    raise NotImplementedError()

tests.test_ccs_loss_values(ccs_loss)
tests.test_ccs_loss_gradient(ccs_loss)
print("Exact loss values and independent gradient checks passed!")
```

<!-- ARENA:cell code -->
```python
grid = torch.linspace(0, 1, 181, dtype=torch.float64)
pp, pm = torch.meshgrid(grid, grid, indexing="xy")
total, consistency, confidence = ccs_loss(pp.reshape(1, -1), pm.reshape(1, -1))
fig, axes = plt.subplots(1, 3, figsize=(12.8, 3.8))
for ax, values, title in zip(axes, [consistency, confidence, total], ["Consistency", "Confidence", "Combined loss"]):
    heat = ax.imshow(values.reshape(181, 181), origin="lower", extent=[0, 1, 0, 1], cmap="magma", aspect="equal")
    ax.plot([0, 1], [1, 0], color="white", linewidth=1, alpha=.6)
    ax.scatter([0, .5, 1], [0, .5, 1], facecolors="none", edgecolors="#5be7c4", s=65)
    ax.set(xlabel="Plus score", ylabel="Minus score", title=title)
    fig.colorbar(heat, ax=ax, shrink=.8)
fig.suptitle("Neither loss term is enough on its own", y=1.04)
fig.tight_layout()
save_figure(fig, "ccs_loss_landscape.png")
```

<!-- ARENA:cell markdown -->
<details>
<summary>Interpretation — is the loss unchanged if we flip every score?</summary>

Not for arbitrary soft scores. $(.8,.6)$ gives $.52$, while $(.2,.4)$ gives
$.20$. The confidence term prefers smaller scores when consistency is imperfect.
On the exact consistency line $p^++p^-=1$, however, the two orientations have
equal loss. Neither of its two confident endpoints has a preferred semantic
meaning. Do not turn this ambiguity into an incorrect global symmetry claim.

Another useful check: the best constant equal score is $.4$, with total loss
$.2$. Differentiate $(2p-1)^2+p^2$ to verify it. Lowish loss alone does not show
that a reporter has learned different answers for different questions.

</details>

<!-- ARENA:cell markdown -->
### Exercise 3 — Combine the two statement scores

> ```yaml
> Difficulty: 🔴🔴⚪⚪⚪
> Importance: 🔵🔵🔵🔵⚪
>
> You should spend 10–15 minutes on this exercise.
> ```

Compute $\tilde p=\tfrac12(p^++1-p^-)$, returning it along with the
two branch probabilities. Support a single weight vector and a matrix whose
rows are independent reporters. This averaging makes disagreement between the
branches visible rather than replacing one by the other's complement.

<details>
<summary>Help</summary>

For many reporters, `plus @ weight.T` has shape `[examples, reporters]`. Adding the corresponding bias vector broadcasts only over examples.

</details>

<details>
<summary>Expected output</summary>

Swapping the branches complements the averaged score. Negating the affine parameters also complements it, even though the original soft loss need not stay equal.

</details>

<details>
<summary>Solution</summary>

```python
def paired_probabilities(
    plus: Tensor, minus: Tensor, weight: Tensor, bias: Tensor
) -> tuple[Tensor, Tensor, Tensor]:
    """Return averaged positive-answer scores and the two branch probabilities.

    A vector weight gives one reporter; (reporters, features) gives many.
    A score is not semantically oriented until a separate orientation is chosen.
    """
    _check_pairs(plus, minus)
    if weight.ndim not in (1, 2) or weight.shape[-1] != plus.shape[-1]:
        raise ValueError("Reporter weights must end in the activation feature dimension.")
    expected_bias = () if weight.ndim == 1 else (weight.shape[0],)
    if bias.shape != expected_bias:
        raise ValueError("Bias must be scalar for one reporter or one value per reporter.")
    p_plus = (plus @ weight.T + bias).sigmoid() if weight.ndim == 2 else (plus @ weight + bias).sigmoid()
    p_minus = (minus @ weight.T + bias).sigmoid() if weight.ndim == 2 else (minus @ weight + bias).sigmoid()
    return (p_plus + 1 - p_minus) / 2, p_plus, p_minus
```

</details>

<!-- ARENA:cell code -->
```python
def paired_probabilities(plus: Tensor, minus: Tensor, weight: Tensor, bias: Tensor) -> tuple[Tensor, Tensor, Tensor]:
    """Return averaged positive-answer scores and the two branch probabilities.

    A vector weight gives one reporter; (reporters, features) gives many.
    A score is not semantically oriented until a separate orientation is chosen.
    """
    raise NotImplementedError()

tests.test_paired_inference(paired_probabilities)
tests.test_two_feature_counterexample(paired_probabilities, ccs_loss)
print("Paired inference and independent-feature counterexample passed!")
```

<!-- ARENA:cell code -->
```python
known_reporters = {
    "Read target Y": torch.tensor([0., 15., 0., 0.], dtype=plus.dtype),
    "Read distractor S": torch.tensor([0., 0., 5., 0.], dtype=plus.dtype),
    "Read shared content U": torch.tensor([0., 0., 0., 15.], dtype=plus.dtype),
    "Read answer offset": torch.tensor([2., 0., 0., 0.], dtype=plus.dtype),
}
fig, axes = plt.subplots(1, 2, figsize=(12.2, 4.6))
rows, names, losses, accuracies = [], [], [], []
for name, weight in known_reporters.items():
    xp, xm = (plus_raw, minus_raw) if name == "Read answer offset" else (plus, minus)
    score, p, m = paired_probabilities(xp, xm, weight, torch.tensor(0., dtype=plus.dtype))
    rows.append(score.numpy()); names.append(name)
    losses.append(float(ccs_loss(p, m)[0]))
    accuracies.append(float(((score > .5) == target_labels).double().mean()))
heat = axes[0].imshow(np.array(rows), vmin=0, vmax=1, cmap="RdBu", aspect="auto")
axes[0].set(yticks=range(4), yticklabels=names, xticks=range(8), xlabel="Question index", title="Averaged plus score")
fig.colorbar(heat, ax=axes[0], shrink=.75)
axes[1].scatter(losses, accuracies, s=90, c=["#277da8", "#e08b35", "#8e69b3", "#777777"])
for name, loss, accuracy in zip(names, losses, accuracies):
    offset = {"Read target Y": (10, -12), "Read distractor S": (10, 14), "Read shared content U": (-125, 12), "Read answer offset": (10, -20)}[name]
    axes[1].annotate(name, (loss, accuracy), xytext=offset, textcoords="offset points", fontsize=9)
axes[1].axhline(.5, color="gray", linestyle="--", linewidth=1)
axes[1].set(xlabel="Unlabelled CCS loss", ylabel="Target accuracy", ylim=(.4, 1.1), title="Equally low loss, different meanings")
axes[1].set_xlim(-.08, 1.8)
fig.tight_layout()
save_figure(fig, "ccs_exact_counterexample.png")
```

<!-- ARENA:cell markdown -->
<details>
<summary>Interpretation — which failure did centering fix?</summary>

Centering removes the constant answer-token coordinate. Without it, the answer
offset reporter gives every question the same averaged answer while satisfying
the pairwise loss almost perfectly. With it, that reporter produces only halves.
It does not remove the independent distractor: $S$ varies across questions and
reverses across the two branches, just as $Y$ does.

The target and distractor scores have equally small positive loss because a
finite sigmoid cannot reach 0 or 1 exactly. The plotted target accuracy is 100%
versus 50%. The same loss is therefore compatible with a useful classifier and
an irrelevant one in this explicitly linear representation.

</details>

# 3️⃣ Fit the reporter and inspect every restart

Now let optimization find a direction. We will use ten independent initializations,
1000 AdamW steps, learning rate $.01$ and weight decay $.01$. There is no label
argument. Each restart has its own parameters and optimizer state; running their
matrix operations together only reduces repeated overhead.

Do not pick the seed with the best target accuracy. Our selection rule is the
lowest **final training CCS loss**, with the first restart breaking a tie. Keep
the whole history, including the loss recomputed after the last update. AdamW
weight decay acts on the parameters; it is not included in the plotted CCS loss.

<!-- ARENA:cell markdown -->
### Exercise 4 — Fit independent restarts and select without labels

> ```yaml
> Difficulty: 🔴🔴🔴⚪⚪
> Importance: 🔵🔵🔵🔵⚪
>
> You should spend 25–35 minutes on this exercise.
> ```

Return every restart's weights, biases and a `[steps + 1, restarts, 3]`
history containing total, consistency and confidence losses. Use local random
generators so fitting does not reset unrelated notebook randomness. Optimize
the sum of the separate reporters' losses. Then implement the stated selection
rule using only this history.

<details>
<summary>Help</summary>

Initialize each weight vector and bias uniformly between
`-1 / sqrt(width)` and `1 / sqrt(width)`, using its own seed. A single AdamW
optimizer can hold the stacked parameter tensors because its moment estimates
are elementwise. Recompute the final loss before selecting.

</details>

<details>
<summary>Expected output</summary>

Batched fits match separate single-seed fits to numerical precision,
including their histories. Inputs and global random state stay unchanged. The
selection test deliberately contains tied losses.

</details>

<details>
<summary>Solution</summary>

```python
def fit_ccs_restarts(
    plus: Tensor,
    minus: Tensor,
    *,
    seeds: Sequence[int] = tuple(range(10)),
    steps: int = 1000,
    learning_rate: float = 0.01,
    weight_decay: float = 0.01,
) -> dict[str, Tensor | list[int]]:
    """Fit independent affine reporters with AdamW and retain every restart.

    Inputs must already have training-fitted centering applied. Independent
    parameter rows are optimized together; sum, rather than mean, over their
    losses preserves each reporter's gradient. The final loss is recomputed
    after the final update. No labels or validation scores enter this function.
    """
    _check_pairs(plus, minus)
    seeds = list(seeds)
    if not seeds or len(set(seeds)) != len(seeds):
        raise ValueError("Provide at least one unique restart seed.")
    if steps < 1 or learning_rate <= 0 or weight_decay < 0:
        raise ValueError("Steps and learning rate must be positive; weight decay must be nonnegative.")
    plus, minus = plus.detach(), minus.detach()
    width = plus.shape[1]
    bound = 1 / math.sqrt(width)
    initial_weights, initial_biases = [], []
    for seed in seeds:
        generator = torch.Generator(device=plus.device).manual_seed(seed)
        initial_weights.append(
            torch.empty(width, dtype=plus.dtype, device=plus.device).uniform_(-bound, bound, generator=generator)
        )
        initial_biases.append(
            torch.empty((), dtype=plus.dtype, device=plus.device).uniform_(-bound, bound, generator=generator)
        )
    weight = torch.stack(initial_weights).requires_grad_()
    bias = torch.stack(initial_biases).requires_grad_()
    optimizer = torch.optim.AdamW([weight, bias], lr=learning_rate, weight_decay=weight_decay)
    history = []
    for step in range(steps + 1):
        _, p_plus, p_minus = paired_probabilities(plus, minus, weight, bias)
        loss, consistency, confidence = ccs_loss(p_plus, p_minus)
        history.append(torch.stack((loss, consistency, confidence), dim=-1).detach().cpu())
        if step == steps:
            break
        optimizer.zero_grad(set_to_none=True)
        loss.sum().backward()
        optimizer.step()
    return {
        "weights": weight.detach().clone(),
        "biases": bias.detach().clone(),
        "history": torch.stack(history),
        "seeds": seeds,
    }
def select_restart(fitted: dict) -> dict:
    """Choose the first minimum final training-loss restart, without labels."""
    history = fitted["history"]
    if history.ndim != 3 or history.shape[-1] != 3 or not torch.isfinite(history).all():
        raise ValueError("Expected finite (steps + 1, restarts, 3) loss history.")
    count = len(fitted["seeds"])
    if history.shape[1] != count or fitted["weights"].shape[0] != count or fitted["biases"].shape != (count,):
        raise ValueError("Restart parameters, seeds and history must agree.")
    index = int(history[-1, :, 0].argmin())
    return {
        "index": index,
        "seed": fitted["seeds"][index],
        "weight": fitted["weights"][index].clone(),
        "bias": fitted["biases"][index].clone(),
        "training_loss": float(history[-1, index, 0]),
    }
```

</details>

<!-- ARENA:cell code -->
```python
def fit_ccs_restarts(plus: Tensor, minus: Tensor, *, seeds: Sequence[int]=tuple(range(10)), steps: int=1000, learning_rate: float=0.01, weight_decay: float=0.01) -> dict[str, Tensor | list[int]]:
    """Fit independent affine reporters with AdamW and retain every restart.

    Inputs must already have training-fitted centering applied. Independent
    parameter rows are optimized together; sum, rather than mean, over their
    losses preserves each reporter's gradient. The final loss is recomputed
    after the final update. No labels or validation scores enter this function.
    """
    raise NotImplementedError()

def select_restart(fitted: dict) -> dict:
    """Choose the first minimum final training-loss restart, without labels."""
    raise NotImplementedError()

tests.test_batched_restarts(fit_ccs_restarts)
tests.test_restart_selection(select_restart)
print("Independent restart equivalence and selection checks passed!")
```

<!-- ARENA:cell code -->
```python
fitted = fit_ccs_restarts(plus, minus)
chosen = select_restart(fitted)
all_scores, all_p, all_m = paired_probabilities(plus, minus, fitted["weights"], fitted["biases"])
target_raw = ((all_scores > .5) == target_labels[:, None]).double().mean(0)
distractor_raw = ((all_scores > .5) == distractor_labels[:, None]).double().mean(0)
target_oracle = torch.maximum(target_raw, 1 - target_raw)
distractor_oracle = torch.maximum(distractor_raw, 1 - distractor_raw)
fig, axes = plt.subplots(1, 3, figsize=(13.4, 4.0))
for index, seed in enumerate(fitted["seeds"]):
    axes[0].plot(fitted["history"][:, index, 0], linewidth=1.2, alpha=.75)
    axes[1].scatter(float(fitted["history"][-1, index, 0]), float(target_oracle[index]), s=35)
    if index in {chosen["index"], int(target_oracle.argmax())}:
        offset = (8, 10) if index == chosen["index"] else (-38, -18)
        axes[1].annotate(f"Seed {seed}", (float(fitted["history"][-1, index, 0]), float(target_oracle[index])),
                         xytext=offset, textcoords="offset points", fontsize=9)
axes[0].axhline(.2, color="black", linestyle="--", linewidth=1, label="Best constant equal scores")
axes[0].set(xlabel="AdamW update", ylabel="CCS loss", yscale="log", title="Every restart is retained")
axes[0].legend(fontsize=8)
axes[1].scatter(chosen["training_loss"], float(target_oracle[chosen["index"]]), marker="*", s=160, facecolors="none", edgecolors="black")
axes[1].set(xlabel="Final training loss", ylabel="Target accuracy, best orientation", ylim=(.4, 1.1), title="Star: loss-selected restart")
positions = np.arange(10)
axes[2].bar(positions - .17, target_oracle, width=.34, label="Target", color="#277da8")
axes[2].bar(positions + .17, distractor_oracle, width=.34, label="Distractor", color="#e08b35")
axes[2].axhline(.5, color="gray", linestyle="--", linewidth=1)
axes[2].set(xticks=positions, xlabel="Restart seed", ylabel="Accuracy, best orientation", ylim=(0, 1.1), title="What feature did each fit find?")
axes[2].legend(fontsize=8)
fig.tight_layout()
save_figure(fig, "ccs_restart_outcomes.png")
print(f"Selected seed {chosen['seed']} using loss {chosen['training_loss']:.6f}.")
```

<!-- ARENA:cell markdown -->
<details>
<summary>Interpretation — why label these accuracies “best orientation”?</summary>

We used the labels to decide which end of each direction counts as positive in
this diagnostic plot. That is useful for identifying a feature in an exact toy,
but it is not a classifier that can be deployed without further information.
The original paper uses this kind of test-set orientation in its reported
evaluation. Its fitting algorithm still does not consume the labels. The next
exercise keeps the fitting and orientation operations separate.

With the prescribed settings, seed 0 reads the target and the other nine seeds
read the distractor. The minimum-loss selection is seed 6 (loss approximately
0.000149), which has 50% target accuracy even after choosing its better
orientation. The right panel identifies every seed separately; points with
similar losses can overlap in the middle panel.

In this example the distractor has three times the target's coordinate scale.
Optimization may find it easily. Every seed is shown so you can see whether a
selected seed represents a stable outcome or just one of several possibilities.
No finite collection of optimizer runs proves which solutions exist; our exact
construction already established that both features can satisfy the loss.

</details>

<!-- ARENA:cell markdown -->
### Exercise 5 — Assign an orientation without reading the final labels

> ```yaml
> Difficulty: 🔴🔴⚪⚪⚪
> Importance: 🔵🔵🔵🔵⚪
>
> You should spend 10–15 minutes on this exercise.
> ```

Use a separate labelled calibration split to choose one global
orientation, +1 or -1. Preserve +1 on a tie. For final evaluation, keep this
orientation fixed. Report accuracy, cross-entropy and Brier score, plus an
explicitly named diagnostic `test_oracle_orientation_accuracy`. A score exactly
equal to .5 predicts zero under either orientation.

<details>
<summary>Help</summary>

Compare `scores > .5` with `(1 - scores) > .5` on calibration labels.
Do not replace the final accuracy by its maximum over the two orientations.
Clip probabilities at a dtype-aware epsilon before taking logarithms.

</details>

<details>
<summary>Expected output</summary>

The test's calibration split chooses -1. Its final split favors the
opposite orientation, but primary accuracy stays 0 and only the labelled oracle
diagnostic reaches 1. Half scores give cross-entropy log(2) and Brier score .25.

</details>

<details>
<summary>Solution</summary>

```python
def calibrate_orientation(scores: Tensor, calibration_labels: Tensor) -> int:
    """Choose a global orientation using a separate labelled calibration split.

    A tie preserves +1. This is supervision for orientation, not CCS fitting.
    Exact 0.5 scores predict zero under either orientation.
    """
    _check_scores_labels(scores, calibration_labels)
    raw = ((scores > 0.5) == calibration_labels).sum()
    flipped = (((1 - scores) > 0.5) == calibration_labels).sum()
    return -1 if flipped > raw else 1
def binary_metrics(scores: Tensor, labels: Tensor, orientation: int = 1) -> dict[str, float | int]:
    """Evaluate a fixed orientation. The test-oracle score is explicitly separate."""
    _check_scores_labels(scores, labels)
    if orientation not in (-1, 1):
        raise ValueError("Orientation must be +1 or -1.")
    probability = scores if orientation == 1 else 1 - scores
    correct = ((probability > 0.5) == labels).sum().item()
    other_correct = (((1 - probability) > 0.5) == labels).sum().item()
    epsilon = max(1e-12, torch.finfo(probability.dtype).eps)
    clipped = probability.clamp(epsilon, 1 - epsilon)
    labels_float = labels.to(probability)
    cross_entropy = -(labels_float * clipped.log() + (1 - labels_float) * (1 - clipped).log()).mean()
    return {
        "count": len(scores),
        "correct": correct,
        "accuracy": correct / len(scores),
        "test_oracle_orientation_accuracy": max(correct, other_correct) / len(scores),
        "cross_entropy": float(cross_entropy),
        "brier": float((probability - labels_float).square().mean()),
    }
```

</details>

<!-- ARENA:cell code -->
```python
def calibrate_orientation(scores: Tensor, calibration_labels: Tensor) -> int:
    """Choose a global orientation using a separate labelled calibration split.

    A tie preserves +1. This is supervision for orientation, not CCS fitting.
    Exact 0.5 scores predict zero under either orientation.
    """
    raise NotImplementedError()

def binary_metrics(scores: Tensor, labels: Tensor, orientation: int=1) -> dict[str, float | int]:
    """Evaluate a fixed orientation. The test-oracle score is explicitly separate."""
    raise NotImplementedError()

tests.test_orientation_and_metrics(calibrate_orientation, binary_metrics)
print("Calibration, fixed-orientation evaluation and probability checks passed!")
```

<!-- ARENA:cell code -->
```python
calibration_scores = torch.tensor([.8, .1, .9, .2], dtype=torch.float64)
calibration_labels = torch.tensor([0, 1, 0, 1])
orientation = calibrate_orientation(calibration_scores, calibration_labels)
final_labels = 1 - calibration_labels
fixed = binary_metrics(calibration_scores, final_labels, orientation)
fig, axes = plt.subplots(1, 2, figsize=(10.8, 3.8))
axes[0].plot(range(4), calibration_scores, "o-", label="Raw score", color="#277da8")
axes[0].plot(range(4), 1 - calibration_scores, "s--", label="Calibration-oriented score", color="#e08b35")
axes[0].scatter(range(4), final_labels, marker="x", s=85, color="black", label="Final labels")
axes[0].axhline(.5, color="gray", linewidth=1)
axes[0].set(xlabel="Final example", ylabel="Plus score / label", ylim=(-.1, 1.1), title="A deliberately shifted evaluation set")
axes[0].legend(fontsize=8)
axes[1].bar(["Fixed calibration\norientation", "Best final-label\norientation", "Balanced\nconstant baseline"],
            [fixed["accuracy"], fixed["test_oracle_orientation_accuracy"], .5], color=["#277da8", "#e08b35", "#888888"])
axes[1].set(ylabel="Final accuracy", ylim=(0, 1.1), title="These are different evaluation questions")
fig.tight_layout()
save_figure(fig, "ccs_orientation_control.png")
```

<!-- ARENA:cell markdown -->
This shift was constructed to make the distinction unmistakable. It does not
predict how often a real reporter changes meaning across tasks. In a native
study, changing calibration data, prompt form or the task can reveal that
instability. Keep the fixed-orientation result visible even when the retrospective
oracle looks much better.

## A simpler direction-finding baseline

Subtract the paired activations and fit their first principal component. This
uses the same contrast structure but no CCS objective. In our construction the
difference is $(0,2Y,6S,0)$, so its largest-variance direction reads the distractor.
The squared leading singular value is $8\times6^2=288$.

This comparison helps identify which parts of a result come from the contrast
representation itself and which require the consistency objective. A supervised
probe is another useful native comparison: it checks whether the target can be
read at all when its fitting labels are provided.

<!-- ARENA:cell markdown -->
### Exercise 6 — Fit the paired-difference PCA baseline

> ```yaml
> Difficulty: 🔴🔴⚪⚪⚪
> Importance: 🔵🔵🔵🔵⚪
>
> You should spend 10–15 minutes on this exercise.
> ```

Center the paired differences on their training mean and find the
first right singular vector. Retain that mean for inference. Fix the numerical
SVD sign by making its largest-magnitude coordinate positive. This convention
does not identify the direction's semantic meaning.

<details>
<summary>Help</summary>

Use `torch.linalg.svd(..., full_matrices=False)`. The rows of `vh` are feature-space directions. Reject a dataset with no difference variance.

</details>

<details>
<summary>Expected output</summary>

The exact dataset gives the distractor coordinate and squared leading singular value 288.

</details>

<details>
<summary>Solution</summary>

```python
def fit_difference_pca(plus: Tensor, minus: Tensor) -> dict[str, Tensor]:
    """Fit a first-PC baseline to centred paired differences, without labels."""
    _check_pairs(plus, minus)
    differences = (plus - minus).detach()
    mean = differences.mean(0)
    _, singular, vh = torch.linalg.svd(differences - mean, full_matrices=False)
    if float(singular[0]) == 0:
        raise ValueError("The paired differences have no variance.")
    weight = vh[0]
    # Fix the numerical SVD sign; this is not a semantic orientation.
    weight = weight * weight[weight.abs().argmax()].sign()
    return {"weight": weight, "mean": mean, "singular_values": singular}
```

</details>

<!-- ARENA:cell code -->
```python
def fit_difference_pca(plus: Tensor, minus: Tensor) -> dict[str, Tensor]:
    """Fit a first-PC baseline to centred paired differences, without labels."""
    raise NotImplementedError()

tests.test_pca_distractor(fit_difference_pca)
print("Paired-difference PCA baseline passed!")
```

<!-- ARENA:cell code -->
```python
pca = fit_difference_pca(plus, minus)
rng = torch.Generator().manual_seed(820)
random_weights = torch.randn(32, plus.shape[1], generator=rng, dtype=plus.dtype)
random_weights = random_weights / random_weights.norm(dim=1, keepdim=True)
random_scores, _, _ = paired_probabilities(plus, minus, random_weights, torch.zeros(32, dtype=plus.dtype))
random_target = ((random_scores > .5) == target_labels[:, None]).double().mean(0)
random_distractor = ((random_scores > .5) == distractor_labels[:, None]).double().mean(0)
random_target = torch.maximum(random_target, 1 - random_target)
random_distractor = torch.maximum(random_distractor, 1 - random_distractor)
fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.2))
for i, weight in enumerate(fitted["weights"]):
    direction = weight[1:3] / weight[1:3].norm()
    axes[0].arrow(0, 0, float(direction[0]), float(direction[1]), head_width=.045, alpha=.45, color="#277da8", length_includes_head=True)
axes[0].arrow(0, 0, 0, 1, head_width=.07, color="#e08b35", length_includes_head=True)
axes[0].plot([], [], color="#277da8", label="CCS restarts")
axes[0].plot([], [], color="#e08b35", label="Paired PCA")
axes[0].set(xlabel="Target-axis weight", ylabel="Distractor-axis weight", xlim=(-1.2, 1.2), ylim=(-1.2, 1.2), title="Directions in the known feature plane", aspect="equal")
axes[0].legend(fontsize=8)
axes[1].scatter(np.arange(32), random_target, s=26, color="#277da8", label="Target, random direction")
axes[1].scatter(np.arange(32), random_distractor, s=26, marker="x", color="#e08b35", label="Distractor, random direction")
axes[1].axhline(.5, color="gray", linestyle="--", linewidth=1)
axes[1].set(xlabel="Random direction seed draw", ylabel="Accuracy, best orientation", ylim=(.4, 1.1), title="Even random directions can read a salient feature")
axes[1].legend(fontsize=8, loc="center right")
fig.tight_layout()
save_figure(fig, "ccs_direction_baselines.png")
```

<!-- ARENA:cell markdown -->
<details>
<summary>Interpretation — why do some random directions perform so well?</summary>

There are only two answer-dependent coordinates in this exact example. A random
direction can have a larger effective coefficient on one than on the other,
making that feature perfectly separable after thresholding. The diagnostic also
gets to choose its orientation using the labels. This is why an apparently good
accuracy needs a random-direction comparison; “not trained” does not imply
“chance” for this representation. We keep all 32 draws.

</details>

## Try It Yourself — turn up the irrelevant feature

Change `DISTRACTOR_STRENGTHS`, `PLAY_STEPS` or `PLAY_SEEDS`. Before running the
cell, predict where PCA will change its preferred direction. Then predict how
often CCS will find the target. Keep the seed list the same across strengths so
you can compare the same initializations. The black circle shows the reporter
selected by unlabelled loss; every faint point is one retained restart.

<!-- ARENA:cell code -->
```python
DISTRACTOR_STRENGTHS = [.25, .5, .75, 1., 1.5, 2., 3., 5.]
PLAY_STEPS = 350
PLAY_SEEDS = list(range(10))
play_records = []
fig, axes = plt.subplots(1, 2, figsize=(12.0, 4.0))
for strength in DISTRACTOR_STRENGTHS:
    pp, pm = plus.clone(), minus.clone()
    pp[:, 2], pm[:, 2] = strength * distractor_sign, -strength * distractor_sign
    fit = fit_ccs_restarts(pp, pm, seeds=PLAY_SEEDS, steps=PLAY_STEPS)
    best = select_restart(fit)
    score, _, _ = paired_probabilities(pp, pm, fit["weights"], fit["biases"])
    accuracy = ((score > .5) == target_labels[:, None]).double().mean(0)
    oracle = torch.maximum(accuracy, 1 - accuracy)
    axes[0].scatter([strength] * len(PLAY_SEEDS), oracle, color="#277da8", alpha=.25, s=30)
    axes[0].scatter(strength, oracle[best["index"]], facecolors="none", edgecolors="black", s=90)
    axes[1].scatter([strength] * len(PLAY_SEEDS), fit["history"][-1, :, 0], color="#277da8", alpha=.4, s=30)
    axes[1].scatter(strength, best["training_loss"], facecolors="none", edgecolors="black", s=90)
    play_records.append({"strength": strength, "selected_seed": best["seed"], "selected_target_oracle_accuracy": float(oracle[best["index"]]),
                         "all_target_oracle_accuracies": oracle.tolist(), "all_final_losses": fit["history"][-1, :, 0].tolist()})
axes[0].plot([.25, .99], [1, 1], "--", color="#e08b35", label="PCA (tie at strength 1 excluded)")
axes[0].plot([1.01, 5], [.5, .5], "--", color="#e08b35")
axes[0].axhline(.5, color="gray", linestyle="--", linewidth=1)
axes[0].set(xlabel="Distractor strength / target strength", ylabel="Target accuracy, best orientation", ylim=(.4, 1.1), title="Same target, different optimization preference")
axes[0].legend(fontsize=8)
axes[1].set(xlabel="Distractor strength / target strength", ylabel="Final training CCS loss", yscale="log", title="Low loss does not identify the target")
fig.tight_layout()
save_figure(fig, "ccs_distractor_strength_play.png")
(assets_dir / "foundation_play.json").write_text(json.dumps(play_records, indent=2) + "\n")
```

<!-- ARENA:cell markdown -->
# 4️⃣ Check the implementation and carry the question to a model

## Independent reference check

The tests above use exact cases and an independently differentiated NumPy
expression. We also compare training centering, original loss and gradients
with hash-verified primitives from the
[author implementation](https://github.com/collin-burns/discovering_latent_knowledge/tree/be10d7b912b17e8eacb45de794e9dca044e4ed37).
This checks the method we actually implement, not an assumed equivalence of the
complete data-processing and evaluation protocols.

The original demonstration centers its test activations separately and chooses
the better test-set orientation. Our intended native study instead reuses the
training means and assigns orientation using separate calibration labels.
Those choices answer different questions about transfer. Neither should be
hidden inside a utility function.

<!-- ARENA:cell code -->
```python
from chapter11_representation_geometry.exercises.part5_contrast_consistent_search.reference_parity import compare_author_primitives
parity = compare_author_primitives()
for result in parity["cases"]:
    print(f"{result['case']}: centering error {result['centering_error']:.2e}, loss error {result['loss_error']:.2e}, gradient error {result['gradient_error']:.2e}")
assert parity["passed"]
(assets_dir / "author_parity.json").write_text(json.dumps(parity, indent=2) + "\n")
```

<!-- ARENA:cell markdown -->
## What has this foundation established?

You have implemented the original objective and fitted a reporter without
labels. In a representation whose factors are known, an independent distractor
can satisfy the same objective as the intended target. The optimizer's choice
depends on which features are represented, their geometry and the fitting
procedure. The paired-PCA and random-direction results help make that dependence
visible.

This controlled example is motivated by the identification problem studied by
[Farquhar et al.](https://arxiv.org/html/2312.10029v2). Our exact construction puts
the competing features into a linear space explicitly. It does not establish
that every arbitrary feature is linearly readable in a particular transformer,
or that CCS never finds useful representations.

## Further investigations

- Replace the distractor coordinate by one that does **not** reverse between
  the two branches. Which loss term now objects to using it?
- Destroy the pairing by permuting only the minus examples. Can a wide reporter
  get low training loss anyway, and does that result transfer to new pairs?
- Increase the fraction of one target label. How does separate branch centering
  change what a threshold at zero means?
- Compare the original loss with a symmetrized confidence term. Verify its
  complement symmetry numerically; keep it labelled as a different objective.

## Native study still to implement

The next stage will extract actual paired activations from a frozen language
model, fit reporters on an unlabelled training split, calibrate their orientation
separately and compare target and distractor behavior on new sentences. Its
protocol, controls, full own-answer run and fresh reproduction are required
before this becomes a published course section. This foundation alone is not a
native knowledge-elicitation result.

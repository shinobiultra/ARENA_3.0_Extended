<!-- ARENA:cell markdown -->
# [11.3] Causal Abstraction and Distributed Alignment Search

# Introduction

A probe reads a decision perfectly from two different features. Swapping one
feature changes the decision; swapping the other does nothing. Which feature
helps explain how the model works?

We'll build this example, rotate it so no neuron has a convenient label, and
learn an intervention using gradient descent. The important comparison is
between two computations: intervene on a named variable in our small causal
model, or intervene on the corresponding part of a neural activation. Do they
produce the same answer, while preserving the base example's other decision?

**Draft scope:** this is the executable exact-model foundation for 11.3. The
pretrained GPT-2 experiment is still being developed. These results do not
establish a causal abstraction inside a pretrained language model.

## Content & Learning Objectives

### 1️⃣ Specify the counterfactual

> - Distinguish an observation, an intervention, and an output prediction.
> - Implement a high-level model and enumerate its interchange interventions.
> - Explain why a full donor swap can change an unrelated variable.

### 2️⃣ Implement a distributed intervention

> - Derive a subspace swap from rotate, replace, and unrotate.
> - Preserve the orthogonal complement and test composition of interventions.
> - Check gradients against an independent finite-difference oracle.

### 3️⃣ Learn an alignment, then try to falsify it

> - Optimize intervention loss while keeping the neural model frozen.
> - Compare changed-variable and unchanged-variable agreement.
> - Retain all seeds, shuffled-supervision controls and random subspaces.
> - Separate correct output behavior from recovery of an exact internal coordinate.

## Setup

The foundation runs on CPU in seconds after dependencies load. Allow around
90 minutes to implement and interpret it. Complete each function before running
its immediate tests, or open the solution when that helps you make progress.

<!-- ARENA:cell code -->
```python
import itertools
import os
import sys
from collections.abc import Callable
from pathlib import Path
from types import SimpleNamespace

import matplotlib.pyplot as plt
import numpy as np
import torch as t
from IPython import get_ipython

if get_ipython() is not None:
    get_ipython().run_line_magic("matplotlib", "inline")
root_dir = next(p for p in [Path.cwd(), *Path.cwd().parents]
                if (p / "chapter11_representation_geometry").exists())
if str(root_dir) not in sys.path:
    sys.path.append(str(root_dir))
from chapter11_representation_geometry.exercises.part3_causal_abstraction_das import das_methods_tests as tests

assets_dir = Path(os.environ.get("ARENA_DAS_OUTPUT_DIRECTORY", "das_outputs"))
assets_dir.mkdir(parents=True, exist_ok=True)
t.set_num_threads(2)
plt.style.use("seaborn-v0_8-whitegrid")
```

<!-- ARENA:cell markdown -->
# 1️⃣ Specify the counterfactual

## Two decisions, four possible answers

Our high-level model has two independent binary intermediate variables: a
routing decision $R$ and a side decision $S$. It reports the joint output
$Y = 2R + S$, so class 3 means $(R,S)=(1,1)$.

Take a base example $(0,1)$ and a source example $(1,0)$. Interchanging **only
$R$** produces $(1,1)$, hence output 3. Copying the entire source produces output
2. The distinction matters: an intervention that copies every answer need not
isolate the variable we intended to explain.

An interchange obtains the replacement value from another ordinary model run.
It then overrides the selected variable's normal mechanism, leaving other
mechanisms and the base input fixed. We will use all 16 base/source combinations,
including pairs whose routing decisions are already equal.

<!-- ARENA:cell markdown -->
### Exercise 1 — Intervene on a named high-level variable

> ```yaml
> Difficulty: 🔴🔴🔴⚪⚪
> Importance: 🔵🔵🔵🔵⚪
> You should spend 10 minutes on this exercise.
> ```

Implement the variable replacement and recompute the joint output. Inputs have shape `[examples, 2]`. The `variables` tuple may select neither, either, or both columns. Do not modify the caller's tensors.

<details><summary>Help</summary>

Clone the base settings, then copy only selected source columns. The output is computed from the resulting settings; returning the source's output skips the central counterfactual question.

</details>

<details><summary>Expected output</summary>

Base `[0, 1]`, source `[1, 0]`, and variable `(0,)` give `[1, 1]` and output `3`. A whole-source swap gives output `2`.

</details>

<details><summary>Solution</summary>

```python
def high_level_interchange(
    base: t.Tensor, source: t.Tensor, variables: tuple[int, ...]
) -> t.Tensor:
    """Replace named binary variables, preserving the rest of each base row.

    Column 0 is a routing decision; column 1 is an independent side decision.
    This returns the intervened variable setting, before evaluating the output.
    """
    if base.ndim != 2 or base.shape[1] != 2 or source.shape != base.shape:
        raise ValueError("Expected paired [examples, two binary variables] arrays.")
    if not t.all((base == 0) | (base == 1)) or not t.all((source == 0) | (source == 1)):
        raise ValueError("The high-level variables must be binary.")
    if len(set(variables)) != len(variables) or any(i not in (0, 1) for i in variables):
        raise ValueError("Choose distinct variables from (0, 1).")
    result = base.clone()
    result[:, list(variables)] = source[:, list(variables)]
    return result


def high_level_output(variables: t.Tensor) -> t.Tensor:
    """Joint output class for routing and side decisions: 2 * routing + side."""
    return (2 * variables[:, 0] + variables[:, 1]).long()

```

</details>

<!-- ARENA:cell code -->
```python
def high_level_interchange(
    base: t.Tensor, source: t.Tensor, variables: tuple[int, ...]
) -> t.Tensor:
    'Replace named binary variables, preserving the rest of each base row.'
    raise NotImplementedError()

def high_level_output(variables: t.Tensor) -> t.Tensor:
    'Joint output class for routing and side decisions: 2 * routing + side.'
    raise NotImplementedError()

tests.test_high_level_mechanisms(SimpleNamespace(**globals()))
```

<!-- ARENA:cell markdown -->
# 2️⃣ Implement a distributed intervention

## Rotate, replace, and unrotate

Let $h_b,h_s\in\mathbb R^d$ be row-vector activations. Suppose the columns of
$Q\in\mathbb R^{d\times k}$ span the feature we want to exchange, with
$Q^\top Q=I_k$. Complete them to an orthogonal basis $[Q,Q_\perp]$.

In the rotated coordinates, replace $h_bQ$ with $h_sQ$ and preserve
$h_bQ_\perp$. Transforming back gives

$$h'_b = h_sQQ^\top + h_bQ_\perp Q_\perp^\top
       = h_b + (h_s-h_b)QQ^\top.$$

The second expression needs only a thin basis. It can represent any rank-$k$
orthogonal subspace without constructing a $d\times d$ rotation. Changing
column signs or rotating within that subspace leaves the intervention unchanged.

We will optimize an unconstrained matrix $A$ and use its reduced QR basis $Q(A)$
at every step. This is differentiable away from rank loss; it is not a claim
that QR is well-behaved when columns become dependent. The projector stays
orthogonal throughout training.

<!-- ARENA:cell markdown -->
### Exercise 2 — Parameterize an orthonormal subspace

> ```yaml
> Difficulty: 🔴🔴🔴⚪⚪
> Importance: 🔵🔵🔵🔵⚪
> You should spend 10 minutes on this exercise.
> ```

Return a `[width, rank]` orthonormal basis from a full-column-rank floating matrix. Reject dependent or nonfinite columns; handle rank zero. Use reduced QR and make the diagonal of the corresponding triangular factor nonnegative.

<details><summary>Help</summary>

For `A = Q @ R`, multiply each column of Q by the sign of the matching diagonal of R. The projection Q Q.T is sign-invariant. Do not detach Q: a later loss must differentiate through it.

</details>

<details><summary>Expected output</summary>

`Q.T @ Q` is the identity. You will check the full intervention gradient after implementing the swap and loss.

</details>

<details><summary>Solution</summary>

```python
def orthonormal_columns(raw: t.Tensor) -> t.Tensor:
    """Differentiable reduced QR, with a defined sign convention.

    Only the column span is used by an intervention. QR signs do not change its
    projector. The sign convention makes saved bases easier to compare; QR is
    differentiable only away from rank loss. A zero-column basis is allowed.
    """
    if raw.ndim != 2 or raw.shape[1] > raw.shape[0] or not raw.is_floating_point():
        raise ValueError("Use a floating [width, rank] matrix, with rank <= width.")
    if not t.isfinite(raw).all():
        raise ValueError("The alignment parameters must be finite.")
    if raw.shape[1] == 0:
        return raw.clone()
    if int(t.linalg.matrix_rank(raw.detach())) != raw.shape[1]:
        raise ValueError("QR alignment requires linearly independent columns.")
    q, r = t.linalg.qr(raw, mode="reduced")
    signs = t.where(r.diagonal() < 0, -1.0, 1.0)
    return q * signs

```

</details>

<!-- ARENA:cell code -->
```python
def orthonormal_columns(raw: t.Tensor) -> t.Tensor:
    'Differentiable reduced QR, with a defined sign convention.'
    raise NotImplementedError()
```

<!-- ARENA:cell markdown -->
### Exercise 3 — Swap only the selected subspace

> ```yaml
> Difficulty: 🔴🔴🔴⚪⚪
> Importance: 🔵🔵🔵🔵⚪
> You should spend 15 minutes on this exercise.
> ```

Implement the derived row-vector formula. Validate dimensions and orthonormality. The tests compare it with an independently computed full rotation, including rank-zero and full-rank cases.

<details><summary>Help</summary>

A common bug is using `Q.T @ Q` as the activation-space projector; that matrix lives in feature-coordinate space. Compute `(source-base) @ Q @ Q.T`. No-op, source-coordinate equality and complement preservation test different failure modes.

</details>

<details><summary>Expected output</summary>

Self-swap is exactly unchanged; rank zero changes nothing; full rank recovers the complete donor. Swaps in disjoint orthogonal subspaces commute, while a second swap in the same subspace overwrites the first.

</details>

<details><summary>Solution</summary>

```python
def subspace_interchange(base: t.Tensor, source: t.Tensor, basis: t.Tensor) -> t.Tensor:
    """Copy source coordinates in a column-orthonormal subspace.

    For row vectors, h' = h + (s - h) Q Q.T. All base coordinates in the
    orthogonal complement are preserved. This is equivalent to rotate, replace
    the selected coordinates, then unrotate, without building a width^2 matrix.
    """
    if base.ndim != 2 or source.shape != base.shape:
        raise ValueError("Expected paired [examples, width] activations.")
    if basis.ndim != 2 or basis.shape[0] != base.shape[1]:
        raise ValueError("The basis must have shape [width, rank].")
    gram = basis.T @ basis
    identity = t.eye(basis.shape[1], dtype=basis.dtype, device=basis.device)
    if not t.allclose(gram, identity, atol=1e-5, rtol=1e-5):
        raise ValueError("Subspace interchange needs orthonormal columns.")
    return base + ((source - base) @ basis) @ basis.T

```

</details>

<!-- ARENA:cell code -->
```python
def subspace_interchange(base: t.Tensor, source: t.Tensor, basis: t.Tensor) -> t.Tensor:
    'Copy source coordinates in a column-orthonormal subspace.'
    raise NotImplementedError()

tests.test_projector_matches_explicit_rotate_swap_unrotate(SimpleNamespace(**globals()))
tests.test_disjoint_interventions_commute_and_same_variable_overwrites(SimpleNamespace(**globals()))
```

<!-- ARENA:cell markdown -->
## The low-level model: a used feature and an unused copy

The following model is deliberately small enough to inspect. Its latent vector
starts with `[2R-1, 2S-1, 2R-1]` and then independent Gaussian nuisance values.
A fixed random orthogonal matrix hides these coordinates in eight neurons.
The readout uses the first two latent coordinates and ignores the third.

That third coordinate predicts R perfectly. Its redundancy is observational;
it has no causal path to the output. We keep it to give the causal test an
honest adversary. All 16 variable pairs occur in both splits, but the held-out
examples have new nuisance values. This tests nuisance generalization, not
unseen binary concepts.

Read the encoder and readout before running them. They are the entire neural
model: there is no hidden trained network behind this example.

<!-- ARENA:cell code -->
```python
def make_organism(width: int = 8, seed: int = 17) -> dict:
    if width < 3:
        raise ValueError("The organism needs two causal variables and one unused copy.")
    generator = t.Generator().manual_seed(seed)
    rotation = t.linalg.qr(t.randn(width, width, dtype=t.float64, generator=generator)).Q
    classes = t.tensor(list(itertools.product((-1, 1), repeat=2)), dtype=t.float64)
    return {"rotation": rotation, "readout": 2.0 * rotation[:, :2] @ classes.T}


def organism_pairs(organism: dict, repeats: int, seed: int) -> dict:
    """All 16 base/source variable pairs, each with fresh independent nuisances."""
    variables = t.tensor(list(itertools.product((0, 1), repeat=2)))
    base_variables = variables.repeat_interleave(4, 0).repeat(repeats, 1)
    source_variables = variables.repeat(4, 1).repeat(repeats, 1)
    generator = t.Generator().manual_seed(seed)
    rotation = organism["rotation"]

    def encode(values):
        latent = t.randn(len(values), rotation.shape[0], dtype=t.float64, generator=generator)
        latent[:, :2] = 2 * values - 1
        latent[:, 2] = latent[:, 0]  # Perfectly predictive; the readout ignores this column.
        return latent @ rotation.T

    return {
        "base": encode(base_variables),
        "source": encode(source_variables),
        "base_variables": base_variables,
        "source_variables": source_variables,
    }
```

<!-- ARENA:cell code -->
```python
organism = make_organism()
train = organism_pairs(organism, repeats=16, seed=101)
heldout = organism_pairs(organism, repeats=64, seed=202)
rotation = organism["rotation"]
readout_before = organism["readout"].clone()
latent = heldout["base"] @ rotation
used_probe_accuracy = float(((latent[:, 0] > 0) == heldout["base_variables"][:, 0]).double().mean())
unused_probe_accuracy = float(((latent[:, 2] > 0) == heldout["base_variables"][:, 0]).double().mean())
print(f"Used feature probe: {used_probe_accuracy:.0%}; unused feature probe: {unused_probe_accuracy:.0%}")
print(f"Training pairs: {len(train['base'])}; held-out pairs: {len(heldout['base'])}")
```

<!-- ARENA:cell markdown -->
# 3️⃣ Learn an alignment, then try to falsify it

## Score the commuting diagram

The high-level route computes $H_{R\leftarrow R_s}(b)$. The low-level route
patches a subspace and reads the output, $L_{Q\leftarrow Q_s}(b)$. **Interchange
intervention accuracy (IIA)** is the fraction of specified pairs for which those
outputs agree. It depends on the intervention distribution and output mapping.
Finite held-out IIA is evidence on those cases; it is not a proof for every
possible intervention or an identification of unique internal coordinates.

For training, use cross entropy against the high-level counterfactual output.
Compute the normalizer over all four classes. For a language model this becomes
the full vocabulary; normalizing over two candidate names is a different loss.
Keep a separate changed-variable score. Half our pairs have the same R already,
so doing nothing earns 50% overall IIA while implementing none of the changes.

<!-- ARENA:cell markdown -->
### Exercise 4 — Train on counterfactual answers and measure agreement

> ```yaml
> Difficulty: 🔴🔴🔴⚪⚪
> Importance: 🔵🔵🔵🔵⚪
> You should spend 15 minutes on this exercise.
> ```

Implement stable cross entropy and masked output agreement. Targets are integer output classes. Return NaN for an empty subgroup, since it provides no accuracy evidence. Now check the entire differentiable path against finite differences.

<details><summary>Help</summary>

Use `logsumexp(logits, -1)` minus the selected target logit. For the gradient oracle, the test computes a projector independently as `A @ solve(A.T @ A, A.T)`; it does not call your QR implementation.

</details>

<details><summary>Expected output</summary>

Extreme logits remain finite. A no-op will score 50% overall and 0% on changed-variable pairs. The full gradient agrees with independent central finite differences.

</details>

<details><summary>Solution</summary>

```python
def intervention_loss(logits: t.Tensor, target: t.Tensor) -> t.Tensor:
    """Mean full-output-space cross entropy against high-level counterfactuals."""
    if logits.ndim != 2 or target.shape != (logits.shape[0],) or not len(target):
        raise ValueError("Use nonempty [examples, classes] logits and one target per row.")
    if target.dtype != t.long:
        raise ValueError("Targets must be integer class indices (torch.long).")
    if t.any(target < 0) or t.any(target >= logits.shape[1]):
        raise ValueError("A target is outside the output vocabulary.")
    log_normalizer = t.logsumexp(logits, dim=-1)
    target_logit = logits.gather(1, target[:, None]).squeeze(1)
    return (log_normalizer - target_logit).mean()


def interchange_accuracy(logits: t.Tensor, target: t.Tensor, mask: t.Tensor | None = None) -> float:
    """Output agreement on a specified intervention distribution.

    An empty subgroup is undefined (NaN), not perfect agreement. Report both
    all-pair IIA and changed-variable IIA: identity pairs can inflate an average.
    """
    if logits.ndim != 2 or target.shape != (len(logits),):
        raise ValueError("Use one target for each logit row.")
    if mask is None:
        mask = t.ones_like(target, dtype=t.bool)
    if mask.shape != target.shape or mask.dtype != t.bool:
        raise ValueError("The subgroup mask must be a boolean vector of matching shape.")
    if not mask.any():
        return float("nan")
    return float((logits.argmax(-1)[mask] == target[mask]).double().mean())

```

</details>

<!-- ARENA:cell code -->
```python
def intervention_loss(logits: t.Tensor, target: t.Tensor) -> t.Tensor:
    'Mean full-output-space cross entropy against high-level counterfactuals.'
    raise NotImplementedError()

def interchange_accuracy(logits: t.Tensor, target: t.Tensor, mask: t.Tensor | None = None) -> float:
    'Output agreement on a specified intervention distribution.'
    raise NotImplementedError()

tests.test_qr_and_independent_finite_difference_gradient(SimpleNamespace(**globals()))
tests.test_full_vocabulary_loss_and_empty_iia(SimpleNamespace(**globals()))
tests.test_predictive_unused_copy_fails_causal_interchange(SimpleNamespace(**globals()))
```

<!-- ARENA:cell code -->
```python
def evaluate_alignment(organism: dict, pairs: dict, basis: t.Tensor) -> dict:
    """Keep output agreement, coordinate errors and collateral changes distinct."""
    target_variables = high_level_interchange(
        pairs["base_variables"], pairs["source_variables"], (0,)
    )
    targets = high_level_output(target_variables)
    patched = subspace_interchange(pairs["base"], pairs["source"], basis)
    logits = patched @ organism["readout"]
    latent = patched @ organism["rotation"]
    changed = pairs["base_variables"][:, 0] != pairs["source_variables"][:, 0]
    expected = (2 * target_variables - 1).double()
    return {
        "iia": interchange_accuracy(logits, targets),
        "changed_iia": interchange_accuracy(logits, targets, changed),
        "unchanged_iia": interchange_accuracy(logits, targets, ~changed),
        "loss": float(intervention_loss(logits, targets)),
        "side_decision_accuracy": float(
            ((latent[:, 1] > 0) == target_variables[:, 1]).double().mean()
        ),
        "routing_coordinate_mae": float((latent[:, 0] - expected[:, 0]).abs().mean()),
        "side_coordinate_mae": float((latent[:, 1] - expected[:, 1]).abs().mean()),
        "unused_copy_constraint_error": float((latent[:, 0] - latent[:, 2]).abs().mean()),
        "examples": len(targets),
        "changed_examples": int(changed.sum()),
    }
```

<!-- ARENA:cell markdown -->
## First compare interventions you can explain exactly

For the base/source pair `(0,1) → (1,0)`, the high-level intervention requests
joint output 3. Read the actual distributions below. The full donor changes the
side decision too. The unused-copy swap leaves the output unchanged.

The mean-difference direction is a useful successful baseline here: it includes
both the used coordinate and its copy. Its success prevents us from claiming
that a trained DAS alignment is needed for this simple organism.

<!-- ARENA:cell code -->
```python
bases = {
    "No-op": rotation[:, :0],
    "Known causal": rotation[:, :1],
    "Unused copy": rotation[:, 2:3],
    "Mean direction": (rotation[:, :1] + rotation[:, 2:3]) / 2**0.5,
    "Full donor": rotation,
}
example_index = 6  # Base (0, 1), donor (1, 0): request (1, 1), class 3.
base = heldout["base"][example_index:example_index+1]
source = heldout["source"][example_index:example_index+1]
example_probabilities = t.stack([
    (subspace_interchange(base, source, q) @ organism["readout"]).softmax(-1)[0]
    for q in bases.values()
])
fig, ax = plt.subplots(figsize=(8, 4), constrained_layout=True)
image = ax.imshow(example_probabilities.numpy(), cmap="Blues", vmin=0, vmax=1)
ax.grid(False)
ax.set_xticks(range(4), ["(0,0)", "(0,1)", "(1,0)", "(1,1)
requested"])
ax.set_yticks(range(len(bases)), list(bases))
ax.set(xlabel="Joint (routing, side) output", title="Same perfect probe accuracy, different intervention effects")
for i in range(len(bases)):
    for j in range(4):
        value = float(example_probabilities[i, j])
        ax.text(j, i, f"{value:.2f}", ha="center", va="center", color="white" if value>.5 else "black")
fig.colorbar(image, ax=ax, label="Actual model probability")
fig.savefig(assets_dir / "das_exact_interchanges.png", dpi=160)
plt.show()
```

<!-- ARENA:cell markdown -->
## Learn the intervention rather than the probe

DAS minimizes the disagreement induced by interventions. Here only the thin
alignment parameters are trainable; the encoder, readout and high-level model
stay fixed. A gradient still has to pass through the readout to the intervention.
Wrapping that continuation in `no_grad()` would sever the learning signal.

We use 300 full-batch Adam updates at learning rate .03, three initializations,
and a rank-one subspace. These are small-model development settings, not an
optimized recipe for GPT-2. The final update is returned. No held-out metric
chooses a checkpoint, and every seed is retained.

<!-- ARENA:cell markdown -->
### Exercise 5 — Optimize a distributed alignment

> ```yaml
> Difficulty: 🔴🔴🔴⚪⚪
> Importance: 🔵🔵🔵🔵⚪
> You should spend 20 minutes on this exercise.
> ```

Initialize a thin trainable matrix with a local seeded generator. At every step, construct Q, patch the training base activations, run the frozen continuation and minimize counterfactual cross entropy. Record loss and IIA from step 0 through the final step.

<details><summary>Help</summary>

The optimizer should receive only the raw alignment matrix. Detach cached base/source activations, but keep autograd through Q, the swap and the model continuation. Zero the alignment gradient before backpropagating; check it is finite and nonempty.

</details>

<details><summary>Expected output</summary>

Training intervention loss falls, a fresh-nuisance test exceeds 98% IIA, and the model readout is bitwise unchanged. The test does not require recovering a unique planted vector.

</details>

<details><summary>Solution</summary>

```python
def fit_alignment(
    base: t.Tensor,
    source: t.Tensor,
    targets: t.Tensor,
    continue_model: Callable[[t.Tensor], t.Tensor],
    *,
    rank: int,
    steps: int = 200,
    learning_rate: float = 0.03,
    seed: int = 0,
) -> dict:
    """Optimize only a subspace using frozen activations and a frozen model tail.

    This small full-batch implementation is used by the exact organism. For a
    transformer, the continuation also needs each base prompt's untouched token
    positions. The caller must freeze model weights but retain autograd through
    the tail; inference_mode/no_grad around that tail would break DAS training.
    The returned alignment is the final step, not a test-selected checkpoint.
    """
    if not 1 <= rank <= base.shape[-1] or steps < 1 or learning_rate <= 0:
        raise ValueError("Use a feasible positive rank, step count and learning rate.")
    base, source = base.detach(), source.detach()
    generator = t.Generator(device=base.device).manual_seed(seed)
    raw = t.nn.Parameter(
        t.randn(base.shape[1], rank, dtype=base.dtype, device=base.device, generator=generator)
    )
    optimizer = t.optim.Adam([raw], lr=learning_rate)
    history = []
    for step in range(steps + 1):
        q = orthonormal_columns(raw)
        patched = subspace_interchange(base, source, q)
        logits = continue_model(patched)
        loss = intervention_loss(logits, targets)
        if not t.isfinite(loss):
            raise ValueError("The intervention objective became nonfinite.")
        history.append(
            {
                "step": step,
                "loss": float(loss.detach()),
                "iia": interchange_accuracy(logits.detach(), targets),
            }
        )
        if step == steps:
            break
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        if raw.grad is None or not t.isfinite(raw.grad).all():
            raise ValueError("A finite gradient must reach the alignment parameters.")
        optimizer.step()
    return {"basis": q.detach().clone(), "history": history}

```

</details>

<!-- ARENA:cell code -->
```python
def fit_alignment(
    base: t.Tensor,
    source: t.Tensor,
    targets: t.Tensor,
    continue_model: Callable[[t.Tensor], t.Tensor],
    *,
    rank: int,
    steps: int = 200,
    learning_rate: float = 0.03,
    seed: int = 0,
) -> dict:
    'Optimize only a subspace using frozen activations and a frozen model tail.'
    raise NotImplementedError()

tests.test_alignment_optimization_changes_subspace_and_freezes_model(SimpleNamespace(**globals()))
```

<!-- ARENA:cell code -->
```python
target = high_level_output(high_level_interchange(train["base_variables"], train["source_variables"], (0,)))
fits = {}
for seed in (0, 1, 2):
    for kind in ("DAS", "Shuffled targets"):
        targets = target
        if kind == "Shuffled targets":
            permutation = t.randperm(len(target), generator=t.Generator().manual_seed(400 + seed))
            targets = target[permutation]
        fitted = fit_alignment(train["base"], train["source"], targets,
                               lambda h: h @ organism["readout"], rank=1,
                               steps=300, learning_rate=.03, seed=seed)
        key = f"{kind}/seed{seed}"
        fits[key] = fitted
        bases[key] = fitted["basis"]
for draw in range(32):
    bases[f"Random/draw{draw}"] = orthonormal_columns(
        t.randn(8, 1, dtype=t.float64, generator=t.Generator().manual_seed(600 + draw)))
results = {name: evaluate_alignment(organism, heldout, q) for name, q in bases.items()}
assert t.equal(readout_before, organism["readout"]), "Only alignment parameters may change."
print("All six fits completed; all 32 random subspaces retained; model weights unchanged.")
```

<!-- ARENA:cell code -->
```python
fig, axes = plt.subplots(1, 2, figsize=(12, 4.5), constrained_layout=True)
for name, fit in fits.items():
    shuffled = name.startswith("Shuffled")
    axes[0].plot([r["step"] for r in fit["history"]], [r["loss"] for r in fit["history"]],
                 color="#8a9eb2" if shuffled else "#bf4c28", alpha=.7,
                 linestyle="--" if shuffled else "-", label=name)
axes[0].set(xlabel="Alignment update", ylabel="Training counterfactual cross entropy", title="Optimize the alignment, keep the model frozen")
axes[0].legend(fontsize=7)
groups = ["No-op", "Unused copy", "Known causal", "Mean direction", "Full donor", "DAS", "Shuffled targets", "Random"]
for x, group in enumerate(groups):
    chosen = [r for name, r in results.items() if name == group or name.startswith(group+"/")]
    for offset, field, color, label in [(-.16, "iia", "#8a9eb2", "All pairs"), (.16, "changed_iia", "#bf4c28", "Changed R only")]:
        values = [r[field] for r in chosen]
        jitter = np.linspace(-.06, .06, len(values)) if len(values)>1 else np.zeros(1)
        axes[1].scatter(x+offset+jitter, values, c=color, s=20, alpha=.65, label=label if x==0 else None)
        axes[1].plot([x+offset-.1, x+offset+.1], [np.mean(values)]*2, color=color, linewidth=2)
axes[1].set_xticks(range(len(groups)), groups, rotation=40, ha="right")
axes[1].set(ylim=(-.04, 1.08), ylabel="Held-out interchange accuracy", title="Identity pairs can hide failed interventions")
axes[1].legend(fontsize=8)
fig.savefig(assets_dir / "das_learning_and_controls.png", dpi=160)
plt.show()
```

<!-- ARENA:cell markdown -->
<details><summary>Interpretation — did DAS discover the unique true feature?</summary>

All three learned subspaces reach 100% output agreement in this experiment, as
do the known causal subspace and the observational mean direction. The unused
copy gets 0% on changed-R pairs; random subspaces average about 6%, with the
strongest near 59%. All 32 remain visible. Shuffled supervision sometimes has
partial effects too: it is not guaranteed to do nothing.

The readout cannot distinguish every latent value that yields the same winning
class. Cross entropy can prefer an edit that pushes beyond the source's original
coordinate and raises confidence. Thus perfect answer agreement does not recover
the exact coordinate or a unique direction. Inspect the errors below rather than
concluding that a successful optimizer has uniquely identified the mechanism.

</details>

<!-- ARENA:cell code -->
```python
fig, axes = plt.subplots(1, 2, figsize=(10, 4), constrained_layout=True)
comparison_names = ["Known causal", "Unused copy", "Mean direction", "Full donor", "DAS/seed0", "DAS/seed1", "DAS/seed2"]
for ax, metric, label in [(axes[0], "routing_coordinate_mae", "Routing coordinate mean absolute error"),
                          (axes[1], "side_decision_accuracy", "Preserved base side decision")]:
    ax.bar(range(len(comparison_names)), [results[name][metric] for name in comparison_names],
           color=["#487d9b"]*4+["#bf4c28"]*3)
    ax.set_xticks(range(len(comparison_names)), comparison_names, rotation=40, ha="right")
    ax.set(ylabel=label)
axes[0].set_title("Correct classes do not imply exact coordinates")
axes[1].set_title("Whole-donor swaps change another decision")
axes[1].set_ylim(0, 1.05)
fig.savefig(assets_dir / "das_coordinate_and_specificity.png", dpi=160)
plt.show()
```

<!-- ARENA:cell markdown -->
## Try It Yourself — move from an unused feature toward a used one

Vary the angle below. At zero degrees the intervention targets only the unused
copy; at 90 degrees it targets the known causal feature. Before running, predict
whether IIA should increase smoothly. Does confidence or coordinate error tell
you something that a hard 0/1 accuracy hides?

Then switch the high-level variable in the first exercise to `(1,)` and build
the corresponding intervention using `rotation[:, 1:2]`. The desired output must
preserve the base routing decision. Merely changing the target labels after a
routing swap is not the same experiment.

<!-- ARENA:cell code -->
```python
PLAY_ANGLE_DEGREES = 30
angle = t.tensor(PLAY_ANGLE_DEGREES * np.pi / 180, dtype=t.float64)
play_basis = angle.cos() * rotation[:, 2:3] + angle.sin() * rotation[:, :1]
play_results = {"Unused copy": results["Unused copy"],
                f"Angle {PLAY_ANGLE_DEGREES}°": evaluate_alignment(organism, heldout, play_basis),
                "Known causal": results["Known causal"]}
fig, axes = plt.subplots(1, 2, figsize=(9, 3.5), constrained_layout=True)
for ax, metric, label in [(axes[0], "changed_iia", "Changed-variable IIA"),
                          (axes[1], "routing_coordinate_mae", "Routing coordinate error")]:
    ax.bar(list(play_results), [r[metric] for r in play_results.values()], color=["#8a9eb2", "#bf4c28", "#487d9b"])
    ax.set(ylabel=label)
axes[0].set_ylim(0, 1.05)
fig.savefig(assets_dir / "das_angle_play.png", dpi=160)
plt.show()
```

<!-- ARENA:cell markdown -->
## Limitations and next experiment

This exact model was constructed to have two independent causal coordinates.
The unused duplicate also creates redundancy: more than one subspace can
implement the same output changes. The finite 1,024-pair test covers every
binary setting with new nuisance values, not every continuous hidden state.
An intervention can violate the observational equality between used and copied
coordinates; that does not by itself invalidate the specified structural
intervention. It does limit what an observational-manifold argument can prove.

The next part will ask whether a frozen GPT-2 model supports a useful alignment
for name-role changes. That requires a differentiable native continuation,
new prompt families, development selection, independent final evaluation and
controls for copying answer identity. No pretrained-model result is claimed by
this draft. Training an alignment is also distinct from training the neural
model itself with an interchange objective.

## Reading

- [Geiger et al., Finding Alignments Between Interpretable Causal Variables and Distributed Neural Representations](https://proceedings.mlr.press/v236/geiger24a.html): DAS and distributed interchange interventions. Our thin QR basis implements one orthogonal subspace rather than optimizing a full square rotation.
- [Geiger et al., Causal Abstraction: A Theoretical Foundation for Mechanistic Interpretability](https://jmlr.org/papers/v26/23-0058.html): formal alignments, intervention distributions and approximate abstraction. An empirical output score supplies only part of that argument.

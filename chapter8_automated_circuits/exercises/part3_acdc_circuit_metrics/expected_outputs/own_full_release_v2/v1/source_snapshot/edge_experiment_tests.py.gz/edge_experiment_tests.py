"""Ensure long notebook runs cannot silently reuse stale or unchecked results."""
from __future__ import annotations

import json

import pytest

from . import real_edges as edge
from .edge_experiments import checkpointed_learner_search


def test_notebook_checkpoint_reuse_and_fresh_execution(tmp_path):
    graph = edge.build_residual_graph(1, 1)
    calls = []
    def loss(mask):
        calls.append(mask.clone())
        primary = float(mask[0, 0] and mask[1, 4])
        backup = float(mask[0, 3] and mask[2, 4])
        return (1.2 - primary - .2 * backup) ** 2
    kwargs = dict(threshold=.01, search_fn=edge.greedy_edge_acdc,
                  core_functions={"graph": edge.build_residual_graph},
                  data={"task": "two_path_oracle", "seed": 1},
                  model_revision="exact_oracle_v1", output_directory=tmp_path)
    first = checkpointed_learner_search(graph, loss, **kwargs)
    first_calls = len(calls)
    assert first_calls > 1
    cached = checkpointed_learner_search(graph, loss, **kwargs)
    assert cached["trace"] == first["trace"]
    assert len(calls) == first_calls + 1, "A cached final mask must be evaluated live."
    calls.clear()
    fresh = checkpointed_learner_search(graph, loss, **kwargs, fresh=True)
    assert len(calls) == first_calls, "Fresh learner validation must actually execute every search decision."
    assert fresh["active_edges"] == first["active_edges"]
    calls.clear()
    changed = {**kwargs, "data": {"task": "two_path_oracle", "seed": 2}}
    checkpointed_learner_search(graph, loss, **changed)
    assert len(calls) == first_calls, "Different task data must start a separate search."

    # Corrupt a cached result's recorded final loss without changing source/data.
    context_dirs = [path for path in tmp_path.iterdir() if not path.name.startswith("fresh-")]
    assert len(context_dirs) == 2
    for directory in context_dirs:
        path = directory / "checkpoint.json"
        record = json.loads(path.read_text())
        record["final_loss"] += 1.
        path.write_text(json.dumps(record))
    with pytest.raises(ValueError, match="live recomputation"):
        checkpointed_learner_search(graph, loss, **kwargs)
